# 小米 14 Ultra 协议 v3 回归（2026-10-08）

本轮只测试 Xiaomi 14 Ultra，ADB 设备 925c23bb，型号 24031PN0DC；同包不同进程 echo，Debug APK。开始时电量 34%、电池温度 33.3°C。测试契约 serviceId=9001、apiVersion=3、apiHash=bench_echo_v3。

APK SHA-256：9645B21BBD43557E416DE6428015E7DA75B358E83D24AABB2433C49B6D2A8BA0。设备 base.apk 拉回后哈希与本地构建产物一致。

## 修改与验证

direct 回复先写 Android 标准异常头，客户端 readException 后解析业务状态。保留业务异常的 RuntimeException 消息契约。错误 token 返回 SecurityException、空 String 参数返回 IllegalArgumentException、业务错误返回 bench-error；两轮均通过。Int、Long、Boolean、ByteArray 回归均通过。主线程保护代码保持，当前基准由后台 scope 启动，本轮没有实际执行主线程保护断言。

suspend/oneway 请求增加 finally 回收与拒绝事务检查；Flow 将参数编码纳入 finally 回收。五个演示应用 assembleDebug 通过。Parcel 故障回收和本地 Binder 返回 false 分支已检查生成源码，本轮未做独立故障注入，不能将正常调用零失败解释为这些路径的设备验证。

## 同一 APK 串行结果

每种模式、每个负载预热 50 次，计时 1000 次。verify1 挂起先、verify2 direct 先；包含结果检查。单位 ms。

| 字符数 | 模式 | verify1 P50 | verify2 P50 | 两轮 P50 中位数 |
| --- | --- | ---: | ---: | ---: |
| 16 | suspend | 0.645989 | 0.579427 | 0.612708 |
| 16 | direct | 0.115729 | 0.143229 | 0.129479 |
| 1024 | suspend | 0.547292 | 0.795469 | 0.671381 |
| 1024 | direct | 0.262187 | 0.398021 | 0.330104 |

## 并发回归

16 字符负载，每格 1024 次成功，预热 50 次；QPS 为成功次数/整批耗时。

| 并发数 | 模式 | QPS | P50 ms | P99 ms |
| --- | --- | ---: | ---: | ---: |
| 16 | suspend | 2679 | 5.145 | 16.551 |
| 16 | direct | 18828 | 0.421 | 4.185 |
| 64 | suspend | 3213 | 17.622 | 30.476 |
| 64 | direct | 21181 | 0.387 | 7.160 |

总计 12096 次计时调用，日志 failures=0，12 个 CSV 样本数和正值校验通过。[原始 CSV 与日志](runs/2026-10-08-xiaomi14ultra/protocol-v3/)可复核全部分位数。

这是一轮协议修复后的功能与性能回归；只有两轮串行和一轮并发，不用于证明相较 v2 的性能增益，也未重新运行 AndLinker。设备温度、系统负载、安装包与 9 月测试不同，旧结果保持独立。短 echo 不代表长任务、I/O、跨 UID 或生产业务性能；同步快速路径仍不能在主线程使用。
