# 小米鉴权分配优化（2026-10-08）

## 结论

已落地服务端鉴权临时对象优化。小米同 UID、不同进程的鉴权微测，在同一服务进程重复预热后，线程 CPU 时间从 479.8 ns/次降至 187.5 ns/次，下降 60.9%。每批 50000 次旧路径的进程累计分配增量约 3.2 MB，新路径批次的计数器增量为 0；这是近似进程计数，不能解释为精确零分配或整个应用 CPU 降低 61%。

四轮同 APK IPC A/B 的配对变化方向不一致，**尚未证明端到端延迟稳定下降**。保留此次局部分配和 CPU 改善，未用不稳定的 IPC 中位数给出通用加速倍数。

## 改动与调用链

[CallerAuthenticator](../../ipc-runtime-server/src/main/kotlin/com/cn/ipc/server/CallerAuthenticator.kt)新增 authorizeCurrentCaller：每个事务读取当前 Binder UID；同 UID 按原策略准入；不同 UID 每次实时查询包名并检查签名。旧 authenticate/authorize API 保留，鉴权结果没有被缓存。

[ServerStubGenerator](../../ipc-compiler/src/main/kotlin/com/cn/ipc/compiler/ServerStubGenerator.kt)让每个 Stub 持有一个无状态鉴权器，token 校验后调用 authorizeCaller。默认入口执行上述策略。protected 入口用于基准复现旧实现；覆盖者负责保留调用方校验。

原同 UID 路径构造了鉴权器、CallerIdentity 和单元素包名集合，还获取未被准入逻辑使用的 PID。新路径直接校验，避免这些构造。实际对象分配可能受 ART 优化影响，以观测计数和源码分别说明。

~~~mermaid
flowchart TD
    A[每次 Binder 事务] --> B[enforceInterface]
    B --> C[复用无状态鉴权器]
    C --> D[读取当前调用 UID]
    D --> E{与服务 UID 相同}
    E -- 是 --> F[进入业务分发]
    E -- 否 --> G[实时查询 UID 包名]
    G --> H{有包名且签名匹配}
    H -- 是 --> F
    H -- 否 --> I[SecurityException]
~~~

## 设备、APK 与控制变量

仅 Xiaomi 14 Ultra（925c23bb、24031PN0DC、Android 16）测试。A/B 开始电量 46%、温度 32.9°C；测量中读取到 Awake、USB供电、前台 MainActivity。测试前停止同项目其它演示进程，跨 UID 回归在 A/B 后进行。

Debug 同 APK：FCD36F32540CFB9256A19013439A4911C16144873F1AA8D122778EB65CEDAA0D。设备 base.apk 与本地哈希一致，完整 APK/源码哈希见[evidence.json](runs/2026-10-08-xiaomi14ultra/auth-allocation/evidence.json)。

[IpcAuthBenchmark](../../demo-app/src/main/kotlin/com/cn/ipc/demo/IpcAuthBenchmark.kt)通过基准 echo 的专用控制参数，切换服务器同一个 Stub 的旧/新鉴权。两边都经过 token 与完整准入策略，相同事务号、同一服务 ID、16 个 ASCII 字符、相同客户端/服务端调度器。模式控制和 CSV 落盘均在计时之外；每格预热 50 次、计时 1000 次，包含结果检查。

四轮 authab1/2/3/4 的鉴权顺序分别旧新、新旧、新旧、旧新；API 顺序奇数挂起先、偶数 direct 先。每轮冷启演示进程，结束时恢复新鉴权模式。基准入口只有显式 intent extra 才运行；默认 Stub 使用优化策略，基准 echo 的控制分支不涉及 MessageHub/IUser 业务。

## IPC 配对结果

总计 16 个 CSV、16000 个有效计时样本，16 个 RESULT 和 4 个 DONE，失败数均为 0。负值表示优化后 P50 更低。

| 轮次 | suspend P50 变化 | direct P50 变化 |
| --- | ---: | ---: |
| authab1 | +33.17% | -57.02% |
| authab2 | -13.95% | -61.58% |
| authab3 | -29.22% | -2.13% |
| authab4 | +82.02% | +101.28% |

四轮 run-P50 中位数：suspend 0.748333→0.764662 ms（+2.18%），direct 0.270286→0.187578 ms（-30.60%）。由于配对方向和尾延迟不一致，direct 的汇总下降不能作为稳定 30.6% 加速结论。

authab1 optimized/suspend 保留了一个 11341.402026 ms 的最大样本，拉高该格均值；没有删除。该停顿原因本轮未定位，不能归因于鉴权优化，也不能以 P50 掩盖它。完整逐轮 P99、最大值和配对表在[自动重算结果](runs/2026-10-08-xiaomi14ultra/auth-allocation/summary.md)。

这轮数据表明此负载下调度/系统波动远大于鉴权微秒内的局部差值。该说明是对观测尺度的推断，未用调度 trace 定位具体线程或停顿根因。因串行收益未稳定，本轮没有扩张到并发64或追测更多轮次。

## 鉴权 CPU 与分配微测

[IpcAuthProbe](../../demo-app/src/main/kotlin/com/cn/ipc/demo/IpcAuthProbe.kt)在真实同 UID Binder 调用线程执行，每路径预热 2000 次，旧新新旧、每格 50000 次。CPU/墙钟计时与分配采样分批；没有人为保存身份对象到逃逸 sink。第一次受 JIT/频率影响，全部保留；为核对预热影响，在同一服务 PID 8746 再跑一次。

第二次 CPU 数据：

| 模式 | 批次 | 线程 CPU ns/次 |
| --- | --- | ---: |
| 旧 | 0 | 515.284 |
| 新 | 1 | 187.022 |
| 新 | 2 | 187.970 |
| 旧 | 3 | 444.298 |

两格中位数旧 479.791、新 187.496 ns/次，下降 60.9%；这只覆盖同 UID 鉴权循环。第二次分配批次旧为 3260416/3194880 bytes，新为 0/0，旧第一格有一次 GC，新两格均无 GC。不能用这一小批 GC 次数推导长期 GC 降幅。

分配通过 Debug.getRuntimeStat 读取进程总计。Android 文档说明这些统计是近似值、单次分配不保证立即反映；null 保留为 unavailable。其它线程和统计调用也可贡献分配，不能把表中的进程平均量当函数精确计数。[Android Debug 官方说明](https://developer.android.com/reference/android/os/Debug#getRuntimeStat(java.lang.String))

## 功能门禁与证据范围

五个演示应用 assembleDebug 通过（JDK17、offline、max-workers=1、in-process Kotlin）；git diff --check 通过。

优化 APK 的 faultauth1 六组故障探针通过：即时回包不多发 cancel、两种取消各一次 hook、1000 轮注册表回复/断连竞争、远端 Flow 工厂异常、关闭 pending 失败、旧快照拒绝、重连 Flow 正常。它沿用[故障报告](xiaomi14ultra_2026-10-08_fault_paths.md)的验收边界，不能扩展为服务端进程死亡或远端 Job 回收证明。

不同 UID 回归：app-client1（u0_a422）→app-server（u0_a421），均安装本轮 APK，1000 次 RTT 往返完成，界面显示已连接，见[回归日志](runs/2026-10-08-xiaomi14ultra/auth-allocation/cross-uid-logcat.txt)、[UI XML](runs/2026-10-08-xiaomi14ultra/auth-allocation/cross-uid-ui.xml)和[进程记录](runs/2026-10-08-xiaomi14ultra/auth-allocation/processes.txt)。两个设备 base.apk 均与本地产物匹配。这验证有效签名的跨 UID 调用路径，未验证不同签名拒绝，也不作为跨 UID 性能增益数据。

## 复现

~~~powershell
adb -s 925c23bb install -r demo-app/build/outputs/apk/debug/demo-app-debug.apk
adb -s 925c23bb shell am force-stop com.cn.ipc.demo
adb -s 925c23bb shell am start -n com.cn.ipc.demo/.MainActivity --es ipc_benchmark authab1
~~~

待 DONE 后重复 authab2、authab3、authab4。以 authmicro1 冷启运行微测，随后 clear-top 重建 Activity、以 authmicro2 在保留的服务进程复测。每轮结束恢复优化模式。

~~~powershell
python docs/benchmarks/harness/analyze_auth.py docs/benchmarks/runs/2026-10-08-xiaomi14ultra/auth-allocation
~~~

[分析脚本](harness/analyze_auth.py)严格校验样本数、正值、RESULT/DONE 和分位数，并处理不可用的分配统计。后续如需稳定降低真实业务 RTT，应先用线程调度证据定位长停顿与挂起路径两次调度；本轮没有更改业务线程或取消/限流语义。
