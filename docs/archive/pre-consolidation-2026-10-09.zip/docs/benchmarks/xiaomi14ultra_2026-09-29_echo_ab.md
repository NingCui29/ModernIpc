# 小米 14 Ultra：ModernIpc / AndLinker 同负载 echo 实测

日期：2026-09-29。此报告补充[原版示例功能短测](xiaomi14ultra_2026-09-29_smoke.md)，使用明确的相同业务方法取得可比较的端到端 API 往返样本。这里比较的是两套 Debug 示例在指定调用方式下的完整调用开销，不是纯 Binder 单跳耗时，也不是任意业务或设备上的库性能排名。

## 测试对象

设备：Xiaomi 14 Ultra，型号 24031PN0DC，Android 16，系统构建 BP2A.250605.031.A3，USB 供电。主对比序列期间电量约 14%～15%，结束时电池温度 31.5 °C，Thermal Status 0。测试没有固定 CPU 频率；不同轮次仍会受到系统调度、ART 编译和温度影响。

| 实现 | 安装拓扑 | API 调用 | Debug APK SHA-256 |
| --- | --- | --- | --- |
| ModernIpc | demo-app 主进程 → 同包 :server 服务进程；targetSdk 34 | KSP 生成代理的 suspend echo(String): String；单向请求加回调 Binder 恢复协程 | 47BB67B492393E116B7239EFF712E0010C265D29B1CE0194896374D39C156E30 |
| AndLinker | sample 主进程 → 同包 :remote 服务进程；targetSdk 26 | Java 动态代理同步 echo(String): String；另测 Call.enqueue 的回调路径 | CFD5EE622B80470771C20391065F29611F17C5C1ED5A9AE038E174D5E8101B25 |

ModernIpc 对应本仓库提交 7586008421271537ef16500429277fd8434d40db 加工作区未提交修复及专用 echo 契约。AndLinker 对应[上游提交 7ae01bfd](https://github.com/codezjx/AndLinker/tree/7ae01bfd87ddcf021319148a8727a95345cf350e)，临时克隆增加了 echo 方法、测试入口与 Debug 签名配置，并在测试入口关闭库的逐次日志；改动已保存为[可复现补丁](harness/andlinker-echo.patch)。两边服务端业务均为原样返回传入的字符串，无 sleep、日志或数据库访问。客户端逐次校验返回值等于入参。

测试后读取设备上已安装的两个 base.apk 并计算 SHA-256，均与本地构建文件一致；设备侧输出见[安装包哈希记录](runs/2026-09-29-xiaomi14ultra/echo-ab2/installed-apk-hashes.txt)。

## 方法

- 两档 ASCII 字符串：16 字符与 1024 字符。它们是业务字符数，不是实测 Parcel 字节数。
- 每库每档每轮先预热 50 次，再串行测 1000 次。每次以设备上的 SystemClock.elapsedRealtimeNanos 在调用前后计时；写 CSV 与统计摘要发生在采样结束之后。
- ModernIpc 在单条 Dispatchers.Default 协程中循环。AndLinker 同步路径在后台线程循环；enqueue 路径在后台线程发起 Call.enqueue，等待默认主线程回调后进入下一次请求。两边都包含代理、序列化、Binder、服务端回显及客户端恢复/回调。
- 每轮先 force-stop 两个示例，再启动目标 Activity；按照 And、Modern、Modern、And、And、Modern、Modern、And 的顺序运行主序列 a5/m5/m6/a6/a7/m7/m8/a8。冷启动和绑定发生在计时前。所有样本在服务已连接后采集。
- P50/P90/P99 使用每轮排序后第 500/900/990 个样本，摘要使用四轮 P50 的中位数。比值是 ModernIpc 摘要 P50 除以 AndLinker 摘要 P50；数值大于 1 表示在这次配置下 ModernIpc 的样本耗时较长。

## 主序列结果

每行 1000 次回显，全部返回内容匹配，失败数均为 0。单位 ms。

| 实现 | 字符 | 四轮 P50 | 四轮 P99 |
| --- | ---: | --- | --- |
| ModernIpc suspend | 16 | 0.540 / 0.532 / 0.501 / 0.540 | 1.632 / 1.804 / 1.540 / 1.924 |
| AndLinker 同步 | 16 | 0.255 / 0.257 / 0.264 / 0.259 | 1.408 / 0.694 / 0.779 / 1.003 |
| AndLinker enqueue | 16 | 0.354 / 0.331 / 0.324 / 0.308 | 0.604 / 0.486 / 0.482 / 0.570 |
| ModernIpc suspend | 1024 | 0.598 / 0.864 / 0.557 / 0.766 | 1.086 / 1.588 / 1.185 / 1.606 |
| AndLinker 同步 | 1024 | 0.264 / 0.235 / 0.222 / 0.229 | 0.417 / 0.319 / 0.324 / 0.304 |
| AndLinker enqueue | 1024 | 0.373 / 0.354 / 0.351 / 0.351 | 0.529 / 0.497 / 0.510 / 0.483 |

| 字符 | ModernIpc 四轮 P50 中位数 | AndLinker 同步 | AndLinker enqueue |
| ---: | ---: | ---: | ---: |
| 16 | 0.536 ms | 0.258 ms（Modern / And = 2.08） | 0.327 ms（Modern / And = 1.64） |
| 1024 | 0.682 ms | 0.232 ms（Modern / And = 2.94） | 0.353 ms（Modern / And = 1.93） |

本次同负载、同包分进程的短时串行回显中，AndLinker 两种调用方式的 P50 均低于 ModernIpc。AndLinker 同步路径仅用一次同步请求/响应 Binder 事务；ModernIpc 的挂起接口使用请求事务加返回回调，协议与调度开销不同。enqueue 路径还含线程池提交和默认主线程回调，因此应优先与挂起 API 对照，但它仍不是相同调度实现。不能把上述比值推广为所有 IPC 方法或生产场景的固定性能倍数。

主序列原始数据：[24 个 CSV 与 Logcat 汇总](runs/2026-09-29-xiaomi14ultra/echo-ab2/)。每个 CSV 恰有 1000 个以纳秒计的正数。使用[分析脚本](harness/analyze_echo.py)可重新生成逐轮均值、P50、P90、P99 和摘要表：

~~~powershell
python docs/benchmarks/harness/analyze_echo.py docs/benchmarks/runs/2026-09-29-xiaomi14ultra/echo-ab2 5 8
~~~

在扩展 enqueue 路径前，还完成四轮同步路径与 ModernIpc 交替测试。旧 APK 哈希不同，数据保存在[初始序列](runs/2026-09-29-xiaomi14ultra/echo-ab/)；不与主序列混算。

## 可复现入口

ModernIpc 测试契约在[IBenchmarkEchoService](../../ipc-api/src/main/kotlin/com/cn/ipc/api/test/IBenchmarkEchoService.kt)，服务端注册在[MyBrokerService](../../demo-app/src/main/kotlin/com/cn/ipc/demo/MyBrokerService.kt)，采样代码在[IpcEchoBenchmark](../../demo-app/src/main/kotlin/com/cn/ipc/demo/IpcEchoBenchmark.kt)。使用 JDK 17 构建 demo-app:assembleDebug，安装 Debug APK 后通过 ADB 启动：

~~~powershell
adb shell am force-stop com.cn.ipc.demo
adb shell am start -W -n com.cn.ipc.demo/.MainActivity --es ipc_benchmark m9
adb exec-out run-as com.cn.ipc.demo cat files/modern-m9-16.csv
~~~

AndLinker 在指定上游提交上应用[补丁](harness/andlinker-echo.patch)，使用 JDK 11 和 Android SDK 构建 sample:assembleDebug。旧工程的发布脚本配置阶段需要传入仅供本地编译的 ossrhUsername/ossrhPassword 占位属性；补丁中的 Debug 签名配置引用 sample/bench-debug.keystore，需自行生成测试密钥，不能使用生产密钥。在上游克隆目录执行，先把补丁路径替换成自己工作区的实际路径：

~~~powershell
git checkout 7ae01bfd87ddcf021319148a8727a95345cf350e
git apply D:/Developer/WorkSpace/ModernIpc/docs/benchmarks/harness/andlinker-echo.patch
keytool -genkeypair -keystore sample/bench-debug.keystore -storepass android -keypass android -alias AndroidDebugKey -dname "CN=Android Debug,O=Android,C=US" -keyalg RSA -keysize 2048 -validity 10000
.\gradlew.bat :sample:assembleDebug -PossrhUsername=unused -PossrhPassword=unused
adb shell am start -W -n com.example.andlinker/.BindingActivity --es ipc_benchmark a9
adb exec-out run-as com.example.andlinker cat files/andlinker-async-a9-16.csv
~~~

构建前需设置 JDK 11 的 JAVA_HOME、ANDROID_HOME/ANDROID_SDK_ROOT。安装 APK、force-stop 两应用、逐轮启动并保存 CSV 的顺序见上方方法说明。此补丁的反向应用检查已通过。

## 边界与下一步

本次只覆盖 16 与 1024 字符、单个在途请求、前台客户端、同包分进程和 Debug 构建。两 APK 的 targetSdk、构建工具、语言与调度器不同；这些也是结果的一部分，不能拆成“反射开销”或“Binder 独占开销”。未测跨包绑定、后台唤醒、并发成功吞吐、长消息、Oneway 服务端完成时间、CPU 与内存。特别是之前[跨包业务短测](xiaomi14ultra_2026-09-29_smoke.md)出现小米后台唤醒拒绝和几十秒回执长尾，这些现象不能由本次前台 echo 数据解释或排除。
