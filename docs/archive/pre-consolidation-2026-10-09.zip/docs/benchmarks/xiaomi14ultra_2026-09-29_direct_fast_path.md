# 小米 14 Ultra：可选同步快速路径实测

日期：2026-09-29。此次对比只针对同一 ModernIpc Debug APK 中两个等价的无业务计算 echo 方法：原 `suspend echo` 与新增 `@IpcDirect echoDirect`。两者从同包主进程调用 `:server` 进程、返回完全相同的字符串。数据不能代表其他方法或跨包后台调用。

## 构建与设备

| 项目 | 值 |
| --- | --- |
| 设备 | Xiaomi 14 Ultra / 24031PN0DC，Android 16，构建 `BP2A.250605.031.A3`，ADB 序列号 `925c23bb` |
| 环境 | USB 连接、前台 Activity，结束时电量 24%、电池温度 31.0 °C、Thermal Status 0；没有锁定 CPU 频率 |
| 应用 | `com.cn.ipc.demo`，Debug，targetSdk 34；实测主进程与 `com.cn.ipc.demo:server` 同时存在 |
| APK SHA-256 | `208343DE0AA7968919EE1F054B35372738BACD6FBA927A7D0653B9E6B34BBA1B`；设备上安装的 base.apk 与本地构建一致 |
| 源码 | 基准提交 `7586008421271537ef16500429277fd8434d40db` 加工作区尚未提交的修复、echo 测试与本次 `@IpcDirect` 实现 |
| 契约 | echo 服务 `serviceId=9001`、`apiVersion=2`、`apiHash=bench_echo_v2`；新增同步事务码 12–16，不修改原挂起事务码 10/11 |

快速路径由[注解](../../ipc-annotations/src/main/kotlin/com/cn/ipc/annotations/IpcAnnotations.kt)、[生成客户端](../../ipc-compiler/src/main/kotlin/com/cn/ipc/compiler/ClientAdapterGenerator.kt)和[生成服务端](../../ipc-compiler/src/main/kotlin/com/cn/ipc/compiler/ServerStubGenerator.kt)组成。它在后台调用线程执行一次带 reply 的同步 Binder 事务；服务端仍鉴权，然后在 Binder 线程调用短方法并直接写 reply。原挂起方法继续使用单向请求、Job 跟踪、回调 Binder 与取消事务。

## 串行延迟

四轮 `release1`–`release4`，每轮对 16 与 1024 字符分别先预热 50 次，再串行调用 1000 次。奇数轮先测 suspend，偶数轮先测 direct；每次校验返回值与入参一致。计时为设备上的 `SystemClock.elapsedRealtimeNanos` 调用前后差值，写 CSV 和汇总发生在样本结束后。所有 16 个 CSV 均为 1000 条正数，Logcat 没有 `FAILED`。

| 字符 | suspend 四轮 P50 ms | direct 四轮 P50 ms | 四轮 P50 中位数 suspend → direct |
| ---: | --- | --- | --- |
| 16 | 0.586 / 0.545 / 0.533 / 0.542 | 0.255 / 0.103 / 0.150 / 0.107 | **0.543 → 0.129 ms**，约 4.23 倍 |
| 1024 | 0.603 / 0.600 / 0.608 / 0.585 | 0.350 / 0.318 / 0.231 / 0.338 | **0.602 → 0.328 ms**，约 1.83 倍 |

16 字符 direct 的逐轮 P99 为 0.443/0.752/0.393/0.557 ms，suspend 为 1.652/1.398/1.475/1.494 ms。1024 字符 direct P99 为 0.558/0.536/0.475/0.502 ms，suspend 为 1.159/1.214/1.114/0.956 ms。短输入 direct 的轮间 P50 从 0.103 到 0.255 ms，说明系统状态仍带来显著波动；不能把最快一轮视为稳定成本。

## 并发短测

两轮 `stress1`、`stress2`；分别以 16 和 64 个 `Dispatchers.IO` 工作协程发送总共 1024 个 16 字符请求。每个工作协程在共同闸门打开后连续调用，全部结果必须匹配入参。总时长从打开闸门到最后一个任务完成，QPS = 1024 个成功请求 / 总秒数；P99 为每请求耗时。两轮改变两种模式的先后次序。所有 8 个 CSV 各有 1024 条正数，零失败。

| 并发 | suspend 成功 QPS（两轮） | direct 成功 QPS（两轮） | suspend P99 ms（两轮） | direct P99 ms（两轮） |
| ---: | --- | --- | --- | --- |
| 16 | 2487 / 1908 | 12014 / 19067 | 24.645 / 18.422 | 6.002 / 3.576 |
| 64 | 3765 / 1929 | 34393 / 15272 | 30.906 / 72.142 | 4.442 / 17.035 |

这是无 I/O、无挂起的极短服务方法。64 并发的 direct P99 从 4.442 变为 17.035 ms，成功 QPS 从约 34393 变为 15272；设备调度与线程竞争造成的波动不可忽略。同步路径占用客户端和服务端 Binder 线程，遇到耗时业务可能出现完全不同的结果。当前 direct 路径也不经过异步请求的 128 在途许可和远端取消机制，因此不能用这组数字决定真实业务的容量上限。

## 功能与可复算性

每次串行运行计时前还检查：主线程调用 direct 被拒绝；服务端抛出的指定错误会回到客户端；Int、Long、Boolean、ByteArray 生成分支的返回值正确。四轮均继续完成所有 echo 采样，Logcat 无失败。编译已覆盖 demo-app 与四个跨包示例 APK。设备上观察到主进程与 `:server` 服务进程同时运行。

编译期负例也已核对：临时给 echo 接口加入与原请求冲突的事务码 10，以及不受支持的 Unit 返回值，KSP 分别报告重复事务号和非法返回类型并使构建失败；恢复测试契约后 Debug 与 Release 构建通过。负例改动没有留在最终源码或 APK 中。

原始 [24 个 CSV、Logcat 与逐轮输出](runs/2026-09-29-xiaomi14ultra/direct-final)由[复算脚本](harness/analyze_direct.py)检查并重算：

```powershell
python docs/benchmarks/harness/analyze_direct.py docs/benchmarks/runs/2026-09-29-xiaomi14ultra/direct-final
```

此前的[AndLinker 同负载对比](xiaomi14ultra_2026-09-29_echo_ab.md)使用另一组 APK、调用语义和测试时段，不能将其数值与本表直接混算，或宣称快速路径已在所有场景超过 AndLinker。下一步应给真实短业务单独加 direct 契约，并分别验证跨包鉴权、长尾、Binder 线程占用、超时与业务异常。同步 Binder 的调用线程限制见 [Android AIDL 文档](https://developer.android.com/develop/background-work/services/aidl)。
