# 当前问题分析：冷发现、关闭清理与 RTT 波动

分析日期：2026-10-08。设备证据限定 Xiaomi 14 Ultra（925c23bb、24031PN0DC、Android 16）。本次核对源码，并离线复算已有合格记录；没有新增设备测试或修改生产源码。

关联报告：[发送前检查优化](xiaomi14ultra_2026-10-08_presend_guard.md)、[优化分析总览](../ModernIPC_Optimization_Analysis.md)、[架构](../ModernIPC_Architecture.md)。

## 1. 结论与优先级

| 优先级 | 问题 | 已有证据 | 当前边界 |
| --- | --- | --- | --- |
| P1 | Async 冷发现同步调用 Broker，可能阻塞 UI；注册请求的截止计时尚未开始 | 生成代理先发现 Binder，再进入 PendingCallRegistry；demo 的部分调用来自 Main scope | 调用链由源码确认；慢 Broker 导致的 UI 卡顿/ANR 尚未在小米复现 |
| P1 | 远程发现在缓存 `compute` 内，可能拖住 `clear`，连带延迟解绑、pending 终结和 dispose 完成 | Controller 的 RPC、缓存清理和 failAll 顺序；AOSP Android 16 的 Map 同步机制 | 满足慢 RPC、同一缓存 bin 和清理并发条件时存在风险；尚未审计小米对应 libcore 或复现此故障 |
| P2 | RTT 样本存在明显连续相关与块内漂移，当前结果不足以证明稳定收益 | 两组合格 run 的原始 CSV，32 个测量块均有较高相邻相关 | 漂移已观测；调度、频率、GC、JIT 中哪项造成它仍未知 |
| P2 | 前台监控的合格判定缺少最大采样间隔与覆盖要求 | 分析脚本只检查间隔非负；监控和生命周期回调都依赖 Main 线程执行 | 本轮最大间隔 504/505 ms，没有观测到长时间停采；未来记录可能漏判 |
| P2 | `maxReconnectAttempts=0` 在首次绑定失败和已连接后死亡分支的处理不同 | 首次失败检查上限；死亡分支直接设置 attempt=1 并调度 | API 尚未明确零是否禁止所有自动重连；应先统一契约再修分支 |

前两项是应优先处理的生命周期与冷发现风险。它们独立于当前已经预热的 echo RTT 比较；不能用它们解释本次温缓存测量方向反转。

## 2. P1：Async 冷发现发生在调用线程和截止计时之前

### 2.1 实际调用链

- [ClientAdapterGenerator](../../ipc-compiler/src/main/kotlin/com/cn/ipc/compiler/ClientAdapterGenerator.kt)第 114 行生成同步 `getServiceBinderForConnection`，第 131 行才进入 `callSuspend`。
- [Controller](../../ipc-runtime-client/src/main/kotlin/com/cn/ipc/client/IpcConnectionController.kt)第 156–168 行在冷缓存分支执行同步 `getServiceSchema`、校验、`getServiceChecked`；无 Schema 的手工调用分支执行同步 `getService`。
- [PendingCallRegistry](../../ipc-runtime-client/src/main/kotlin/com/cn/ipc/client/PendingCallRegistry.kt)第 46 行进入 `withTimeout(defaultCallTimeoutMs)`，计时覆盖注册后的等待。
- [MainActivity](../../demo-app/src/main/kotlin/com/cn/ipc/demo/MainActivity.kt)第 28 行使用 Main scope，第 230、261 行分别调用 Async 业务方法。`suspend` 函数的声明不会自动把其中的同步发现切换到后台线程。

```mermaid
sequenceDiagram
    participant U as Main 调用协程
    participant A as 生成 Async 代理
    participant C as Controller / 服务缓存
    participant B as 远端 Broker
    participant P as PendingCallRegistry
    U->>A: 首次调用 / 捕获 Connected
    A->>C: getServiceBinderForConnection
    alt 缓存未命中
        C->>B: 同步 getServiceSchema
        B-->>C: 返回元数据
        C->>C: 严格校验
        C->>B: 同步 getServiceChecked
        B-->>C: 返回业务 Binder
    end
    C-->>A: 捕获 Binder
    A->>P: 开始注册后截止计时 / pending
    A->>A: 编码 / guard / oneway 请求
    P-->>U: 回复、取消、超时或关闭终态
```

风险触发条件是 UI 上首次访问服务、缓存失效或进入新连接代次，同时 Broker 对发现 RPC 响应很慢。此时 Main 线程等待同步 Binder 返回；当前注册后 30 秒计时还没有开始，取消也无法自动中断这个同步 RPC。Android 官方说明了同步 AIDL 的阻塞行为与 UI 调用风险；Kotlin 的超时依赖协作式取消。[Android AIDL 文档](https://developer.android.com/develop/background-work/services/aidl)、[withTimeout 文档](https://kotlinlang.org/api/kotlinx.coroutines/kotlinx-coroutines-core/kotlinx.coroutines/with-timeout.html)

当前 API 的超时范围已定义为注册后的等待。若业务需要覆盖冷发现的端到端 deadline，应在入口创建统一预算，把冷发现和后续响应等待纳入同一个期限。

### 2.2 现有测试为何没有覆盖

[IpcTerminalProbe](../../demo-app/src/main/kotlin/com/cn/ipc/demo/IpcTerminalProbe.kt)第 119 行先调用 Direct echo 预热服务，再测试较短截止。该 PASS 证明预热之后的注册请求能超时并取消，没有覆盖慢 Schema 发现。局部 Registry 竞态测试也从注册入口开始。

最新 APK 的 52 项功能 PASS 应继续保留，但不能作为这条冷发现路径已通过的证据。

## 3. P1：冷 RPC 与关闭清理形成等待链

### 3.1 锁和操作顺序

Controller 冷发现把同步 Broker RPC 放在 `serviceBinderCache.compute` 的映射函数里。`launchClose` 获得 Controller Mutex 后，先发布 Closed/Disposed，再调用 `doUnbindServiceLocked`；后者先 `serviceBinderCache.clear()`，随后解绑。`pendingCallRegistry.failAll` 和永久释放完成信号发生在缓存清理之后。

AOSP Android 16 的 `ConcurrentHashMap.compute` 在相关 bin 或占位节点的 monitor 内执行映射函数；`clear` 也同步访问 bin。慢映射函数可能让并发清理等待。这是核对过的 AOSP 机制，小米系统对应实现尚未现场确认。[AOSP Android 16 ConcurrentHashMap](https://android.googlesource.com/platform/libcore/+/android16-release/ojluni/src/main/java/java/util/concurrent/ConcurrentHashMap.java)

```mermaid
sequenceDiagram
    participant R as 冷发现线程
    participant M as 缓存 bin monitor
    participant B as 远端 Broker
    participant L as close / dispose 控制协程
    participant P as 已注册请求
    R->>M: compute：获取 bin monitor
    M->>B: 映射函数内同步发现 RPC
    Note over R,B: 等待远端返回，monitor 尚未释放
    L->>L: 获取 Controller Mutex / 发布 Closed 或 Disposed
    L->>M: clear：等待相关 bin monitor
    Note over L,P: 解绑和 failAll 尚未执行
    B-->>M: RPC 最终返回或抛错
    M-->>R: 映射退出 / 释放 monitor
    R->>R: 连接代次检查 / 拒绝旧结果
    M-->>L: clear 完成
    L->>L: unlink / unbind
    L->>P: failAll
    L->>L: 释放 Controller Mutex
    L->>L: 永久释放时完成 dispose 信号
```

直接影响包括：已经挂起的其他请求不能及时收到关闭异常；`closeAndJoin` / `disposeAndJoin` 延迟完成；新的 connect 等待同一个 Controller Mutex。状态已经显示关闭也不代表清理已完成。

这里确认的是外部 RPC 拖住本地清理的等待路径。没有发现两个本地锁必然循环等待的证据，不能描述为已经发生的永久死锁。

### 3.2 修复边界

1. **先把远程发现移出 Map 映射函数和清理持锁区域。** 共享缓存只做短时间查找和发布；同一代次、同一 Schema 的并发发现需要合并为一次进行中的任务。
2. **让清理能直接作废代次缓存。** 可采用代次专属缓存容器，并在关闭时替换/解除引用；解析者必须捕获所属容器，返回后核对代次，避免晚到结果写入新缓存。
3. **让已注册请求尽快进入终态。** 整理 failAll 与清理顺序，确保它不等待远端发现；同时保留发送前代次检查，覆盖并发晚注册。
4. **为 Async 提供可取消的冷发现等待。** 同步 Binder 工作放入有容量限制的工作线程；调用方等待可超时、可取消，旧结果一律丢弃。严格 Schema 校验、异常和鉴权行为保持。
5. **明确阻塞工作线程的边界。** `withContext(IO)` 加 `withTimeout` 本身不能强制终止已开始的 Binder 调用；结构化等待还可能等待阻塞代码退出。必须设计工作任务与调用方等待的生命周期、容量上限和过载行为。远端永久不返回时不能保证立即回收该线程，也不能让无界新任务耗尽进程线程。

上述设计应同时覆盖 Async、显式预热和现有同步解析入口。Direct 的同步业务事务仍要求在 Main 之外执行。

## 4. P2：局部优化与实际 RTT 的量级和观测范围不同

已有两个合格 run 使用同一个 APK：`30ED4B9762422AFEBF5DBA9DEEBB125C81921EA60C5C766A7B53EEAE01A1782D`。各 run 16 个 IPC block，每块 1000 次成功串行调用；前台状态观测全部合格。记录见 [guardperf3](runs/2026-10-08-xiaomi14ultra/ordered-guardperf-3/analysis.json)、[guardperf5](runs/2026-10-08-xiaomi14ultra/ordered-guardperf-5/analysis.json)。

### 4.1 已经测到什么

| 记录 | 局部线程 CPU 节省 | 16 字符 RTT 摘要变化 | 1024 字符 RTT 摘要变化 |
| --- | --- | --- | --- |
| guardperf3 | 0.598743 μs/发送前检查步骤 | −31.89% | −16.91% |
| guardperf5 | 0.606955 μs/发送前检查步骤 | +4.84% | +9.98% |

RTT 摘要沿用原报告口径：每模式四个 block 各自 P50 的中位数之比；它不同于合并全部样本的 P50，也不同于配对百分比的中位数。原脚本分位数和摘要没有发现算术错误。

局部测试只重复发送前 recheck，统计线程 CPU；完整 RTT 统计墙钟，包含首次温缓存解析、Registry、编解码、两个 oneway 方向、服务端 Job、回复处理、调用方恢复和返回值检查。约 0.60 μs 相对约 700–1000 μs RTT，仅为 0.06%–0.09% 的直接成本量级。该比例不是收益上限：分配变化可能间接影响 GC 或排队，但目前没有轨迹证明这些效应。

温缓存 lookup 不执行两个发现 RPC。因此本轮优化不能解释为每次请求减少一次远程 Binder 往返。局部少约 48 B 也不是完整 Async 调用零分配的证明。

### 4.2 新复算：块内漂移与连续相关

[离线诊断脚本](harness/analyze_guard_problems.py)保持每个 CSV 内的采集顺序，计算相邻样本 Pearson 相关系数、四个连续 250 样本区间的中位数，以及逐轮配对 P50 差值。结果保存在[问题分析 JSON](runs/2026-10-08-xiaomi14ultra/analysis-current-problems/problem-analysis.json)。这是描述统计，没有假设平稳过程或计算显著性。

| 记录 | 16 个 block 的相邻相关系数范围 | 16 字符同一模式四个 block P50 极差 | 1024 字符同一模式四个 block P50 极差 |
| --- | --- | --- | --- |
| guardperf3 | 0.743–0.974 | lookup 350.833 μs；guard 429.115 μs | lookup 405.574 μs；guard 175.938 μs |
| guardperf5 | 0.680–0.978 | lookup 420.000 μs；guard 598.906 μs | lookup 508.281 μs；guard 206.145 μs |

两个明确例子：

- guardperf3，R4 lookup/16 的连续四段中位数约为 **0.990 → 0.848 → 0.461 → 0.507 ms**，相邻相关系数约 0.974。
- guardperf5，R4 lookup/16 的连续四段中位数约为 **0.579 → 0.385 → 0.464 → 0.907 ms**，相邻相关系数约 0.978。

同一实现、同一测量块的时延已经明显随采样进程变化。32,000 次串行调用共享运行环境，不能视为 32,000 次独立实验，也不能据此声明稳定收益或高置信度。当前更适合按 block / run 比较；样本数量增加无法替代对环境漂移的控制。

下图上排明确选取 R4/16 展示块内漂移，每 50 个连续样本取中位数，两条线来自分别采集的 block；下排保留全部四轮配对差值。全量 32 个 block 在 JSON 中保留，图示例不用于筛选收益。

![合格记录的块内漂移与逐轮差值](runs/2026-10-08-xiaomi14ultra/analysis-current-problems/guard-problems.png)

图脚本：[plot_guard_problems.py](harness/plot_guard_problems.py)。

### 4.3 已知环境不等于因果解释

- ABBA 平衡部分模式顺序，固定 50 次预热没有证明 JIT 已进入稳态。
- block 之间有诊断 RPC、CSV 写入、排序和日志；这些工作不计入单次 RTT，但可能影响下一块环境。具体影响量尚未测出。
- 四份 thermal 记录均为 `Thermal Status: 0`，但 **Current temperatures from HAL** 的 CPU5 在 run3 前后为 **51.5→38.8°C**，run5 为 **36.4→38.4°C**。必须读取当前 HAL 段，不能使用前面缓存段的旧温度。证据：[run3 前](runs/2026-10-08-xiaomi14ultra/ordered-guardperf-3/thermal-before.txt)、[run3 后](runs/2026-10-08-xiaomi14ultra/ordered-guardperf-3/thermal.txt)、[run5 前](runs/2026-10-08-xiaomi14ultra/ordered-guardperf-5/thermal-before.txt)、[run5 后](runs/2026-10-08-xiaomi14ultra/ordered-guardperf-5/thermal.txt)。端点温度无法说明测量期间是否调频，也没有证明它造成 RTT 反转。
- `processes.txt` 是进程快照，没有连续 CPU 负载、频率、PSI 或调度数据。局部分配计数不覆盖 IPC 测量时段，不能据此判断 RTT 长尾是否发生 GC。

当前可确认存在漂移、前后台状态合格和局部检查成本下降。温缓存 RTT 波动的主因仍待验证；本轮也没有新增 AndLinker 对照，不能更新两库速度排名。

## 5. P2：前台监控缺少采样覆盖门禁

[BenchmarkForegroundSession](../../demo-app/src/main/kotlin/com/cn/ipc/demo/BenchmarkForegroundSession.kt)在 Main 上运行，目标每 500 ms 记录状态，并记录生命周期/焦点变化。[analyze_guard.py](harness/analyze_guard.py)第 25 行只要求时间差非负，未限定最大间隔或最低周期覆盖。

Main 若长时间阻塞，周期采样和生命周期回调本身也可能延迟。仅见 BEGIN/END 有效而中间长时间没有样本的未来记录，仍可能通过当前脚本。

本次 run3/run5 分别有 39/41 条测量期观测，最大间隔 504/505 ms；目前这两组没有观测到此缺口。它们证明已记录的活动/电源状态，不保证每一时刻的前台状态、CPU 频率或无后台竞争。

建议为后续长性能 run 明确目标周期、允许最大中断和最低覆盖，独立记录监控缺口；不满足即标为无法证明全程前台。用保存的前台 CSV 构造缺失采样、过长间隔、仅 BEGIN/END 和状态失效四类反例验证门禁。阈值要在采集前确定，保留原始数据，不能为了让某次结果通过事后调整。

## 6. P2：重连配置契约需统一

Controller 第 368 行在绑定失败时使用 `reconnectAttempts < maxReconnectAttempts`；第 503–513 行在已连接后 Binder 死亡时直接设置 attempt=1 并调度重连。零次配置的行为不一致。

建议定义“零次”是否禁止所有自动重连，以及死亡后的第一次重新绑定是否计入上限，再让两个分支共用上限判断。验证零、一、多次上限，区分初始绑定失败、连接后死亡和业务显式 `connect`，并确认没有超过上限的定时任务。当前零次探针只覆盖首次绑定失败。

## 7. 按用户要求的顺序继续验证

### 7.1 生命周期 → 请求与流终态 → 协议兼容

修复冷发现时先用可控 Broker 阻塞点构造以下场景，再在 **925c23bb** 验证真实分进程 Binder 路径：

| 场景 | 需要验证的结果 |
| --- | --- |
| 从 Main 首次发起 Async，发现 RPC 被阻塞 | UI 仍能响应；调用方预算内超时/取消；阻塞任务数量有上限 |
| 发现阻塞期间另有已注册请求，然后 close/dispose | 已注册请求及时终结，解绑和代次作废完成，不等待 Schema RPC 返回 |
| close 后显式 reconnect，旧发现晚返回 | 旧调用失败，旧 Binder/元数据不写入新代次，不向新代次发送旧请求 |
| 同代次并发访问同一 Schema | 合并发现；失败不会永久占住进行中任务；不同 Schema 键不混用 |
| 发现异常、接口缺失、签名/版本不兼容 | 保持严格拒绝和原异常边界，不能降级绕过 Schema |
| owner 结束、调用方取消、远端死亡 | 清理路径和请求终态完整；遗留阻塞线程的限制与状态可观察 |

源码/受控夹具证明、小米设备证明分别记录。当前已有 52 PASS、12 guard PASS、32,000 次 IPC 成功属于原场景；新增故障场景需要单独验收。

### 7.2 性能优化：先分解墙钟，再选一个因素

下一次小米性能采集应关联 generation、requestId、客户端/服务端进程和线程，避免只保存一个 RTT 总值。建议记录：

1. 调用入口、发现开始/结束、pending 注册和发送前检查。
2. 客户端 transact 前/后、服务端收到请求、Job 排队与开始执行。
3. 业务开始/结束、回调提交、客户端收到回调、continuation 恢复后的首次执行。
4. 同时采集 Binder、线程运行/等待、CPU 频率以及可获得的 ART GC/JIT 事件；统一时间基准，跨进程按 requestId 关联，不比较各线程独立 CPU 计时器的绝对时间。

由这些点区分业务 CPU、Binder 提交/接收、服务端调度等待和调用方恢复等待。trace 本身有开销，应先核对开关差异，诊断采集与最终收益测试分别报告。

只有定位出占比和长尾来源，才决定优化 Tracker/死亡监听复用、调度、编码或回调处理。每次保留取消、UID 鉴权、Schema、代次和终态语义，采用同 APK 对称路径或固定场景交替 A/B；按多组合格 run 汇报配对结果和所有失败/失效记录。新增速度结论需要与完整语义的同场景测量绑定。

## 8. 本次产物与复算

- 新增问题报告、离线统计和图；优化总览、设备记录索引加入入口。
- 生产代码、APK 与已有原始设备记录保留；本次没有运行新构建或设备测试。
- 复算：`python docs/benchmarks/harness/analyze_guard_problems.py`，然后 `python docs/benchmarks/harness/plot_guard_problems.py`。绘图使用已有 `.gradle/plot-deps` Matplotlib；诊断 JSON 使用 Python 标准库。

当前最先应收束冷发现和关闭清理的关系，随后补足监控覆盖与请求关联 trace。局部成本下降可以保留，稳定端到端收益仍未证明。
