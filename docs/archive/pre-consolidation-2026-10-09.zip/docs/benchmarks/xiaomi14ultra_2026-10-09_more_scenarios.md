# 三个新增多 App 场景：实现与验收状态

## 1. 当前状态

已在原会议案例之外增加仓储工单、配置同步与遥测告警三个可操作场景。三个客户端通过统一场景选择器切换业务卡，默认仍为会议通知；隐藏场景也处理消息，切换场景不重新绑定或重放业务请求。

最新五应用统一构建 **BUILD SUCCESSFUL in 3m 22s，退出码 0，272 个任务**。日志与每个 APK/源码 SHA-256 见 [build-result.json](runs/2026-10-09-xiaomi14ultra/more-scenarios-build/build-result.json)、[gradle-build.txt](runs/2026-10-09-xiaomi14ultra/more-scenarios-build/gradle-build.txt)。本次完整生成的 Hub Schema 与修改前文件哈希一致；35 个 runtime、contract、compiler、annotations 文件与会议构建快照一致。这些是源码与构建证据，不是设备回归结果。

**本次安装与设备验收均为 NOT_RUN。** 2026-10-09 15:04（北京时间）检查指定小米 `925c23bb`，仍为 `device not found`，见 [device-state.json](runs/2026-10-09-xiaomi14ultra/more-scenarios-build/device-state.json)。没有使用其他设备。旧会议构建、crosspkg1、框架回归或 echo 性能不能替代新场景验收。

## 2. 新场景与终态

| 场景 | 实现的业务链 | 业务终态 |
| --- | --- | --- |
| 仓储工单 | client1 定向分派 → client2 接单 → 用户点击完成 → client1/client3 观察 | completed；accepted 只是接单。完成态不被迟到 accepted 倒退。 |
| 配置同步 | client1 广播版本与卡片主题/字号 → client2/client3 独立应用 → 各自定向确认 | 收齐两个来源的同 ID、版本与内容确认；一端成功不足以认定全部同步。 |
| 遥测告警 | client2 发预置温度样本 → client3 判断 30°C 阈值 → 告警广播至 client1/client2 | 指定异常样本的告警可见；正常样本不生成新告警，已有告警不自动解除。 |

完整角色、载荷、架构图、三个流程图和三个时序图见[场景目录](../ModernIPC_Multi_App_Scenarios.md)。这些图表示实现路径，不是本次设备轨迹。温度为按钮预置的 25/35°C 演示值；工单不扣减真实库存，配置只改变本 App 的演示卡样式。

## 3. 源码与审查

- [MultiAppScenarioMessage](../../ipc-api/src/main/kotlin/com/cn/ipc/api/hub/MultiAppScenarioMessage.kt)：独立 JSON 载荷族与版本；检查场景/kind 配对、ID、标题/详情、整数类型与范围，不改变 Hub Binder 接口。
- [MultiAppScenarioDemo](../../demo-client-common/src/main/kotlin/com/cn/ipc/client/common/MultiAppScenarioDemo.kt)：三个角色业务卡、工单状态机、有界 64 条记录、配置版本校验、双端确认和阈值分析。
- [BaseClientActivity](../../demo-client-common/src/main/kotlin/com/cn/ipc/client/common/BaseClientActivity.kt)：四场景目录、业务消息路由、捕获代次的发送入口；DEBUG Intent 复用按钮业务方法，消费后清除，select 动作只切换可见卡。

独立静态复审检查了完成先于接单的顺序、路由回包晚于业务确认、双端确认来源去重、旧代次发送/接收拒绝、整数 JSON、隐藏卡处理与深色文字对比，未发现新增确定缺陷。静态复审不能证明设备上的业务链、实际绘制或后台稳定性。

每场景最多一个主动操作和一个自动回复等待者。新自动回复取消旧等待；已开始的 Binder 操作仍可能远端完成。案例不提供所有连续样本可靠交付、离线补发或持久幂等。

## 4. 自动采集与本地验证

[capture_multi_app_scenarios.py](harness/capture_multi_app_scenarios.py) 固定设备 `925c23bb`，还检查已记录的小米型号身份；系统 fingerprint 保存但不固定，以便区分 OTA。执行前要求已安装四包哈希与本地 APK 一致、UID 不同、真实进程身份、亮屏与未锁屏。

| 计划阶段 | 必须通过的证据 |
| --- | --- |
| 工单接单 | client2 业务卡应用，client1/client3 接单确认；原始 assign 不派发观察端。 |
| 工单完成 | 三端同 ID 的完成状态。 |
| 已完成工单重发 | 同 ID/载荷/版本重发 assign，出现新的 completed 确认日志，三端不倒退。 |
| 配置版本 1 | light/14，两端应用及两个独立来源确认。 |
| 配置版本 2 | dark/18，新版本双端确认完成。 |
| 正常温度 | 25°C 到分析端，无该样本告警的有限窗口观察。 |
| 高温样本 | 35°C 到分析端，两端关联告警可见。 |
| 场景切换后返回 | 本次 Activity 中工单完成状态保留。 |

这些是 **8 项计划，不是 8 项设备 PASS**。UI 门槛只检查唯一的 `scenario-<scenario>-status` TextView，不能用普通日志文本冒充更新；重发阶段要求后续新日志行。配置事件与 UI XML 不证明颜色和字号的实际像素呈现。

Python 编译、三个既有/新增采集入口的源码契约检查通过。脚本的离线数值/身份解析和 UI 假阳性检查通过。新场景默认 prepare 在不可用 ADB 名下成功，没有调用设备；当前构建对应的准备记录见 [scenariosprepare-current1/capture-plan.json](runs/2026-10-09-xiaomi14ultra/multi-app-scenarios-scenariosprepare-current1/capture-plan.json)。较早 prepare 快照保留，但不能替代这个源码/APK 身份。

另同步修正原 cross-package smoke 对过时订阅文案的校验；它仍只检查连接、登记和本地订阅启动，不证明远端 collector 消费。

## 5. 待执行与边界

设备恢复后，先按[接入步骤](../ModernIPC_Business_Interaction_Guide.md#4-构建启动与操作)安装本次四包，再用新 run-id 执行：

```powershell
python docs/benchmarks/harness/capture_multi_app_scenarios.py --run-id scenarios1 --execute
# 原会议案例也应回归，使用新 APK 身份和新目录。
python docs/benchmarks/harness/capture_multi_app_case.py --run-id meetingnew1 --execute
```

采集日期默认实际当天，准备目录不复用。失败保留原始日志和现场，不覆盖。负向隔离/无告警仅覆盖对应 commandId 的 3 秒窗口；前台与 keyguard 快照不证明持续同时前台。

配置旧版本、冲突拒绝与部分确认缺失、迟到接单、断线、重建及连续高频样本是额外手工/诊断验收，未记入上述自动覆盖。正常发布路径先拒绝某些冲突，不能将发布端拒绝当作接收端拒绝证据。

此前新增握手与框架/trace 的最终小米回归仍待完成，见[前序验收步骤](runs/2026-10-09-xiaomi14ultra/handshake-build/next-steps.md)。源码未变不等于这些设备门槛已通过。

所有记录与版本保存在当前 Activity 内存中，重建后丢失；路由 OK 不表示消费，业务确认表示页面数据处理而非硬件执行或持久提交。本次不提供业务耗时或两库性能排名。
