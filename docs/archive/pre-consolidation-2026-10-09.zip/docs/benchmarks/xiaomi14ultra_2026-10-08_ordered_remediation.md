# 小米：生命周期、终态、兼容与性能顺序修复

日期：2026-10-08。测试限定 Xiaomi 14 Ultra（925c23bb、Android 16）。按“生命周期 → 请求与流终态 → 协议兼容 → 性能优化”逐阶段构建、安装、验证。各阶段 APK/源码哈希独立保存，不把不同 APK 的结果当作同一版本。

## 阶段 1：生命周期

### 改动

- Controller 使用独立控制 scope 完成绑定/清理，owner 最终结束后自动 dispose；同步握手移出状态机锁，迟到结果需要验证连接实例。
- close/closeAndJoin 关闭当前连接且允许重连；dispose/disposeAndJoin 永久释放并进入 Disposed，结束本地 Flow，拒绝再连接。
- Pending 关闭时向捕获的原 Binder 发送一次取消；成功回复不会误发取消。
- 每连接代次独立 Flow observer，过滤旧事件；退订使用订阅时捕获的 Binder/subId。
- Registry 在 Service.onDestroy 释放生成 Stub，取消请求、订阅及宿主 scope。计数在 Job 完成后移除。
- 覆盖空绑定/绑定失效回调及绑定超时；示例 Activity 将 Controller 归属其生命周期，UserServiceImpl 的广播退出 GlobalScope。

### 小米门禁

生命周期探针 lifecycle1：22 条 PASS、1 条 DONE、没有该 run 的 FAILED。客户端 PID 12286，服务端 PID 18811；原始时间范围 10:29:33.710–10:29:39.287，详见日志。

| 场景 | 实际结果 |
| --- | --- |
| 8 轮同实例关闭/重连，服务由锚定连接保活 | 每次关闭后请求/订阅 0，事件静默；重连后订阅恰为 1，generation 递增 |
| 真实挂起请求关闭 | 本地失败、服务端请求计数归零 |
| 永久 dispose | 外部 collector 结束、两端计数归零、再次连接被拒绝 |
| owner Job 最终结束 | 独立控制 scope 完成释放、请求失败、流结束、事件静默 |
| 最后绑定解除导致 Service 销毁 | 旧业务 Binder 仍存活，但 Stub 拒绝调用；重绑获得新 Stub，计数 0 |
| NullBindingService | 3 ms 内进入 Disconnected，早于配置的 5000 ms 超时 |
| DelayedBindingService | 配置 200 ms，206 ms 进入 Disconnected；迟到回调没有恢复连接 |

两项绑定失败探针的 pending 是本地合成等待项；它们验证状态机清理，不代表发出了业务 RPC。其余请求及订阅回收使用真实远端 Stub 的计数。没有用提前 clear map 制造归零。

### 产物与范围

Debug APK SHA-256：59ACE43ADCF5C9275AC62FDFC9DB366DECD530765BD371B47BC563D2DE10BAB3。安装后拉取 base.apk，哈希与本地产物相同。五个演示应用 assembleDebug 通过。

[证据与源码哈希](runs/2026-10-08-xiaomi14ultra/ordered-lifecycle/evidence.json)、[Logcat](runs/2026-10-08-xiaomi14ultra/ordered-lifecycle/logcat.txt)、[进程](runs/2026-10-08-xiaomi14ultra/ordered-lifecycle/processes.txt)、[电池](runs/2026-10-08-xiaomi14ultra/ordered-lifecycle/battery.txt)。

边界：owner 自动释放触发于 Job 最终完成；阻塞子任务可能延后该时点，显式 dispose 独立于它。dispose 不承诺中断已开始的同步 Binder 调用或非协作业务。onBindingDied 分支构建覆盖，本轮未制造系统绑定失效事件。示例广播改为宿主 scope 属于源码证明，探针计数不覆盖所有业务自建任务。

## 阶段 2：请求与流终态

### 改动与小米门禁

注册后的 Async RPC 默认截止时间为 30 秒，Controller 可配置；超时移除 pending 并向原 Binder 发送取消。有限 Flow 发 COMPLETE（observer code 2），业务失败发 ERROR（code 3、String），原 NEXT code 1 保持布局。客户端终态只接受一次；默认缓冲满时结束流并显式报错，`overflowPolicy = CONFLATE` 明确允许合并状态值。主动取消及 observer 死亡安静退订。

terminal1：8 条 PASS、DONE，日志 10:42:57.707–10:42:59.651，客户端 PID 18618。

| 场景 | 实际结果 |
| --- | --- |
| 有限流 | 收到 1、2、3，正常结束 |
| 运行时失败 | 收到 7 后以 flow-runtime-error 结束 |
| 慢消费者、默认 ERROR | 消费 69 项后收到溢出异常，订阅归零 |
| 慢消费者、CONFLATE | 合并消费 4 项，末值 999，正常结束且订阅归零 |
| 显式取消 | 无附加错误，两端清理 |
| 配置 150 ms RPC 截止 | 实测 155 ms，真实服务端 Job 从 1 到 0，pending 0 |
| 可识别 raw null 请求 | 立即 String 错误回调 Missing payload |
| 坏 Token 无回调 | 实测 153 ms 截止，不留下 pending |

Debug APK SHA-256：14124F10BA7417152BF7380E88F429638ED5BCA9C95142DE6F2846ABF6E150A1。本地产物与已安装 base.apk 相同，五应用 assembleDebug 通过。

[证据](runs/2026-10-08-xiaomi14ultra/ordered-terminals/evidence.json)、[日志](runs/2026-10-08-xiaomi14ultra/ordered-terminals/logcat.txt)。

范围：截止覆盖注册后的 RPC 等待；同步冷服务发现、Direct 和已经开始的同步 transact 不会被这个超时中断。Parcelable 请求先鉴权再反序列化，无法安全识别回调的非法帧依赖客户端截止。源 SharedFlow 的 DROP_OLDEST 仍可能先丢值，终态和 CONFLATE 不构成可靠投递保证。

## 阶段 3：协议兼容

### 改动

保留 ClientHello/ProtocolInfo 布局及 Broker 原方法编号，增加 Schema 元数据（AIDL 显式编号 3）和严格获取（4）。显式编号的实际 Binder code 为 FIRST_CALL_TRANSACTION + 编号，即 4/5。握手能力改为请求与真实支持能力的交集。

KSP 共享 WireTypeModel 校验及生成双端 codec，生成 IpcSchema 描述每个事务的参数、返回、调用模式、标志、响应信封与关联取消/退订事务。Generated Stub 提供元数据；Controller 本地检查后 Broker 再校验，允许服务器增加事务。客户端快照/fingerprint 构造时计算，手写 Parcelable 发送同一快照；缓存包含 generation、serviceId、minApiVersion、fingerprint，热路径没有重复 metadata RPC 或整份 hash。

用户与消息中枢服务要求最低客户端契约版本 2；旧 getService 无法验证实际客户端版本，因此拒绝这些服务。Echo floor 1 保留旧发现作为测试入口。旧 Broker 缺 Schema 方法或未协商能力时严格代理明确失败，不自动降级。业务校验拒绝使用可传输的 IllegalArgumentException，鉴权仍使用 SecurityException，客户端 wire 不兼容为 IpcCompatibilityException。

### 小米门禁与排查过程

compat3：16 PASS、DONE，11:04:19.252–11:04:19.351，客户端 PID 22162，最后 pending/requests/subscriptions 均 0。

| 场景 | 实际结果 |
| --- | --- |
| metadata | 17 个事务签名与生成契约匹配 |
| 旧 v1 单事务子集 | 接受且真实 echo 成功，允许额外服务端事务 |
| 参数、返回、模式、信封、缺失事务、descriptor、未来客户端版本 | Broker 与 Controller 均拒绝 |
| 相同 serviceId 的不同 Schema | 不借用已验证缓存，合法子集仍接受 |
| 构造后修改原 Map | 指纹不变，Broker wire 与 Controller 使用旧快照；copy 新 Map 后两端拒绝 |
| 旧发现入口 | user floor 2 拒绝、echo floor 1 接受 |
| 100 次生成 Direct 热调用 | metadata=1、checked=1，无额外发现或 legacy 事务 |
| 同 Stub 锚定后的关闭/重连 | generation 递增，metadata/checked 各从 1 到 2 |
| 旧 Broker 方法可用性模拟 | 3/4 缺失；严格客户端失败，legacyFallbacks=0 |

首次 compat1 真机发现 Broker 的 RemoteException 无法由 Parcel.writeException 编码，客户端得到空返回。已修为标准异常，保留[初次失败日志](runs/2026-10-08-xiaomi14ultra/ordered-compatibility-initial-failure/logcat.txt)。compat2 在已通过 14 项后暴露夹具断言错误：未知 AIDL 方法可能返回 null，而非必定抛异常；修正不可用结果判断，并让 Controller 明确检查 null，保留[夹具记录](runs/2026-10-08-xiaomi14ultra/ordered-compatibility-legacy-fixture/logcat.txt)。最终完整门禁通过。

Debug APK SHA-256：CEA7244D318B31786621AD19B93EAEA7F9C0BD5969A7D1F5C5DAF472E3E24FD2，安装哈希一致，五应用 assembleDebug 通过。[证据](runs/2026-10-08-xiaomi14ultra/ordered-compatibility/evidence.json)、[日志](runs/2026-10-08-xiaomi14ultra/ordered-compatibility/logcat.txt)。

范围：旧 Broker 为同 UID 方法可用性夹具，不是历史 APK 的完整升级矩阵；本轮未测试跨 UID 授权变更。Parcelable 的 FQCN 仍是 opaque 类型标识，无法证明 DTO 内部字段布局兼容。apiHash 标签未用作校验，session/nonce 未绑定业务或提供防重放。协议保持静态注册，不支持运行中修改服务版本。

## 阶段 4：性能优化

### 改动与比较方法

PendingCallRegistry 将每个请求的三个 AtomicBoolean 合并为一个 AtomicInteger，位 1/2/4 分别为 DISPATCHED、ABORTED、CANCEL_SENT。OR-CAS 只置位；取消只有在已发送且已中止时执行，CAS 赢者发送一次取消。正常即刻回复不标记中止。位常量在文件级定义，避免被每个请求的闭包捕获。请求限额、截止、鉴权、死亡监听与服务端调度保留。

冻结阶段 3 的完整 Registry 为 demo-only LegacyPendingCallRegistry；只改 package/class/private-record 名字，反向替换后字节与原源码一致。原 SHA-256 为 686065E9D7304328327085E2CBE04E17703AAB4FCA0BB4447AB649B132833B1F。两版通过同一 PendingBenchmarkPort 测量，没有仅测位运算循环。

三组 pendingperf1、pendingperf2、pendingperf3awake **使用同一 APK**，没有重新构建：49C58DAA156DA8CEE1A79AAD11033D78DC65860680F3FEC27F70948AFC5DC4B4。三次拉取已安装 base.apk，均与本地产物一致。每组：

- 本地立即回复与 Parcel 回复各 2000 次预热/版，ABBA 四个 TIME 块与四个 ALLOC 块，每块 50000 次完整注册、回复、续体和截止计时器清理。TIME 为单个测量线程 CPU；ALLOC 为整个客户端进程近似增量，包含其他线程。
- 两版各 6 个竞态 PASS：回复早于发送返回、断连发生于发送中、调用方取消发生于发送中、1000 轮回复/断连竞争、取消 hook 抛错、30 ms 默认截止。功能检查在计时区域之外。
- 真实 IPC 四轮 ABBA，16/1024 字符，每块 50 次预热 + 1000 次采样，共 16 个 CSV。两版共用同一个业务 Binder、回调 Binder、编解码及调用上下文。切换前 pending 与真实服务端 Job 均归零。

真实 IPC 比较的是**相同 wire 的完整 Registry 路径**，没有包括生成 ClientAdapter 每次的缓存查询和连接检查；不是新一轮 AndLinker 比较。

### 设备状态与证据边界

不能将本轮性能记录标为受控前台验收。前两组没有保存电源/Activity 快照。第三组开始 power 为 Awake，但 Activity 快照已有 isSleeping/PAUSING；结束采集晚于 DONE，power 为 Dozing、Demo Activity 为 STOPPED。目录名 awake 只表示唤醒尝试，不能证明整个采样窗口保持唤醒或前台。三组分别保留，不将它们合成一个前台优化收益。

第一次最终 lifecyclefinal 没有完成，日志仅到第二轮重连，随后现场为 Dozing/STOPPED；记录在[中断现场](runs/2026-10-08-xiaomi14ultra/ordered-final-dozing)。这证明该次门禁未完成和采集时设备状态，不能单独定位停顿原因。后续完整回归全部通过，见下节。临时充电保持唤醒设置原值 0，完成后已恢复 0，前后值均保存。

### 分配和 CPU

数值为每种实现两个块的每调用均值的中位数。CPU 单位 μs/调用，近似分配单位 bytes/调用；百分比为优化相对基线变化。

| 组 | 本地路径 | CPU 基线 → 优化 | 近似分配基线 → 优化 | 分配变化 |
| --- | --- | ---: | ---: | ---: |
| pendingperf1 | 立即回复 | 34.97 → 30.85 | 897.19 → 849.67 | -5.30% |
| pendingperf1 | Parcel 回复 | 39.09 → 37.99 | 929.63 → 881.30 | -5.20% |
| pendingperf2 | 立即回复 | 35.50 → 31.43 | 897.52 → 849.51 | -5.35% |
| pendingperf2 | Parcel 回复 | 41.18 → 40.61 | 929.46 → 881.30 | -5.18% |
| pendingperf3awake | 立即回复 | 31.20 → 27.36 | 896.70 → 849.18 | -5.30% |
| pendingperf3awake | Parcel 回复 | 34.67 → 32.12 | 929.30 → 880.97 | -5.20% |

三组局部分配差额约 48 bytes/调用，与减少状态对象及闭包引用的源码方向一致；这是本轮可报告的分配改善。不能把进程级近似统计称为逐对象精确分配或全应用内存下降。CPU 汇总较低，但立即回复第一/最后基线块明显漂移（首组约 40.6 → 29.3 μs），仍有 JIT、调度与测量顺序因素，未证明固定稳态 CPU 收益。

### 实际 IPC 延迟与长尾

每组摘要为四轮 P50 的中位数，单位 ms，均 16000 条有效样本、零失败、无意外回调，结束时 requests/subscriptions/pending 为 0。

| 组 | 字符数 | 基线 | 优化 | 变化 | 四个配对变化 % |
| --- | ---: | ---: | ---: | ---: | --- |
| pendingperf1 | 16 | 0.566 | 0.494 | -12.79% | -6.57 / -36.79 / -1.84 / -22.50 |
| pendingperf1 | 1024 | 0.590 | 0.545 | -7.64% | -7.43 / +32.16 / -18.57 / -43.88 |
| pendingperf2 | 16 | 0.762 | 0.501 | -34.31% | -32.10 / +13.42 / -44.76 / -36.33 |
| pendingperf2 | 1024 | 0.766 | 0.584 | -23.68% | +0.82 / -19.57 / -45.58 / +8.95 |
| pendingperf3awake | 16 | 1.409 | 1.450 | +2.94% | -7.86 / +6.13 / -62.06 / +9.60 |
| pendingperf3awake | 1024 | 1.486 | 1.408 | -5.27% | -2.82 / -8.14 / -1.38 / -9.53 |

前两组 16 个配对有 4 个 P50 变慢，第三组又有 2 个变慢；三组间基线明显变化。第三组基线 16 字符第 2 轮最大值 **6411.066769 ms**，优化 1024 字符第 2 轮最大值 34.753125 ms，全部保留在原始 CSV。该组 16/1024 字符优化 P99 分别为 3.230–4.877 / 4.816–10.414 ms。没有 Perfetto 或单次链路分段证据定位上述长尾，不能据此认定原子状态、Dozing、Binder 或特定调度器是唯一原因。

结论：**源码减少了两个原子状态对象，本地近似分配约少 48 bytes/调用；真实 IPC 未证明稳定端到端加速。** 当前差异不用于生产吞吐承诺、后台时限保证或与历史 AndLinker APK 的速度排名。

![第三组分配、测量线程 CPU 与逐轮 IPC P50](runs/2026-10-08-xiaomi14ultra/ordered-performance-awake/pending-performance.png)

| 数据 | 证据、日志、逐轮 P50/P90/P99/max 与 CSV |
| --- | --- |
| pendingperf1 | [目录](runs/2026-10-08-xiaomi14ultra/ordered-performance)、[复算](runs/2026-10-08-xiaomi14ultra/ordered-performance/analysis.json) |
| pendingperf2 | [目录](runs/2026-10-08-xiaomi14ultra/ordered-performance-repeat)、[复算](runs/2026-10-08-xiaomi14ultra/ordered-performance-repeat/analysis.json) |
| pendingperf3awake | [目录](runs/2026-10-08-xiaomi14ultra/ordered-performance-awake)、[复算](runs/2026-10-08-xiaomi14ultra/ordered-performance-awake/analysis.json) |

## 最终 APK 功能回归

五个示例应用 assembleDebug 通过。最终同 APK 再次验证 **52 PASS + 四条 DONE**，所有日志无该 run 的 FAILED，安装 SHA 与本地产物同为 49C58DAA156DA8CEE1A79AAD11033D78DC65860680F3FEC27F70948AFC5DC4B4。

| 门禁 | PASS | 原始证据 |
| --- | ---: | --- |
| 生命周期 lifecycleawake | 22 | [日志及哈希](runs/2026-10-08-xiaomi14ultra/ordered-final-lifecycle-awake) |
| 请求与流终态 terminalawake | 8 | [日志及哈希](runs/2026-10-08-xiaomi14ultra/ordered-final-terminals-awake) |
| 协议兼容 compatawake | 16 | [日志及哈希](runs/2026-10-08-xiaomi14ultra/ordered-final-compatibility-awake) |
| 故障路径 faultawake | 6 | [日志及哈希](runs/2026-10-08-xiaomi14ultra/ordered-final-fault-awake) |

最终终态复测：150 ms 截止实测 159 ms，坏 Token 无回调实测 157 ms；溢出消费 72 项后报错，CONFLATE 消费 11 项、末值 999，两端计数归零。这些计数随调度改变，不是固定容量或吞吐指标。最终结束快照仍为 Dozing/STOPPED，功能成功不能推广为任意后台时机的稳定完成保证。

## 复现入口

固定 Xiaomi serial，单设备安装/运行，避免省略 `-s` 后误测其他连接设备。构建使用 JDK 17：

~~~powershell
.\gradlew.bat :demo-app:assembleDebug :app-server:assembleDebug :app-client1:assembleDebug :app-client2:assembleDebug :app-client3:assembleDebug --offline --quiet --max-workers=1 '-Pkotlin.compiler.execution.strategy=in-process'
adb -s 925c23bb install -r demo-app/build/outputs/apk/debug/demo-app-debug.apk
adb -s 925c23bb shell am force-stop com.cn.ipc.demo
adb -s 925c23bb logcat -c
adb -s 925c23bb shell am start -n com.cn.ipc.demo/.MainActivity --es ipc_benchmark pendingperf1
~~~

确认 IpcPendingBench 的 DONE 后，[capture_ordered.py](harness/capture_ordered.py)冻结源码/安装哈希及日志；[pull_pending.py](harness/pull_pending.py)按字节提取 CSV；[analyze_pending.py](harness/analyze_pending.py)检查数量/失败并复算；[plot_pending.py](harness/plot_pending.py)从 JSON 绘图。功能前缀分别为 lifecycle、terminal、compat、fault。正式前台性能验收还需确认并记录解锁、Demo 为 RESUMED、整个窗口电源状态及系统负载，不能只依赖目录名或启动命令。
