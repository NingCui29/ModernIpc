# 小米故障路径排查与回归（2026-10-08）

## 环境与产物

仅 Xiaomi 14 Ultra（925c23bb、24031PN0DC、Android 16）实测；最终两轮故障回归为北京时间 09:33:40–09:33:52。第二轮前电量 41%、温度 33.0°C。Debug 同包不同进程：正常回归主进程 PID 3362、服务端 PID 4519；见[进程记录](runs/2026-10-08-xiaomi14ultra/fault-paths/processes.txt)。

APK SHA-256：A27BE6B70E9B4D4F962B4EABD9B2A6369DBE604D0E3C2594F522A8C24F6915BD。本地 APK 与设备拉回的 base.apk 一致。[源码哈希清单](runs/2026-10-08-xiaomi14ultra/fault-paths/evidence.json)绑定本轮源码；[原始日志与 CSV](runs/2026-10-08-xiaomi14ultra/fault-paths/)可复核结果。早期 fault1/fault2 使用较早测试探针，未合入最终统计。

## 问题、修复和证据边界

| 问题 | 原因与修复 | 本轮证据 |
| --- | --- | --- |
| 成功完成后多发 cancel | callSuspend 发送 block 返回时 !isActive 包含成功完成；改为 isCancelled | 小米客户端注册表内同步完成请求，cancel hook 为 0 |
| 完成/断连重复恢复 | failAll 的 iterator.remove 未取得恢复所有权；发送异常 catch 同样忽略移除结果；两处改为移除成功后恢复 | 最终 APK 两轮各 1000 次注册表回复/断连竞争，终态仅接受 ok 或 lost，迟到结果均拒绝；未出现重复恢复 |
| 请求跨连接代次发送 | generation 与 Binder 分开读取；绑定同一 Connected 快照，登记后取 Binder 前后校验身份，断连先发布非 Connected 再清理 | 合成 pending 在 close 后失败；重连后旧快照请求明确拒绝，新 Flow 正常 |
| 迟到查询污染共享缓存 | 缓存只按 serviceId；改为 generation/serviceId，过期查询完成后丢弃 | 生成代码与运行时源码检查；未阻塞 Broker 查询制造该交错，不能声称此竞态已经实测 |
| Flow 工厂错误被当订阅 ID | 客户端未读系统异常，且吞掉所有错误；双方新增标准异常头，永久失败 close(error) | 真实远端工厂抛 IllegalArgumentException，客户端收到 flow-factory-error，正常订阅首项为 0 |
| 活跃订阅一直持有请求 Parcel | 请求 finally 原来包围整个 awaitCancellation；改为订阅事务结束后立即回收 | 生成源码检查；未做 Parcel/native 内存计数实验 |
| 方法注解与事务形状缺少校验 | 缺注解、错误 Async/Stream/Oneway 形状可生成无效事务；新增恰好一种注解、形状和事务范围检查 | 五个演示应用构建通过；本轮未增加负向编译 fixture |

客户端显式取消和发送 block 内取消分别验证 cancel hook 一次。这是本地注册表测试，不能推导远端 Job 已取消、死亡监听已释放。reply/断连竞争由门闩同时释放两个任务，调度器决定交错；1000 轮不是对所有线程时序的穷举证明。

## 修复后的流程

~~~mermaid
flowchart TD
    A[捕获 Connected 快照] --> B[按快照 generation 登记请求]
    B --> C{取 Binder 前后仍是同一快照}
    C -- 否 --> D[原子移除请求并返回连接错误]
    C -- 是 --> E[发送到该代次 Binder]
    E --> F{终止事件}
    F -- 回复 --> G[原子移除后恢复结果]
    F -- 取消 --> H[移除并至多发送一次原代次 cancel]
    F -- 断连 --> I[先更新连接状态 再原子移除并失败]
    G --> J[后到事件找不到请求 忽略]
    H --> J
    I --> J
~~~

Flow 订阅握手为标准异常头 + subId；成功 ID 收到后立即回收请求和回复 Parcel，保留 observer 与订阅 Job。工厂、token 或同步订阅错误传播到收集者。Binder 死亡保留等待下一 Connected 代次的策略。

IUserService 与 IMessageHubService 的 minApiVersion/注册 apiVersion 升至 2，apiHash 分别 user_v2/hub_v2。双端生成代码必须同步升级；旧版订阅回复不可混用。基准 echo 保持 v3。API 升级并不为旧客户端提供新的 wire-format 兼容层。

## 构建与设备回归

五个应用 assembleDebug 通过，随后单独重建 demo-app，确保测试探针的结果校验、超时及父 Job 修正进入最终 APK。git diff --check 通过。构建使用本机 JDK 17、offline、max-workers=1 和 in-process Kotlin 编译。

复现设备故障测试：

~~~powershell
adb -s 925c23bb install -r demo-app/build/outputs/apk/debug/demo-app-debug.apk
adb -s 925c23bb shell am force-stop com.cn.ipc.demo
adb -s 925c23bb shell am start -n com.cn.ipc.demo/.MainActivity --es ipc_benchmark faultfinal1
adb -s 925c23bb logcat -d -s IpcFaultProbe:I IpcEchoBench:E '*:S'
~~~

待第一轮 DONE 再 force-stop、以 faultfinal2 重启。每轮 6 组 PASS + DONE，涵盖即时回包、显式取消、发送期间取消、1000 轮完成/断连竞争、远端 Flow 工厂异常和关闭/重连。整个探针限制 30 秒。

另以 chaincheck1 运行正常 echo，4 种模式/负载各 1000 次，合计 4000 次计时调用无失败，错误 token、缺失参数、业务错误及基本类型烟测仍通过。计时包括结果检查，各预热 50 次；只有一轮，作为功能回归，不证明相较上一 APK 的性能变化。

| 负载字符数 | 模式 | P50 ms | P99 ms |
| --- | --- | ---: | ---: |
| 16 | suspend | 0.552500 | 2.280000 |
| 16 | direct | 0.267656 | 0.484740 |
| 1024 | suspend | 0.756302 | 1.552552 |
| 1024 | direct | 0.404219 | 0.578645 |

## 已定位但仍需专项修复/验证

1. Flow 的 collect 异常与正常 completion 尚无终止事件，客户端可能继续等待；本轮只修复创建/订阅阶段错误。
2. 控制器 scope 已取消后 close 使用同一 scope.launch，可能不执行清理；不能直接 close 后立即取消该 scope。
3. onNullBinding/onBindingDied 尚未处理，服务返回 null Binder 可停在 Binding。
4. 非 direct 参数的 nullable/Parcelable 支持缺少完整形状校验；例如 async String? 的 null 参数可在服务器读 callback 前抛错，客户端等到外部超时。
5. 服务端 scope 已取消时 IpcRequestTracker 的 LAZY Job 可能直接取消且无业务回调。

此外，真实在途请求遭服务端进程死亡、跨 UID 取消/权限拒绝，以及资源与死亡监听长期计数尚未纳入本轮设备验收。
