# 小米：Async 发送前检查优化

日期：2026-10-08。设备限定 Xiaomi 14 Ultra（925c23bb、24031PN0DC、Android 16）。本轮承接[生命周期、终态、兼容与 pending 状态修复](xiaomi14ultra_2026-10-08_ordered_remediation.md)，仅精简 Async 发送前重复查询；不沿用前序 APK 的功能或性能数字作为本轮验收。

## 1. 发现与改动

生成 Async 代理先获取连接快照，完整解析服务并捕获 `_binder`。注册 pending、编码后，原代码再次执行 `getServiceBinderForConnection`，却丢弃第二次返回的 Binder，仍向原 `_binder` 发送。温缓存时多构造一个 ServiceBinderKey，查询 serviceVersions 与业务 Binder 缓存；缓存失效时甚至可能再次发现服务，但依然发送原 Binder。

本轮将第二次完整查询改为 `checkServiceBinderForConnection(connection, capturedBinder)`：

1. 检查仍为同一 Connected 实例且 Controller 未 dispose。
2. 检查捕获 Binder 的 isBinderAlive。
3. 再检查连接实例和 dispose，覆盖存活检查期间关闭的情况。

首次完整版本/Schema 校验、冷发现、请求截止、取消、鉴权、回调、服务端调度与死亡监听保留。guard 失败由 PendingCallRegistry 摘除本地等待项；不自动获取新 Binder、重放请求或向新代次取消旧请求。guard 到 transact 之间仍可能断连或死亡，必须处理事务失败，不能保证远端未执行或回滚副作用。

源码：[生成器](../../ipc-compiler/src/main/kotlin/com/cn/ipc/compiler/ClientAdapterGenerator.kt)、[Controller](../../ipc-runtime-client/src/main/kotlin/com/cn/ipc/client/IpcConnectionController.kt)、[本轮基准](../../demo-app/src/main/kotlin/com/cn/ipc/demo/IpcGuardBenchmark.kt)。

```mermaid
sequenceDiagram
    participant A as Async 代理
    participant C as Controller
    participant P as PendingCallRegistry
    participant S as 远端 Stub
    A->>C: 首次完整解析服务与 Schema
    C-->>A: 捕获连接与业务 Binder
    A->>P: 注册 continuation、截止与取消
    A->>A: 编码请求
    A->>C: 检查原连接、dispose、原 Binder 存活
    C-->>A: 检查通过
    A-)S: Oneway transact
    S-)P: 原回调 Binder 返回结果
    P-->>A: 恢复调用方
```

## 2. APK、构建与前台门禁

最终 Debug APK SHA-256：`30ED4B9762422AFEBF5DBA9DEEBB125C81921EA60C5C766A7B53EEAE01A1782D`。五个应用 assembleDebug 通过。本轮合格性能记录与最终四组功能记录均使用此 APK，设备拉取的 base.apk 与本地产物一致；各目录 evidence.json 保存源码哈希。

前序开始快照含 PAUSING、锁屏显示及 NotificationShade 焦点，说明 Awake 并不保证 Demo 在前台。新 demo-only [BenchmarkForegroundSession](../../demo-app/src/main/kotlin/com/cn/ipc/demo/BenchmarkForegroundSession.kt) 在三次连续 100 ms 检查合格后开始，要求 RESUMED、窗口焦点、interactive、keyguard/device unlocked。仅基准期间设置 KEEP_SCREEN_ON，finally 恢复原窗口标志，不修改系统充电保持唤醒设置。

开始至结束记录 onPause/onStop/focus loss 等事件，并每 500 ms 采样应用可观察状态；任何失效标记整轮无效，不自动重启或删除已测数据。此机制的证据范围是应用生命周期事件、周期快照和独立 dumpsys，不能证明恒定 CPU 频率、无后台负载或完全消除调度波动。

| 合格性能记录 | 应用状态观察 | 独立开始/结束快照 | 电池温度与 Thermal Status |
| --- | --- | --- | --- |
| guardperf3 | 39 次 BEGIN–END 观察，最大间隔 504 ms，全部合格 | Awake，Demo topResumed | 开始 31.4 °C，结束 Thermal Status 0 |
| guardperf5 | 41 次 BEGIN–END 观察，最大间隔 505 ms，全部合格 | Awake，Demo topResumed | 开始 31.9 °C，结束 Thermal Status 0 |

两组设备电量均 100%、供电状态保存于 battery 文件。窗口保持唤醒仍受前台条件约束；本轮没有借此绕过锁屏验证。[Android 保持屏幕唤醒说明](https://developer.android.com/develop/background-work/background-tasks/awake/screen-on)

## 3. 同 APK 比较方法

两条路径共存于同一 APK：lookup 模拟旧发送前完整查询，guard 使用新检查。两条真实 IPC 路径共用首次严格服务解析、PendingCallRegistry、全局响应 Binder、String codec、捕获 Binder 的取消及实际服务端 Stub；唯一切换项是发送前的 recheck。生成代理正常返回也单独验证。

- 局部步骤：每种路径 20,000 次预热，单测量线程；TIME 与 ALLOC 分开，每类四个 ABBA 块，每块 500,000 次。TIME 是该线程 CPU，ALLOC 是整个客户端进程 ART bytes-allocated 的近似增量，仅覆盖第二次查询/guard 步骤。
- 实际 IPC：四轮 ABBA，轮间交替 16/1024 字符顺序；每块 50 次预热、1000 次采样，共 16 个 CSV。每次计时包含首次严格解析的温缓存检查、注册、编码、发送、远端请求跟踪/执行、回调与续体恢复。切换前 pending 和真实远端请求数归零。
- 每个合格 run：6 项 guard 检查、16,000 次成功 IPC、零失败，结束 requests/subscriptions/pending 均为 0。两组共 32,000 次成功 IPC、12 项 guard PASS。

该 harness 手写对称的生成协议调用，用于隔离第二次检查；不是完整旧版 APK 对新版 APK比较，也没有本轮 AndLinker 配对。调用上下文仍为 Default，没有采用全局 Unconfined 或 Direct 替换。

## 4. 分配与局部 CPU

数值为每条路径两个块的每步骤均值的中位数。

| 记录 | 线程 CPU，lookup → guard（μs/步骤） | 进程近似分配，lookup → guard（B/步骤） |
| --- | ---: | ---: |
| guardperf3 | 1.310 → 0.711 | 48.087 → 0.000 |
| guardperf5 | 1.510 → 0.903 | 48.087 → 0.016 |

本轮可确认发送前步骤近似少分配约 48 B，并在这两组 TIME 块中减少约 0.60 μs CPU。0.000 只表示计数器未观察到该块增量，不证明整个 Async 调用零分配；0.016 同样包含进程其他线程与计数器粒度。局部步骤约 40%–46% 的 CPU 降幅不能描述成全调用或全应用 CPU 降幅。首末 lookup 块仍存在漂移，逐块原值保留。

这一差额不与前序 pending 状态的约 48 B 直接相加为完整调用收益：两轮测量范围不同，且 ART 对象优化与计数粒度没有逐对象归因。

## 5. 实际 IPC RTT：方向反转

下表为每组四轮 P50 的中位数，单位 ms。变化为 guard 相对 lookup；负值较低、正值较高。

| 记录 | 字符数 | lookup | guard | 摘要变化 | 四轮配对变化 % |
| --- | ---: | ---: | ---: | ---: | --- |
| guardperf3 | 16 | 0.952 | 0.648 | -31.89% | -6.90 / -41.11 / -36.22 / -3.32 |
| guardperf3 | 1024 | 0.887 | 0.737 | -16.91% | +2.22 / +23.35 / -31.81 / -18.32 |
| guardperf5 | 16 | 0.813 | 0.852 | +4.84% | +14.51 / +22.77 / -5.34 / +6.30 |
| guardperf5 | 1024 | 0.741 | 0.815 | +9.98% | +43.03 / -27.80 / -1.23 / +17.74 |

**两组整体方向反转，仍未证明稳定 RTT 加速。** 同一组也有反向配对，局部约 0.60 μs 的差额不能直接解释第一组数百 μs 的端到端差异。没有逐请求线程/调度轨迹确定这些变化的原因；不将它们归因于单次缓存查询、锁屏、GC 或某个调度器。

| 记录 | 字符数 | lookup 四轮 P99 范围（ms） | guard 四轮 P99 范围（ms） |
| --- | ---: | ---: | ---: |
| guardperf3 | 16 | 1.373–2.014 | 1.267–1.835 |
| guardperf3 | 1024 | 1.057–1.649 | 1.392–1.788 |
| guardperf5 | 16 | 1.157–1.861 | 0.862–1.741 |
| guardperf5 | 1024 | 1.333–1.640 | 1.460–1.639 |

两组全部最大样本分别为 4.999010 / 4.733802 ms，均保留。没有观察到前序 6.411 秒长尾不证明其原因已被修复；APK、前台条件和采样窗口均不同。

![第二组合格记录：发送前成本与逐轮完整 RTT](runs/2026-10-08-xiaomi14ultra/ordered-guardperf-5/guard-performance.png)

第一组图表保存在[guardperf3 图表](runs/2026-10-08-xiaomi14ultra/ordered-guardperf-3/guard-performance.png)，两组分别展示，未合成固定收益。

## 6. 最终功能回归与 guard 门禁

| 门禁 | 最新 APK PASS | 证据 |
| --- | ---: | --- |
| 生命周期 lifecycleguard | 22 | [目录](runs/2026-10-08-xiaomi14ultra/ordered-guard-lifecycle) |
| 请求与流终态 terminalguard | 8 | [目录](runs/2026-10-08-xiaomi14ultra/ordered-guard-terminals) |
| 协议兼容 compatguard | 16 | [目录](runs/2026-10-08-xiaomi14ultra/ordered-guard-compatibility) |
| 故障 faultguard | 6 | [目录](runs/2026-10-08-xiaomi14ultra/ordered-guard-fault) |

合计 **52 PASS、四组 DONE**；各组前台 END started/completed/valid 均 true，源码与安装哈希一致。兼容采集器最初使用了错误过滤 tag，纠正为 IpcCompatibilityProbe 后从原日志冻结 16 PASS/DONE，没有重新跑测试制造另一份结果。

每组性能探针的 6 项检查：真实捕获 Binder 接受；死亡 Binder 夹具阻止发送且 pending 0；isBinderAlive 期间关闭阻止发送且 pending 0；重连后拒绝旧快照、接受新快照；真实生成 Async 返回并清 pending；永久 dispose 后拒绝旧快照。死亡夹具是 IBinder 接口模拟，本轮没有制造客户端/服务端进程死亡，不把它描述成真实进程死亡覆盖。

## 7. 未纳入合格比较的记录

失败与环境无效记录保留，不以缺条件的数字补足有效轮次。

| 记录 | 原因与处理 | 证据 |
| --- | --- | --- |
| guardperf1，APK 95ED9C... | interactive=false，keyguard/device locked；前台门禁 10 秒超时，未进入 START | [失败日志与哈希](runs/2026-10-08-xiaomi14ultra/ordered-guardperf-1) |
| guardperf2，APK 95ED9C... | 4 项 guard 检查已过，夹具误以为 Async 的 `__error__` 会抛错；实际只有 Direct 使用该条件。只修测试断言，生产 guard 未因此调整 | [失败日志与哈希](runs/2026-10-08-xiaomi14ultra/ordered-guardperf-2) |
| guardperf4，最终 APK 30ED4B... | 测量中 ON_PAUSE/FOCUS_LOSS，4 次失效观察；6 项检查与 DONE 完成，但整轮环境无效。保留 18 个 CSV，不纳入合格性能摘要 | [日志、原始 CSV、qualification](runs/2026-10-08-xiaomi14ultra/ordered-guardperf-4) |

修正后的两个合格 run 即 guardperf3/5，本轮停止追加性能轮次，不挑选更好的下一轮代替方向反转的记录。

## 8. 原始证据与复算

| 合格记录 | 原始日志、源码/安装哈希、前台 CSV、RTT CSV、复算 |
| --- | --- |
| guardperf3 | [目录](runs/2026-10-08-xiaomi14ultra/ordered-guardperf-3)、[analysis.json](runs/2026-10-08-xiaomi14ultra/ordered-guardperf-3/analysis.json) |
| guardperf5 | [目录](runs/2026-10-08-xiaomi14ultra/ordered-guardperf-5)、[analysis.json](runs/2026-10-08-xiaomi14ultra/ordered-guardperf-5/analysis.json) |

~~~powershell
$env:JAVA_HOME='C:\Users\Work\.jdks\ms-17.0.16'
.\gradlew.bat :demo-app:assembleDebug :app-server:assembleDebug :app-client1:assembleDebug :app-client2:assembleDebug :app-client3:assembleDebug --offline --quiet --max-workers=1 '-Pkotlin.compiler.execution.strategy=in-process'
adb -s 925c23bb install -r demo-app/build/outputs/apk/debug/demo-app-debug.apk
# 设备先解锁；使用新的 stage/run，保留已有证据目录。
python docs/benchmarks/harness/run_guard.py guardperf-next guardperfNext
python docs/benchmarks/harness/analyze_guard.py docs/benchmarks/runs/2026-10-08-xiaomi14ultra/ordered-guardperf-3 guardperf3
~~~

[运行与采集脚本](harness/run_guard.py)固定 Xiaomi serial、等待 DONE 与合格前台 END，再冻结源码/安装哈希并提取 CSV；[复算脚本](harness/analyze_guard.py)检查数量、失败、状态和全部分位数。

后续候选、并发风险和冷/热适用范围见[优化分析](../ModernIPC_Optimization_Analysis.md)。优先定位真实业务和高并发下的排队、回调恢复及 GC；保存宿主 UID、合并服务端 started 对象、共享死亡监听和精简冷 Schema 构造仍是候选，没有混入此轮实现。
