# 小米实测：冷发现、清理、请求关联与调度优化

日期：2026-10-08～2026-10-09。仅操作 Xiaomi 14 Ultra（24031PN0DC，Android 16），ADB serial `925c23bb`。工作区含未提交修改，因此以逐轮源码 SHA-256、构建与安装 APK SHA-256 作为复现身份。

**当前状态：** 冷发现/清理、完整 trace 和调度实验已在下述 5C8/4494 版本完成设备验证。随后补充的握手隔离版本 `402684...` 已完成五应用构建与安装；小米当前锁屏，新增 9 项及新版本完整回归尚待执行。不能把前一版本的 64 PASS 当作最新源码的设备验收。

## 1. 修复与验收范围

| 阶段 | 实施内容 | 实际证据 |
| --- | --- | --- |
| 冷发现与清理 | 远端发现移出调用线程、map compute 与控制器锁；同 key 共享发现；4 worker、无队列；关闭替换并作废旧缓存容器 | 最终 trace 版本 12 项冷发现 PASS；150 ms 超时、取消、共享等待者、关闭、销毁、旧代次晚返回、失败重试、严格 schema、饱和恢复 |
| 终态与兼容 | 保留请求取消位、代次检查、Stream 完成/错误与严格 schema；修正 Main 上同步冷发现的示例入口 | 同 APK 22 生命周期、8 终态、16 兼容、6 故障 PASS；合计 64 PASS、5 DONE；另有三客户端跨包冷进程启动 smoke |
| 请求关联 trace | 默认关闭；客户端 6、服务端 5 个阶段；进程内有界缓冲，测量后导出两个文件；Perfetto 关联真实 Binder 与调度 | `traceon4`：1,000 次成功、11,000 个文件事件、丢弃 0、完整关联 1,000 条链；`traceoff1`：1,000 次成功、事件 0 |
| 主要耗时优化 | 根据请求关联结果测试应用侧短任务调度配置，保留宿主提供 Scope 的 SDK 机制；同步 Direct 作为独立调用语义对照 | 结果见第 7 节 |

五应用统一构建 `BUILD SUCCESSFUL`（272 tasks，exit 0）。第一份完整 trace 与跨包适配回归的 demo APK：

```text
5C8CECFDC5650E8186EC326DEAC916A9584755508BF555A5F48CE917AFBE20FC
```

第一轮 2026-10-08 的 64 项修复回归使用 `6F4162248E507B6762CE3C7984EC454480849D69EB2BC70B4DE6A007037E6067`；它早于完整 trace 和 BaseClientActivity 适配，不能替代上述最终版本证据。历史报告中的旧问题与旧 APK 保留原始日期。

新增 demo 调度实验后再次构建成功（125 tasks，exit 0），该调度实验 APK 为：

```text
4494F5299DF407EA3DB2DFE915B14057A39A6DCE5F4171217237FF8F88E1F0A4
```

该调度实验 APK 已再次通过 64 PASS、5 DONE，最长前台观测间隙 505 ms；`traceon5` 也再次得到 1,000 完整请求、11,000 事件、丢弃 0。5C8 与 4494 两版之间 35 个 runtime/compiler/contract/api 源文件 SHA 一致，新增内容为 demo 调度实验。可核验 [final-verification.json](runs/2026-10-09-xiaomi14ultra/cold-trace-analysis/final-verification.json)。之后补充的握手隔离修改了 Controller 并新增 HandshakeExecutor，其验收单列在第 3.3 节，不沿用 4494 的验收。

## 2. 修复后的架构

```mermaid
flowchart TD
    Entry[生成的 Async 入口] --> Deadline[覆盖发现与请求等待的 withTimeout]
    Deadline --> Cache{当前代次缓存命中?}
    Cache -->|是| Register[注册 pending 与取消钩子]
    Cache -->|否| Flight[同 key 共享 Flight]
    Flight --> Pool[最多 4 个进程内发现 worker<br/>SynchronousQueue 无积压]
    Pool --> Meta[同步 getServiceSchema]
    Meta --> Check[客户端严格校验]
    Check --> Acquire[同步 getServiceChecked]
    Acquire --> Needed{代次与等待者仍有效?}
    Needed -->|是| Publish[发布至捕获的缓存容器]
    Publish --> Register
    Needed -->|否| Drop[拒绝晚返回结果]
    Register --> Guard[发送前检查连接与捕获 Binder]
    Guard --> RPC[oneway 请求 → 服务器 Job → oneway 回复]
    RPC --> Terminal[完成 / 失败 / 取消，只移除一次 pending]
    Deadline -->|到期| Release[释放本次发现等待者或取消请求]
```

缓存热命中不会创建发现 worker 或嵌套发现定时器。同步 Direct/Oneway 入口在 Main 冷发现时立即失败，调用方应先使用 `awaitServiceBinderForConnection` 预热；同步业务事务自身仍可能阻塞调用线程。

```mermaid
sequenceDiagram
    participant Caller as 发现等待者
    participant Ctrl as Controller
    participant Cache as 旧缓存容器
    participant Worker as Discovery worker
    participant Broker as Broker Binder
    Caller->>Ctrl: awaitServiceBinderForConnection
    Ctrl->>Cache: acquire / retain Flight
    Cache->>Worker: 提交有界工作
    Worker->>Broker: getServiceSchema（可阻塞）
    Ctrl->>Ctrl: close/dispose：替换缓存容器
    Ctrl->>Cache: invalidate / fail 全部 Flight
    Cache-->>Caller: 立即失败
    Ctrl->>Ctrl: unlink / unbind / failAll pending
    Broker-->>Worker: 旧事务晚返回
    Worker->>Worker: 代次或 needed 已失效
    Worker-->>Cache: 拒绝发布至新容器
```

取消等待者不能中断已开始的同步 Binder RPC。最后一个等待者离开后 Flight 作废，worker 在 RPC 之间检查有效性；最多 4 个阻塞 worker 会占住发现容量，第 5 个需要新 worker 的 Flight 快速拒绝，服务恢复后可以重试；同 key 的额外等待者仍共享已有 Flight。检查与下一次 Binder 发送之间仍存在普通并发窗口，不能宣称“发出取消信号的同一瞬间不再发送远端事务”。

## 3. 小米功能结果

### 3.1 冷发现 12 项

原始记录：[cold-coldrelease.csv](runs/2026-10-09-xiaomi14ultra/ordered-final-cold-dispatch/cold-coldrelease.csv)，[日志](runs/2026-10-09-xiaomi14ultra/ordered-final-cold-dispatch/logcat.txt)，[身份](runs/2026-10-09-xiaomi14ultra/ordered-final-cold-dispatch/evidence.json)。

| 场景 | 本次观察 |
| --- | --- |
| Main 发起冷 Async，远端 metadata 阻塞 300 ms | Main heartbeat 15/15；最终成功 |
| 150 ms Async 预算 | 156 ms 返回超时，pending=0 |
| 150 ms Flow 发现预算 | 171 ms collector 自然结束且超时，无值、pending=0 |
| 主动取消发现 | cancelAndJoin 1 ms；释放 metadata 前远端仍阻塞 |
| 16 个同 key 并发等待者 | metadata=1、checked=1；后续 10 热调用无额外发现 |
| 16 等待者取消其中 1 个 | 其余 15 成功；metadata=1、checked=1 |
| 关闭 / 销毁时 metadata 阻塞，另有已注册 hold 请求 | close 4 ms / dispose 3 ms；发现等待者与原 pending 均失败，pending=0 |
| 重连后旧发现仍阻塞 | 新代次先完成，旧代次失败；metadata=2、checked=1 |
| 注入发现失败后重试 | 第二次成功，无 legacy fallback |
| 错误 schema | checked=0、legacy=0；合法 schema 可重试成功 |
| 4 worker 被阻塞，第 5 个发现 | 1 ms 拒绝；释放后重试成功，peakBlocked=4 |

“lateChecked=0”是在调用方超时/取消结束后、主动释放测试 metadata gate 前的受控观察，不是对所有竞态时序的证明。测试有 10 s 远端 watchdog，运行没有借 watchdog 完成清理。

### 3.2 终态、兼容与跨包

| 记录 | PASS | 验收 |
| --- | ---: | --- |
| [lifecyclerelease](runs/2026-10-09-xiaomi14ultra/ordered-final-lifecycle-dispatch) | 22 | 连接生命周期、待处理请求与订阅释放 |
| [terminalrelease](runs/2026-10-09-xiaomi14ultra/ordered-final-terminals-dispatch) | 8 | 请求与 Flow 完成/错误/取消、溢出策略 |
| [compatrelease](runs/2026-10-09-xiaomi14ultra/ordered-final-compatibility-dispatch) | 16 | 描述符、版本、事务签名、缺失能力与严格失败，无静默退回 |
| [faultrelease](runs/2026-10-09-xiaomi14ultra/ordered-final-fault-dispatch) | 6 | 故障与取消竞态 |
| [crosspkg1](runs/2026-10-09-xiaomi14ultra/cross-package-smoke-crosspkg1/capture-result.json) | 3 客户端 smoke | 四包安装 APK 与构建一致、不同 UID；冷进程启动、客户端状态、服务端实际注册与订阅记录、ActivityManager bindings |

四包 smoke 使用 `capture-result.json.valid=true`。它没有测消息投递、路由隔离和性能，也不是清数据后的首次安装；前台状态在边界采样。性能与功能 probe 使用更严格的 `foreground-coverage-v1`：500 ms 目标周期、最长间隙 1,000 ms，且生命周期/焦点/亮屏/未锁屏有效。

### 3.3 补充：绑定握手也需要独立的阻塞容量

复核发现，前述 4 worker 只覆盖已连接后的业务发现；此前 `onServiceConnected` 仍直接在控制协程的 `Dispatchers.IO` 执行同步 handshake。虽然 RPC 已移出 Mutex，绑定截止可以解绑重试，但旧同步事务会继续占用 IO 线程。多个控制器反复阻塞时，可能占满与关闭任务共用的 IO 执行容量。metadata gate 的原 64 项没有覆盖这一条路径。

新增 [HandshakeExecutor](../../ipc-runtime-client/src/main/kotlin/com/cn/ipc/client/HandshakeExecutor.kt)，为所有控制器提供独立、最多 4 个 worker 的无队列池。控制协程只等待可取消的 Deferred；解绑、绑定截止、close/dispose/owner 取消都会取消本连接的握手等待 Job。新握手发布必须同时匹配 ServiceConnection 身份、Binding 状态及登记的 Job；重复连接回调不会覆盖活动 waiter。已开始的同步 RPC 仍可能继续，晚结果被放弃。

握手池与业务发现池各自最多 4 个，分别隔离“尚未连接”与“已连接后找服务”；不是全部阻塞 Binder 工作合计只占 4 个线程。池满后按原绑定失败/重试策略处理，不会排入无限工作队列。

新增 [HandshakeBlockingService](../../demo-app/src/main/kotlin/com/cn/ipc/demo/HandshakeBlockingService.kt)与[IpcHandshakeProbe](../../demo-app/src/main/kotlin/com/cn/ipc/demo/IpcHandshakeProbe.kt)，预定 9 项：原始 keep-binding 不占握手容量、阻塞下 close/dispose、绑定截止与显式重试、有限重连、旧握手隔离、owner 取消、4 worker 饱和及容量恢复。夹具非导出、同 UID 控制，真实远端 latch 阻塞，10 s watchdog。

握手隔离源码已通过独立复核，五应用统一构建 **BUILD SUCCESSFUL in 3m 31s，272 tasks，exit 0**。五包已全部安装到 `925c23bb`，逐包拉取安装 APK 校验与构建一致；[构建安装身份及源码 SHA](runs/2026-10-09-xiaomi14ultra/handshake-build/build-install.json)。最新 demo APK：

```text
40268409C9625500E63CAE5BB4B5114CE2EE1831013D0C35E221563ABED4B862
```

小米在此阶段进入 Dozing；只唤醒后仍显示 keyguard=true，已请求人工解锁。安装后的 [power](runs/2026-10-09-xiaomi14ultra/handshake-build/power-after.txt) / [Activity](runs/2026-10-09-xiaomi14ultra/handshake-build/activities-after.txt) 仍为 Dozing / keyguard=true。**9 项新增实测与 402684 新 APK 完整回归等待解锁，尚未执行**，不能视为已通过，也未沿用 4494 验收。待执行命令见[后续验收](runs/2026-10-09-xiaomi14ultra/handshake-build/next-steps.md)。

## 4. 请求 trace 契约与采集修正

```mermaid
flowchart LR
    E[client_entry] --> R[client_resolved]
    R --> P[client_registered]
    P --> S[client_send]
    S --> V[server_receive]
    V --> Q[server_enqueued]
    Q --> J[server_job_start]
    J --> B[server_business_done]
    B --> T[server_reply]
    T --> C[client_reply]
    C --> U[client_resume]
```

每侧缓冲上限 16,384 个事件。默认关闭时不分配 Event、不取 TID、不加事件锁、不写日志；生成代码仍有原始数值快照和分支，不能称为零开销。开启时会分配 Event、加锁和写 ATrace 标记，测量后才导出文件。

关联键在客户端为 run/PID/callback/generation/requestId。callback identity 是进程内值，服务端不等于客户端；服务器 generation 未知记 0。仅在受控单客户端、单 callback、单代次、不同两进程且 requestId 唯一时，允许跨端按 requestId 关联；不适用于直接推广到多客户端。没有修改 wire envelope。

`client_entry`、`client_resolved` 和 `server_receive` 为补记原始 ns。阶段计算使用文件 ns；ATrace marker 实际写入时间只作辅助上下文。`client_encode` 包含补记事件，`server_queue` 包含 enqueue 记录和启动开销，`client_resume` 包含回复记录、解码、pending 移除与调用方恢复。

| 采样 | 结果与处理 |
| --- | --- |
| traceon1 | Perfetto config 位于设备不可读目录，未完成；排除 |
| traceon2 | 设备 v49 不支持 record_thread_names 配置，未完成；排除 |
| traceon3 | App 缓冲计数 11,000，但 Logcat 只有 10,424 条，丢 576；严格校验失败，排除 |
| [traceon4](runs/2026-10-09-xiaomi14ultra/ordered-trace-on4/capture-metadata.json) | 两个可靠文件 6,000 + 5,000，丢弃 0；1,000 唯一且阶段单调的完整请求；通过 |
| [traceoff1](runs/2026-10-09-xiaomi14ultra/ordered-trace-off1/capture-metadata.json) | 同 APK，1,000 成功，事件 0、pending/requests=0；通过 |
| [traceon5](runs/2026-10-09-xiaomi14ultra/ordered-trace-on5/capture-metadata.json) | 最终 4494 APK，1,000 完整请求、11,000 事件、丢弃 0；通过，用于最终 trace 完整性回归 |

上述失败全部保留，修正后使用新目录，不覆盖失败样本。traceon4 RTT P50/P99 为 **0.919896 / 1.576510 ms**；traceoff1 为 **0.771510 / 1.943386 ms**。顺序各一轮且都有系统 Perfetto，不能把差值当成稳定 trace 开销，更不能作为优化收益。trace 路径当前完整验收覆盖正常串行成功 Echo；错误/取消/冷发现链的所有阶段尚未做同等完整性验收。

## 5. 分段与内核相关证据

逐请求：[request-stages.csv](runs/2026-10-09-xiaomi14ultra/ordered-trace-on4/request-stages.csv)。内核关联：[summary.json](runs/2026-10-09-xiaomi14ultra/ordered-trace-on4/correlated-analysis/summary.json)，[分析脚本](runs/2026-10-09-xiaomi14ultra/ordered-trace-on4/correlated-analysis/analyze_correlated.py)。

分段均值/分位数由原始 CSV 生成：[stage-summary.json](runs/2026-10-09-xiaomi14ultra/cold-trace-analysis/stage-summary.json)，[绘图脚本](harness/plot_cold_trace.py)。`server_dispatch` 等于 admission + queue，已重叠，不能重复相加；不同阶段的 P50/P99 也不能相加推导整体分位数。无重叠阶段均值之和为 893.387 μs；它不包含 entry 前与 resume 标记后的外层开销，外部 RTT 均值为 975.815 μs。

![请求分段与线程状态](runs/2026-10-09-xiaomi14ultra/cold-trace-analysis/request-costs.png)

| 请求窗口（1000/1000） | 平均墙钟 μs | 目标线程 Running μs | Ready μs | Sleep μs |
| --- | ---: | ---: | ---: | ---: |
| server receive → enqueue，Binder 线程 | 115.711 | 113.257 | 0.734 | 1.720 |
| server enqueue → job start，目标 worker | 116.693 | 38.936 | 36.952 | 40.805 |
| client reply → resume，目标 worker | 179.371 | 46.339 | 49.381 | 83.651 |

999/1000 服务端 worker 唤醒来自对应请求 Binder TID；1000/1000 客户端 worker 唤醒来自对应 callback Binder TID。两个方向合计 2,000/2,000 唯一 Binder flow；内核 send→receive 平均分别 48.207 μs、52.520 μs。

这说明服务端准入含实际 CPU 工作，调度与恢复也是可测成本。Sleep 可包含源线程处理和 dispatch 准备，不能全部称为 ready 排队；Running 是线程 CPU 驻留，不是函数级 profile。源、目标线程的窗口重叠，不能相加。

两向 Binder receiver 的内核区间也可按状态拆分：请求平均 48.207 μs 中 Ready 34.794 μs，回复平均 52.520 μs 中 Ready 39.772 μs。它们包含接收线程等待执行的时间，不能称为 Binder 驱动 CPU 耗时。

长尾也有具体证据：request 273 的 client reply→resume 为 1.673333 ms，其中 ready 1.484375 ms；request 272 请求 Binder 内核 send→receive 为 2.547084 ms。不能据此归因整个设备、MIUI 单一策略或所有请求。

### Perfetto 可靠性边界

主机 trace processor v58.2，设备 tracing service v49.0。BOOTTIME clock snapshot 偏移 0，文件 ns 位于 trace 窗口内。每 CPU 初始 compact switch/waking 跳过合计 8+8，最晚初始化早于首请求 746.692 ms。当前 buffer 的 overwrite/discard、writer loss 与每 CPU overrun delta 为 0，480 chunks 写入=读取；非零 error/data_loss/notice 为空。

全局 `traced_chunks_discarded=1` 为服务累计计数，仅一份末尾统计，无法判断属于历史还是本次。因此不宣称系统 trace 绝对零丢失。进程名快照还将客户端 PID 1466 记为 usap64，分析按事件 PID/TID 和 Binder flow 关联，不能按包名筛选后误判客户端没有 CPU 或事件。

上述统计语义以 [Perfetto v58.2 初始化实现](https://github.com/google/perfetto/blob/v58.2/src/trace_processor/importers/ftrace/ftrace_sched_event_tracker.cc#L132)和[设备 v49.0 服务累计计数实现](https://github.com/google/perfetto/blob/v49.0/src/tracing/service/tracing_service_impl.cc#L2899)核对。

## 6. 优化边界

1. 保留 LAZY：先注册请求与 completion hook，再运行，防止任务先结束而漏清理。
2. 保留 callback 死亡监听、permit、鉴权、schema、发送前代次检查和取消编码。
3. 不将任意业务放到 Binder 线程执行；服务端 CoroutineScope 由业务配置，runtime 不强行改为 Unconfined/UNDISPATCHED。
4. 不绕过调用方 dispatcher 恢复，Main 调用仍应在 Main 恢复。
5. Direct 已有独立同步协议，可用于有严格短耗时保证且在后台调用的操作；它不能替代需要可取消挂起等待的 Async。

## 7. 同 APK 调度配置与 Direct 对照

实现：`IpcDispatchBenchmark` 在同一个 Echo Stub 上切换现有 `coroutineScope` 的 Default / 专用单线程执行器，任务仍通过原 Tracker 的 LAZY Job 调度；Direct 使用原有同步接口。共享 SupervisorJob，idle 才切换；成功路径显式恢复 Default，异常 finally 尝试恢复，失败时由 capture 判失败并保留现场，不能承诺异常时必然恢复。专用线程保留到服务销毁时关闭。此配置实验只在 demo；SDK 的 Scope 由宿主提供，没有自动建立的默认 Default Scope。

每个 run 三路径各 500 次预热，随后每块 50 次预热；16/1024 字符各 4 轮、三路径换序，共 24×1,000 次串行；再用 16 并发、两轮换序，共 4×1,024 次请求。不开请求 trace，不开系统 Perfetto；每块结束验证 pending/request 清零。

### 实测结果与采用决定

两轮同一最终 APK，各 28,096 次测量请求全部成功，共 **56,192 次**；每轮 4 PASS、28 RESULT、DONE，前台最大间隙均 505 ms。原始记录：[dispatch1](runs/2026-10-09-xiaomi14ultra/ordered-dispatch1)、[dispatch2](runs/2026-10-09-xiaomi14ultra/ordered-dispatch2)。独立离线校验：[analyze_dispatch.py](harness/analyze_dispatch.py)，[完整 JSON](runs/2026-10-09-xiaomi14ultra/dispatch-analysis/dispatch-analysis.json)，[逐块与全部配对表](runs/2026-10-09-xiaomi14ultra/dispatch-analysis/summary.md)。

下表为**各轮配对变化百分比的中位数**，dedicated 相对 default；延迟负数表示下降。没有合池两次 capture，也没有把单个 RTT 当成独立实验计算显著性。

| Capture | 场景 | 配对数 | ΔP50 | ΔP99 | Δmean | Δ并发完成 QPS |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| dispatchperf1 | 串行 16 字符 | 4 | -18.46% | -23.73% | -17.91% | — |
| dispatchperf2 | 串行 16 字符 | 4 | -0.29% | -9.28% | -9.68% | — |
| dispatchperf1 | 串行 1024 字符 | 4 | -30.52% | -42.22% | -31.78% | — |
| dispatchperf2 | 串行 1024 字符 | 4 | -17.30% | -2.17% | -7.91% | — |
| dispatchperf1 | 16 并发、16 字符 | 2 | -9.01% | -7.57% | -9.99% | +13.63% |
| dispatchperf2 | 16 并发、16 字符 | 2 | -13.46% | -20.81% | -15.40% | +22.46% |

第二轮 16 字符串行的四个 P50 配对变化是 **-18.46%、+17.88%、-38.27%、+20.83%**，两组反向，不能承诺稳定的小包延迟下降。1024 字符八组方向均下降，16 并发四组方向均有改善，但样本只包含无工作量 Echo，不能外推到阻塞 I/O、重 CPU 或长任务。

![全部串行配对方向](runs/2026-10-09-xiaomi14ultra/dispatch-analysis/paired-p50.png)

第一轮时此前跨包 smoke 的三个客户端及 server 仍存在；第二轮前显式停止了这四个测试包。processes 快照能证明进程存在/缺席，不能证明其 CPU 负载，更不能把跨 capture 的差值归因于停止进程。两轮只分别报告内部配对，实际设备频率、JIT/GC 和周期漂移仍会影响结果。

**采用：保留短任务专用调度器为应用侧可选配置和可复现实验，SDK 的宿主 Scope 机制不变，demo 默认使用 Default。** 它保留原有 Async wire、Job、取消与死亡监听，确实能绕开 Default 共享工作队列；适用于已证明短、非阻塞业务的专用服务 Scope。单线程会限制重任务并行度，而且每个实例需要线程资源；业务必须关闭 dispatcher 并取消其 Job。实现可查 [MyBrokerService](../../demo-app/src/main/kotlin/com/cn/ipc/demo/MyBrokerService.kt)与[IpcDispatchBenchmark](../../demo-app/src/main/kotlin/com/cn/ipc/demo/IpcDispatchBenchmark.kt)。

Direct 的逐块值也保留在完整表中。它通过同步回复减少服务端 Job、独立 callback Binder 和 continuation 恢复，已是现有 API；其更低 Echo RTT 是不同调用语义的参考，不能包装成保持 Async 全部契约后的加速。对于需要可取消等待的业务，继续使用 Async，并先优化真实业务、批量化或限制请求频率。

### 后续仍需的性能证据

本轮没有改写 runtime 的通用调度策略，没有宣称所有场景加速，也没有重新测量 AndLinker。若业务要采用专用 Scope，下一步应以真实方法的长尾、并发度与公平性测量确定线程数；需要按工作量选择批量接口时，另增事务与版本，保留现有协议兼容。

## 8. 复现

以下工具固定 serial `925c23bb`，没有接触其他设备。准备 trace 与跨包脚本默认不调用 ADB，实际采集必须加 `--execute`。每次使用新 stage/run-id。

```powershell
$env:JAVA_HOME='C:\Users\Work\.jdks\ms-17.0.16'
.\gradlew.bat :demo-app:assembleDebug :app-server:assembleDebug :app-client1:assembleDebug :app-client2:assembleDebug :app-client3:assembleDebug --offline --console=plain --max-workers=1 '-Pkotlin.compiler.execution.strategy=in-process'

# 明确安装完成后执行。capture 工具本身不安装 APK。
$env:IPC_BENCHMARK_DATE='2026-10-09'
python docs/benchmarks/harness/run_guard.py final-cold-trace coldfinal IpcColdProbe 12
python docs/benchmarks/harness/run_guard.py final-lifecycle-trace lifecyclefinaltrace IpcLifecycleProbe 22
python docs/benchmarks/harness/run_guard.py final-terminals-trace terminalfinaltrace IpcTerminalProbe 8
python docs/benchmarks/harness/run_guard.py final-compatibility-trace compatfinaltrace IpcCompatibilityProbe 16
python docs/benchmarks/harness/run_guard.py final-fault-trace faultfinaltrace IpcFaultProbe 6

python docs/benchmarks/harness/capture_request_trace.py docs/benchmarks/runs/2026-10-09-xiaomi14ultra/ordered-trace-on4 --run-id traceon4 --seconds 20 --force-stop --execute
python docs/benchmarks/harness/analyze_request_trace.py docs/benchmarks/runs/2026-10-09-xiaomi14ultra/ordered-trace-on4 --run-id traceon4 --single-client --trace-processor .gradle/trace-tools/trace_processor_shell.exe
python docs/benchmarks/harness/capture_cross_package_smoke.py --run-id crosspkg1 --execute

# 调度实验工具：先捕获功能日志与身份，再拉本轮 raw CSV。
python docs/benchmarks/harness/run_guard.py dispatch1 dispatchperf1 IpcDispatchBench 4
python docs/benchmarks/harness/analyze_dispatch.py docs/benchmarks/runs/2026-10-09-xiaomi14ultra/ordered-dispatch1 dispatchperf1 docs/benchmarks/runs/2026-10-09-xiaomi14ultra/ordered-dispatch2 dispatchperf2 --print-pull
# 根据输出的固定 serial argv 拉取两个CSV后，离线复算：
python docs/benchmarks/harness/analyze_dispatch.py docs/benchmarks/runs/2026-10-09-xiaomi14ultra/ordered-dispatch1 dispatchperf1 docs/benchmarks/runs/2026-10-09-xiaomi14ultra/ordered-dispatch2 dispatchperf2
```

上述实际目录已存在，复测应换新名称。完整请求关联与调度拆解只能证明本次 Debug Echo 场景，不能外推为 AndLinker 的当前排名、真实业务收益或其他机型性能。
