# 四 App 会议通知案例：实现与验收状态

## 1. 当前结果

已完成四个独立 APK 的会议通知业务实现、接入文档和自动采集脚本。修正后五应用统一构建 **BUILD SUCCESSFUL，退出码 0，1 分 14 秒，272 个任务**。构建日志、APK SHA-256 与源码快照见 [build-result.json](runs/2026-10-09-xiaomi14ultra/multi-app-case-build/build-result.json) 和 [gradle-build.txt](runs/2026-10-09-xiaomi14ultra/multi-app-case-build/gradle-build.txt)。

**新案例设备验收为 NOT_RUN。** 2026-10-09 14:38（北京时间）检查指定小米 `925c23bb`，ADB 返回 `device not found`，见 [device-state.json](runs/2026-10-09-xiaomi14ultra/multi-app-case-build/device-state.json)。未安装本次新 APK、未操作其他设备，不能把构建成功或历史跨包 smoke 写成业务案例已通过。

默认 prepare 路径已执行，使用不可用的 ADB 名仍成功，确认不会调用设备；最新准备快照见 [meetingprepare2/capture-plan.json](runs/2026-10-09-xiaomi14ultra/multi-app-case-meetingprepare2/capture-plan.json)。这是准备记录，尚无 PASS 或实际性能数据。

## 2. 实际业务链

| 应用 | 当前可操作行为 |
| --- | --- |
| app-client1 / 调度台 | “发布会议到会议屏”“广播会务通知”“仅向中枢上报”。 |
| app-server / 消息中枢 | 保持现有身份校验与路由；案例上报可关联到 commandId。 |
| app-client2 / 会议屏 | 接收定向会议，更新自己的 TextView 会议卡，再回传处理确认。 |
| app-client3 / 运维屏 | 展示会议屏确认与公共通知；可暂停和恢复订阅。 |

```mermaid
sequenceDiagram
    participant C1 as 调度台 App
    participant S as 中枢 App
    participant C2 as 会议屏 App
    participant C3 as 运维屏 App
    C1->>S: sendMessage(client_1, client_2, meeting.show)
    S->>C2: observeMessages Flow / commandId
    S-->>C1: 路由返回（不能代替业务确认）
    C2->>C2: 校验来源与目标，更新会议卡
    C2->>S: sendMessage(client_2, ALL, meeting.displayed)
    S->>C1: 同 commandId / title / room 的确认
    S->>C3: 会议屏处理确认
    C1->>C1: 匹配当前指令，显示已确认
```

以上箭头表示代码路径，不表示本次已在设备上观测到。会议屏是同一 Android 设备上的独立 App 页面，确认表示 TextView 数据已赋值，没有验证物理屏幕像素呈现。完整架构图、业务流程图、权限和操作步骤见[业务指南](../ModernIPC_Business_Interaction_Guide.md)。

## 3. 实现与审查

- [MeetingBoardMessage](../../ipc-api/src/main/kotlin/com/cn/ipc/api/hub/MeetingBoardMessage.kt)：独立业务 JSON 版本，验证 kind、commandId 和非空标题/位置；JSONObject 转义内容中的控制字符。
- [MeetingBoardDemo](../../demo-client-common/src/main/kotlin/com/cn/ipc/client/common/MeetingBoardDemo.kt)：角色校验、会议卡、5 秒截止、关联确认及当前 Activity 内最近 64 条命令去重。相同 ID/载荷可重发确认，冲突载荷拒绝。
- [BaseClientActivity](../../demo-client-common/src/main/kotlin/com/cn/ipc/client/common/BaseClientActivity.kt)：复用当前连接和订阅，发送前核对原代次，返回后核对连接与 adapter；DEBUG Intent 动作与可见按钮共享业务函数，消费后清除。
- [MessageHubServiceImpl](../../app-server/src/main/kotlin/com/cn/ipc/server/app/MessageHubServiceImpl.kt)：只在合法的 client1 SERVER_ONLY 案例上报分支输出关联观察日志。

复审修正了三个确定问题：业务确认先到时不再被路由回包的超时/异常覆盖；排队的旧业务任务不能经新代次发送；合法会议载荷先于普通压测 marker 解析。构建验证包含这些修正。

业务 JSON 通过现有 String content 传输，未增加 Binder 事务或改变服务 ID/契约版本。与此前握手构建快照比较，35 个 runtime、contract、compiler、annotations 文件哈希相同；这只证明对应源码未变，不替代设备回归。

## 4. 自动验收计划

[capture_multi_app_case.py](harness/capture_multi_app_case.py) 的 Python 编译与离线事件/UI 门槛检查通过。UI 检查只接受对应 `meeting-case-status` 或 `meeting-case-notice` TextView，不能用普通日志中的同一 ID 冒充页面更新。

脚本固定小米 `925c23bb`，执行前要求亮屏、未锁屏、四包安装哈希与构建哈希匹配、四个不同 UID。保存每阶段 UI XML、前台状态、进程身份、关联 Logcat、源码/APK 哈希和失败现场。

| 阶段 | 必须看到的结果 |
| --- | --- |
| 定向会议 | client2 会议卡更新，client1 与 client3 收到同 ID 的业务确认。 |
| 广播通知 | client2 与 client3 通知卡更新，发送端未收到自身广播。 |
| 仅服务端上报 | 服务端关联事件及界面记录，客户端在观察窗口内无该上报。 |
| 暂停运维屏 | client2 收到新通知，暂停的 client3 未收到。 |
| 恢复运维屏 | 两端收到下一条新通知，缺失通知在观察窗口内没有重放。 |
| 再次定向会议 | 发布与确认闭环重新成功。 |

负向检查限于对应 commandId 的 3 秒观察窗口。各阶段界面状态快照不证明所有 App 持续同时在前台。额外手工验收包括暂停会议屏导致确认超时、重复命令与冲突拒绝、断开/重连、Activity 重建。

设备恢复后先安装本次四包，并以新 run-id 执行；准备目录不能复用：

```powershell
# 安装与启动命令见业务指南，明确指定 -s 925c23bb。
python docs/benchmarks/harness/capture_multi_app_case.py --run-id meetingprepare3
python docs/benchmarks/harness/capture_multi_app_case.py --run-id meetingcase1 --execute
```

若设备恢复日期不同，脚本默认按当天保存记录，或显式传 `--date YYYY-MM-DD`。本次报告日期不能代替未来采样日期。

此前新增握手 9 项与框架 64 项、请求 trace 的最终回归仍待完成，步骤见[握手验收计划](runs/2026-10-09-xiaomi14ultra/handshake-build/next-steps.md)。执行这些历史计划时也应使用当前 APK 身份和新的目录，不把旧安装哈希用作本次构建证明。

## 5. 当前边界

会议卡、在线表、去重记录和上报都在内存中。SharedFlow 无离线重放，暂停订阅可能丢消息，路由 OK 不保证消费。注册/订阅启动不是远端 collector 就绪证明。确认超时或连接丢失时结果可能已发生，案例不会自动重发；取消等待不能回滚已执行的远端操作。

本次没有业务端到端时延、无人值守后台稳定性或两库性能排名。历史 echo 测试与会议发布/确认的工作量不同，应分别报告。
