# 2026-09-29 小米 14 Ultra 实机短测

本次测试验证了两个库各自示例能否通信，并观察 ModernIpc 跨包调用在小米设备上的前后台行为。它不是同负载基准测试；详见[库间能力对比](../ModernIPC_vs_AndLinker.md)。

后续已追加[同负载 echo 实测](xiaomi14ultra_2026-09-29_echo_ab.md)，使用两个测试专用 APK 在同包分进程场景比较串行回显时延。本页以下结果仍只描述原版示例功能短测。

## 设备、构建与部署

设备型号 24031PN0DC，Android 16（API 36），Xiaomi OS3.0，系统构建 BP2A.250605.031.A3。测试期间电量 4%～5%，USB 供电，电池温度约 29.0～31.5 °C，系统 Thermal Status 为 0。低电量及厂商调度均可能影响时延。

| 项目 | 构建来源 | 部署拓扑 |
| --- | --- | --- |
| ModernIpc | 本仓库提交 7586008421271537ef16500429277fd8434d40db 加当前未提交修复，重新编译 Debug APK | app-server 与 app-client1/2/3 为四个独立包、独立 UID |
| AndLinker | [上游提交 7ae01bfd](https://github.com/codezjx/AndLinker/tree/7ae01bfd87ddcf021319148a8727a95345cf350e) 的原版 sample；临时克隆中只改构建签名设置以用 JDK 11 编译，未改业务源码 | 单包 com.example.andlinker，主进程与 :remote 服务进程 |

APK SHA-256：ModernIpc 服务端 170131EEB04AAC939614CFF37A96310FF8CD797C55CBC3911D316860111BE8B8；客户端 1 617E97B375D65EC999BC4215F0E2D158DEB08AEF51167449675A03E0992EA80B；AndLinker sample 2C3B68ABD40E20815C7668DA7CD8FCCC9DE9B2E276A3AF68685ED415E5FE939E。其余 ModernIpc 客户端 APK 的哈希未写入本报告，不应据此推断产物相同。

## ModernIpc：跨包连接与唤醒

先启动客户端 1、保持服务端未运行时，小米 WakePathChecker 连续记录 MIUILOG-AutoStart Reject。客户端进入 Reconnecting，服务端没有被成功拉起。手动打开服务端 Activity 后，客户端连接、注册并建立 Flow 订阅。[唤醒拒绝日志](runs/2026-09-29-xiaomi14ultra/wakepath-reject.txt)证明这次跨包启动被系统策略拒绝；不能推广到所有小米设备、所有安装方式或所有前后台状态。

## ModernIpc：挂起 RPC

客户端先执行 50 次预热，然后连续 1000 次调用 sendMessage(client_1, SERVER_ONLY, "[BENCHMARK] rtt_probe")。计时从客户端业务调用开始，到挂起调用恢复结束，包含 Parcel、Binder、服务端 SERVER_ONLY 分支和返回回调。

| 轮次 | P50 | P90 | P99 | 平均 |
| --- | ---: | ---: | ---: | ---: |
| 第一次 | 2.067 ms | 3.010 ms | 5.078 ms | 2.218 ms |
| 第二次 | 2.256 ms | 3.056 ms | 4.554 ms | 2.376 ms |

第二次的[原始 RTT 日志](runs/2026-09-29-xiaomi14ultra/modern-rtt.txt)保留在仓库。第一次的逐次原始日志未保存，只能按测试时汇总值引用。两轮是同设备同 APK 的短时间样本，不含后台长延迟分布，也不是纯 Binder 单跳时延。

## ModernIpc：定向消息与后台长尾

客户端 1 发往 client_2 的两条私信均由服务端处理，并在客户端 2 恢复前台后出现在其 UI 记录；客户端 3 的采集窗口里未出现这两条私信。[客户端 2 日志](runs/2026-09-29-xiaomi14ultra/modern-client2-ui.txt)与[客户端 3 日志](runs/2026-09-29-xiaomi14ultra/modern-client3-ui.txt)仅证明本次窗口内的观察，无法证明任意时机均无误投。

发送端两条回执耗时分别为 37.411 s 和 77.895 s；两条在服务端 Activity 切回前台时几乎同时完成。服务端消息时间戳 10:52:22.681，客户端 2 界面记录接收时间 10:52:38.156/163。设备后台调度可能相关，但没有同步取得进程冻结状态和完整调度轨迹，不能指定唯一根因。该长尾说明前台短时 RTT 不能代表后台业务时延。

## AndLinker：原版 sample 功能

测试中主进程 PID 8452，:remote 进程 PID 16918。日志出现 onServiceConnected、服务端 init、客户端 onInit/onStart/onValueChange 回调和服务端 onewayMethod。[原始功能日志](runs/2026-09-29-xiaomi14ultra/andlinker-smoke.txt)覆盖这次功能路径。Oneway 服务端日志从 11:04:37.935 到 11:04:40.936 的约 3 秒间隔来自 sample 主动 Thread.sleep(3000)，不是 IPC 延迟。

## 可得结论与后续验证

两库都在此设备上完成各自示例的跨进程通信。ModernIpc 额外覆盖了本仓库的跨包拓扑和两轮挂起 RPC；AndLinker 覆盖同包分进程的回调及 Oneway。AndLinker 没有等价 RTT、并发或包体测试；业务方法、包拓扑和进程状态不相同，不计算速度倍数。

如需严格比较，统一同签名/包拓扑、相同空方法和相同业务方法、相同参数与返回、前后台状态、电量和温度；交替多轮运行，保留两个库的原始调用样本、失败数、成功吞吐及服务端完成时间。测试定义见[索引](README.md)。
