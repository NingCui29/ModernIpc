# ModernIpc 多 App 实际使用案例：会议通知与展示

本案例把一个业务拆成四个独立 APK：调度台发布会议，消息中枢路由，会议屏更新会议卡并回传确认，运维屏观察确认与公共通知。它使用现有消息中枢接口，新增业务 JSON 载荷和客户端界面，不改 Binder 事务、服务 ID 或 wire Schema。

这是同一台 Android 设备上的多 App 协作。“会议屏”和“运维屏”分别是客户端 2、3 的 Activity；会议卡是本地 TextView，没有控制外部显示设备或接入日历系统。不同物理终端之间还需要网络或其他传输层。

本案例仅计划在小米 `925c23bb` 上验收；截至本次修改，新场景尚无设备实测结果。当前构建与设备状态见[案例报告](benchmarks/xiaomi14ultra_2026-10-09_multi_app_case.md)。现有跨包 smoke 和 echo 性能数据不能替代本案例验收。SDK 接入见[SDK 指南](ModernIPC_SDK_Guide.md)，Binder 内部调用链见[架构文档](ModernIPC_Architecture.md)。

仓储工单、配置同步和遥测告警三个新增场景使用同一组 APK，在客户端场景选择器切换；角色、业务流程图、时序图、操作与验收边界见[多 App 场景目录](ModernIPC_Multi_App_Scenarios.md)。会议仍是默认场景，本文保留原会议载荷、业务确认语义与历史证据。

## 1. 会议案例的应用角色与架构

| APK / 包名 | 身份 | 案例职责 |
| --- | --- | --- |
| app-server / com.cn.ipc.server.app | 中枢 | 导出 Broker，校验身份，路由消息，记录仅服务端上报。 |
| app-client1 / com.cn.ipc.client1 | client_1，调度台 | 发布定向会议指令，等待会议屏确认，广播会务通知，向中枢上报。 |
| app-client2 / com.cn.ipc.client2 | client_2，会议屏 | 接收指令，更新会议卡，广播同一 commandId 的展示确认。 |
| app-client3 / com.cn.ipc.client3 | client_3，运维屏 | 观察展示确认与公共通知，不接收发给会议屏的原始指令。 |

四个 APK 分属不同 UID，各自有独立进程和界面。调度台通过中枢传递指令，不直接调用会议屏 Activity。

```mermaid
flowchart LR
    subgraph DEVICE["同一 Android 设备 / 小米 925c23bb"]
        C1["app-client1 / 调度台<br/>发布指令、等待确认"]
        HUB["app-server / 中枢<br/>Broker、鉴权、内存会话、路由"]
        C2["app-client2 / 会议屏<br/>本地 TextView 会议卡"]
        C3["app-client3 / 运维屏<br/>确认与会务通知"]
        C1 -- "Async：meeting.show → client_2" --> HUB
        HUB -- "Flow：会议指令" --> C2
        C2 -- "Async：meeting.displayed → ALL" --> HUB
        HUB -- "Flow：展示确认" --> C1
        HUB -- "Flow：展示确认 / 会务通知" --> C3
        C1 -- "meeting.notice → ALL<br/>meeting.audit → SERVER_ONLY" --> HUB
    end
```

## 2. 业务 JSON 与两层回执

`sendMessage(fromClientId, targetScope, content)` 的 content 仍是 String，本案例使用 `JSONObject` 序列化。JSON 的 `v=1` 是业务版本，与 Binder 服务契约版本 `2` 分开维护。

```json
{
  "case": "meeting-board",
  "v": 1,
  "kind": "meeting.show",
  "commandId": "meeting-20261009-001",
  "title": "项目例会",
  "room": "会议室 A"
}
```

| 字段 | 契约 |
| --- | --- |
| case / v | 固定 `meeting-board` / 整数 `1`。 |
| kind | `meeting.show`、`meeting.displayed`、`meeting.notice`、`meeting.audit`。 |
| commandId | 匹配 `[A-Za-z0-9_-]{1,96}`；业务关联 ID，不是 Hub 逐次分配的 MessageEnvelope.messageId。 |
| title / room | 标题与位置，均非空白，分别不超过 120；展示确认回传相同内容供调度台校验。 |

编码与解析见 [MeetingBoardMessage](../ipc-api/src/main/kotlin/com/cn/ipc/api/hub/MeetingBoardMessage.kt)，业务状态与界面见 [MeetingBoardDemo](../demo-client-common/src/main/kotlin/com/cn/ipc/client/common/MeetingBoardDemo.kt)。

| kind | 来源与路由 | 业务行为 |
| --- | --- | --- |
| meeting.show | `client_1 → client_2` | 会议屏验证来源、目标与载荷，更新会议卡后回传确认。 |
| meeting.displayed | `client_2 → ALL` | 调度台匹配待确认 commandId/title/room，运维屏展示确认。 |
| meeting.notice | `client_1 → ALL` | 会议屏与运维屏展示公共通知；发送方不收到自身广播。 |
| meeting.audit | `client_1 → SERVER_ONLY` | 仅中枢界面及日志记录，不向任何客户端 Flow 派发。 |

接收端检查 MessageEnvelope 的真实 `fromId` 与 `target`，不能只信任 JSON 内自报身份。Hub 将调用 UID 映射到 clientId；会议管理员、房间授权等业务权限需要应用另行实现。

**路由回执**是 sendMessage 返回的 `OK: Delivered...` 等文本，表示中枢处理了路由。离线也是普通 `ERROR: ...` 字符串；不能仅以 RPC 未抛异常判断成功。

**业务确认**是会议屏在本地 TextView 赋值后发出的 `meeting.displayed`。调度台只接受来自 client_2、目标为 ALL 且 commandId/title/room 与待确认指令一致的消息。案例从发送开始提供 5 秒总预算，覆盖路由 RPC 与业务 ACK；未在预算内完成时显示结果未知，不自动重试。超时不证明指令没有执行或会议没有展示。

会议屏在当前 Activity 内缓存最近 64 条命令：相同 commandId 和相同载荷重复到达时重发 ACK，同一 ID 的冲突载荷拒绝更新。缓存随 Activity 销毁丢失，也会淘汰旧项，因此不提供持久幂等或“恰好一次”执行。

本案例 ACK 证明本地 TextView 已赋值，不表示首帧已绘制、用户已看见、外部屏幕已刷新或数据库已提交。

## 3. 会议指令、展示与确认时序

```mermaid
sequenceDiagram
    autonumber
    participant C1 as 调度台 / client_1
    participant B as Broker
    participant H as MessageHubServiceImpl
    participant C2 as 会议屏 / client_2
    participant C3 as 运维屏 / client_3
    C2->>B: bind / 握手 / 严格 Schema 发现
    C2-)H: registerClient(client_2)
    C2->>H: observeMessages(client_2)
    C3->>B: 连接与严格发现
    C3-)H: registerClient(client_3)
    C3->>H: observeMessages(client_3)
    C1->>B: 连接、登记、订阅
    C1-)H: sendMessage(client_1, client_2, meeting.show)
    H->>H: 校验 UID / clientId，检查目标会话
    H-)C2: Flow NEXT：定向指令
    H-)C1: Async 路由回执
    Note over H,C3: 原始定向指令不派发给 client_3
    C2->>C2: 验证角色、字段与重复记录
    C2->>C2: 更新本地 TextView 会议卡
    C2-)H: sendMessage(client_2, ALL, meeting.displayed)
    H-)C1: Flow NEXT：相同 commandId 的确认
    H-)C3: Flow NEXT：展示确认
    H-)C2: Async 广播路由回执
    C1->>C1: 匹配来源、commandId/title/room，更新状态
    C3->>C3: 更新运维观察卡
```

路由回执与 Flow 事件来自不同回调路径，其抵达顺序不应被视为业务保证。若匹配的业务确认先到，后续路由回包超时或异常只记录为路由结果未知，保留已确认状态。生成 Async 入口默认 30 秒预算包含冷发现和 pending 等待；会议案例再用 5 秒外层截止覆盖自己的发送与确认全过程。

登记 Oneway 返回、客户端“正在监听”提示及服务端 observeMessages 工厂日志都不能证明订阅已消费消息。验收需观察真实会议卡、同一 commandId 的确认与信封身份。

### 业务流程图

```mermaid
flowchart TD
    START["调度台：生成 commandId，启动 5 秒总预算"] --> SEND["Async：向 client_2 发 meeting.show"]
    SEND --> ROUTE{"中枢路由结果"}
    ROUTE -- "ERROR / 请求失败" --> HASACK{"业务确认是否已成功？"}
    HASACK -- "是" --> DONE["保留会议屏已确认状态"]
    HASACK -- "否" --> FAIL["请求失败或结果未知，不自动重试"]
    ROUTE -- "OK" --> WAIT["等待会议屏业务确认"]
    RECEIVE["会议屏收到定向 Flow"] --> CHECK{"来源、目标、载荷有效？"}
    CHECK -- "否" --> REJECT["拒绝案例处理"]
    CHECK -- "是" --> CACHE{"同 commandId 的当前 Activity 记录？"}
    CACHE -- "相同载荷" --> ACK["广播 meeting.displayed"]
    CACHE -- "冲突载荷" --> REJECT
    CACHE -- "无记录" --> APPLY["更新 TextView，缓存命令"]
    APPLY --> ACK
    ACK --> CONFIRM{"调度台匹配来源和 commandId/title/room？"}
    CONFIRM -- "是" --> DONE
    CONFIRM -- "否" --> IGNORE["不确认为当前命令"]
    START -. "路由 RPC 或 ACK 未在预算内完成" .-> HASACK
```

## 4. 构建、启动与操作

需要 Android SDK、JDK 和 ADB。以下操作固定小米 `925c23bb`；设备缺席或锁屏不能记为验收通过。

```powershell
.\gradlew.bat :app-server:assembleDebug :app-client1:assembleDebug :app-client2:assembleDebug :app-client3:assembleDebug
adb -s 925c23bb install -r app-server\build\outputs\apk\debug\app-server-debug.apk
adb -s 925c23bb install -r app-client1\build\outputs\apk\debug\app-client1-debug.apk
adb -s 925c23bb install -r app-client2\build\outputs\apk\debug\app-client2-debug.apk
adb -s 925c23bb install -r app-client3\build\outputs\apk\debug\app-client3-debug.apk
adb -s 925c23bb shell am start -W -n com.cn.ipc.server.app/.ServerMainActivity
adb -s 925c23bb shell am start -W -n com.cn.ipc.client2/.Client2Activity
adb -s 925c23bb shell am start -W -n com.cn.ipc.client3/.Client3Activity
adb -s 925c23bb shell am start -W -n com.cn.ipc.client1/.Client1Activity
```

先打开中枢，再打开会议屏、运维屏，最后打开调度台，并确认各客户端连接与订阅。客户端共有“多 App 案例：会议通知”业务卡和“暂停案例订阅 / 恢复案例订阅”按钮；它们控制原消息订阅流，暂停会影响该客户端全部 Flow 消息。

| 调度台按钮 | 观察结果 |
| --- | --- |
| 发布会议到会议屏 | client2 显示会议卡；client1、client3 显示同一 commandId 的展示确认。 |
| 广播会务通知 | client2、client3 显示通知，client1 显示发送状态。 |
| 仅向中枢上报 | 服务端界面及日志有该 commandId 的上报；client2、client3 无该上报载荷。 |

会话、会议卡与去重缓存均在内存中。切回现存 Activity 可查看本次状态，重建 Activity 不等于恢复之前会议。

## 5. 验收与当前证据

采集入口为 [capture_multi_app_case.py](benchmarks/harness/capture_multi_app_case.py)，默认只准备方案，`--execute` 才操作固定小米设备。执行前须已安装重建的四包，设备已唤醒解锁。脚本启动实际 Activity，通过仅 Debug 开放的 Intent 动作进入与可见按钮相同的业务路径；用新 run-id 保存源码/APK/UID、关联日志与客户端 UI。

```powershell
python docs/benchmarks/harness/capture_multi_app_case.py --run-id meetingcase1
python docs/benchmarks/harness/capture_multi_app_case.py --run-id meetingcase2 --execute
```

| 验收项 | 必须观察的证据 | 证明边界 |
| --- | --- | --- |
| 独立接入 | 四包 UID 不同，已安装 APK 哈希匹配，三客户端连接和订阅。 | 连接成功不证明业务投递。 |
| 发布与确认 | client2 会议卡更新；client1、client3 有同 commandId 的 displayed，真实来源/目标正确。 | ACK 只表示本地 TextView 赋值。 |
| 定向隔离 | client3 在同一采集窗口没有 meeting.show，可以有 meeting.displayed。 | 有限窗口不能证明任意时机绝无泄漏。 |
| 会务通知 | client2、client3 观察同一 meeting.notice。 | 不覆盖所有后台状态。 |
| 仅服务端上报 | 中枢有 meeting.audit，client2、client3 窗口内无该载荷。 | UI/Logcat 不是持久审计库。 |
| 暂停与恢复 | 暂停 client3 订阅，发送 noticeMiss；恢复后发送新通知，client3 收新消息、不补发此前消息，再发布新会议验证展示与确认。 | 路由 OK 不表示暂停端收到；未覆盖会议屏暂停导致确认超时。 |

**额外人工验收**：暂停会议屏 client2 订阅后发布会议，观察调度台 5 秒超时与恢复后无补发；在同一会议屏 Activity 内重复相同 commandId/载荷、再发送同 ID 冲突载荷，检查重发 ACK 与冲突拒绝。这些步骤目前不属于自动采集脚本的覆盖范围，不能记入脚本 PASS；也不覆盖 Activity 重建或缓存淘汰后的持久去重。

上表是验收条件，新采集完成前不能写成已通过。既有证据须区分：

- 2026-09-29 跨包短测验证了定向文本，保留在本文后半部分；未使用本案例 JSON 或会议卡。
- 2026-10-09 [crosspkg1 smoke](benchmarks/runs/2026-10-09-xiaomi14ultra/cross-package-smoke-crosspkg1/capture-result.json)检查了四包 UID/安装哈希、三客户端连接和服务端登记/observeMessages 工厂 UI；没有验证会议发布、业务确认、路由隔离或性能。
- 此前 `4494...` APK 完成 64 PASS/5 DONE 与完整请求 trace。之后握手构建 `402684...` demo APK 对应五应用构建及安装哈希校验通过，但新增 9 项握手探针与修复后完整设备回归尚未完成。会议案例新增源码后的构建身份单独见[案例报告](benchmarks/xiaomi14ultra_2026-10-09_multi_app_case.md)，设备验收为 NOT_RUN；不能沿用旧 APK 结果。前序记录见[冷发现与 trace 报告](benchmarks/xiaomi14ultra_2026-10-09_cold_trace_optimization.md)及[后续步骤](benchmarks/runs/2026-10-09-xiaomi14ultra/handshake-build/next-steps.md)。

本案例暂不提供业务实测延迟或 AndLinker 排名。echo RTT、跨包冷启动和“发布→展示确认”耗时是不同指标；后者包含解析、Main 更新和确认回程，需要独立测量。

## 6. 产品化需要补齐的能力

- **持久会议状态**：中枢存储会议与版本，会议屏连接后拉取最新快照。
- **持久命令与确认**：保存 commandId、目标及处理状态，以同一 ID 重试并去重；超时不得假设远端未执行。
- **会话管理**：定义订阅就绪、心跳租约和断线清理，不能把 registerClient 的返回或在线表文本当健康证明。
- **业务权限与审计**：定义发布者、房间和运维观察权限；SERVER_ONLY 是路由范围，不是持久审计能力。
- **后台运行策略**：按设备策略管理宿主和订阅，验证实际前后台条件；Activity 订阅不能证明长期无人值守能力。

本案例 JSON 独立版本化并转义控制字符，外层 MessageEnvelope 仍使用控制字符分隔；其他任意原始文本仍需要稳健编码。已启动的同步 Binder 不能强制中断，取消等待不能回滚远端已发生的效果。

## 7. 底层消息中枢交互

以下保留通用路由、接入要求及历史设备记录，便于区分 SDK、业务案例与已有实测证据。

### 应用角色和部署条件

| 应用 | 包名 | 业务身份 |
| --- | --- | --- |
| app-server | com.cn.ipc.server.app | Broker 与消息路由中枢 |
| app-client1 | com.cn.ipc.client1 | client_1，调度台与通用测试发送方 |
| app-client2 | com.cn.ipc.client2 | client_2，会议屏与定向接收方 |
| app-client3 | com.cn.ipc.client3 | client_3，运维屏与独立接收方 |

四个 APK 分属不同 UID，需以兼容签名安装。服务端 Service 在 Manifest 中导出并由 signature 级权限保护；客户端声明相应 uses-permission 和对服务端包的可见性。客户端使用显式 ComponentName 绑定。设备的后台启动策略仍可能拒绝首次唤醒；[小米实测](benchmarks/xiaomi14ultra_2026-09-29_smoke.md)观察到了这一点。

### 从连接到接收的调用链

```mermaid
sequenceDiagram
    autonumber
    participant C1 as Client 1
    participant B as Server Broker
    participant H as MessageHubServiceImpl
    participant C2 as Client 2
    participant C3 as Client 3
    C1->>B: bindService / 握手协商能力
    C1->>B: getServiceSchema(2001) / getServiceChecked(契约版本2)
    B-->>C1: 服务 Binder
    C1-)H: registerClient(client_1)
    C2-)H: registerClient + observeMessages(client_2)
    C3-)H: registerClient + observeMessages(client_3)
    C1-)H: sendMessage(client_1, client_2, 内容)
    H->>H: 校验调用 UID 对应身份并查找在线目标
    H-)C2: Flow 事件
    H-)C1: 业务回执
    Note over H,C3: client_3 无这条定向事件
```

1. 客户端 Activity 创建 IpcConnectionController 并调用 connect。连接成功后创建 IMessageHubServiceClientAdapter。
   生成代理在首次获取服务时逐事务检查 wire Schema，Broker 再校验；服务 2001 的客户端契约最低版本为 2。缓存按代次及预期签名隔离，旧 Broker 无严格方法时明确失败。
2. Activity 调用 registerClient(clientId, clientName)，再收集 observeMessages(clientId)。前者是 Oneway，方法返回不等于服务端已经完成登记。
3. 服务端 ServerBrokerService 的生成 Stub 校验接口 Token、调用方签名，以及与 UID 对应的 clientId；业务实现将身份写入内存在线表，创建或取得对应 SharedFlow。
4. 客户端调用 suspend sendMessage。请求经 Binder 到服务端，MessageHubServiceImpl 按 targetScope 路由，再由响应回调 Binder 返回文本回执。
5. 接收客户端的 Flow 收到编码后的 MessageEnvelope，Activity 解码并显示。订阅取消或连接断开后，客户端应清理 Job；连接恢复时重新登记身份并订阅。

当前生成 Flow 可正常完成或报远端错误，客户端缓冲溢出默认报错并退订。消息中枢的 SharedFlow 源仍可丢旧消息，因此默认溢出检测不能保证每条业务消息送达。生成 Async 入口默认 30 秒预算覆盖冷发现与 pending 等待；业务可设置更短超时，重试必须处理已执行的副作用。

Activity 销毁永久 dispose Controller，宿主 Service 销毁 dispose 注册 Stub。框架请求/订阅回收与业务在线表是不同资源：当前没有心跳过期或断线自动清理所有在线身份的协议。生命周期和终态验证见[顺序修复记录](benchmarks/xiaomi14ultra_2026-10-08_ordered_remediation.md)。

相关源码：[客户端 Activity](../demo-client-common/src/main/kotlin/com/cn/ipc/client/common/BaseClientActivity.kt)、[Broker 宿主](../app-server/src/main/kotlin/com/cn/ipc/server/app/ServerBrokerService.kt)、[消息中枢](../app-server/src/main/kotlin/com/cn/ipc/server/app/MessageHubServiceImpl.kt)。

### 三种路由

```mermaid
flowchart TD
    IN["sendMessage(fromClientId, targetScope, content)"] --> AUTH["ServerStub 身份校验"]
    AUTH --> SELECT{"targetScope"}
    SELECT -- "ALL" --> ALL["遍历已有 clientFlows，排除发送方"]
    SELECT -- "SERVER_ONLY" --> SERVER["服务端计数与界面日志"]
    SELECT -- "client_2 / client_3" --> ONLINE{"目标在线？"}
    ONLINE -- "是" --> TARGET["向目标 SharedFlow tryEmit"]
    ONLINE -- "否" --> ERROR["返回离线错误文本"]
    ALL --> ACK["返回业务回执"]
    SERVER --> ACK
    TARGET --> ACK
    ACK --> LIMIT["回执不等于接收端消费确认"]
```

| targetScope | 服务端行为 | 接收端观察 |
| --- | --- | --- |
| ALL | 遍历已有 clientFlows，排除发送方，向其流发送消息。 | 活跃订阅的其他客户端可收到；不保证离线补发，在线表不是完整投递凭据。 |
| client_2 或 client_3 | 找到对应在线身份，向该客户端的流 tryEmit。 | 仅目标身份的订阅应收到；发送方得到业务回执。 |
| SERVER_ONLY | 只更新服务端统计和界面日志，不向客户端流派发。 | 无客户端消息；这是示例业务行为，并非持久审计记录。 |

服务端对未知或离线目标返回错误文本。对在线目标返回的 “Delivered” 并不是最终消费确认：tryEmit 的结果未被用作可靠投递凭据，且 SharedFlow 采用 replay=0、容量 128 的额外缓冲、溢出丢旧值；无活跃订阅时不会保存待补发事件。在线表和路由计数也仅在进程内，服务端重启后重建。

### 通用消息路由的历史实测步骤

1. 构建并安装四个 Debug APK；命令见[根 README](../README.md)。
2. 打开服务端 Activity，确认服务绑定权限、签名和客户端包可见性配置一致。
3. 分别打开三个客户端，观察每个客户端连接状态、身份登记和订阅日志。
4. 在客户端 1 发送 ALL：检查客户端 2 和 3 的消息；发送 client_2：检查客户端 2 收到，并检查客户端 3 在同一日志窗口没有出现该消息；发送 SERVER_ONLY：检查服务端记录及客户端无派发。
5. 杀掉服务端或断开绑定，观察状态、退避重连、重新登记和重新订阅。分别记录请求失败数、业务回执与接收 UI，而不只看按钮提示。

2026-09-29 的小米设备短测仅覆盖了其中部分路径：两条发往客户端 2 的消息最终显示，客户端 3 在采集窗口内没有对应私信；后台状态下回执长达 37.411 秒和 77.895 秒。测试不能证明所有时机的稳定投递，也未证明延迟的唯一系统原因。原始日志见[设备报告](benchmarks/xiaomi14ultra_2026-09-29_smoke.md)。

### 业务集成边界

- clientId 与包名的映射在 ServerBrokerService 中硬编码，只适用于这三个示例客户端；新增应用要更新映射并重查权限。
- 每个客户端声明 `com.cn.ipc.server.app.permission.BIND_BROKER` uses-permission、服务端包 queries 与显式 ComponentName；服务端导出 Service 使用同名 signature 权限。同签名可绑定不等于自动获得房间或业务操作授权。
- 用户输入和 MessageEnvelope 内容经字符串协议传输。当前编码使用控制字符分隔；任意外部文本和协议演进需要更稳健的编码与版本化方案。
- 业务请求如需断线重试，先定义幂等消息 ID；当前 IpcAsync.idempotent 标注不会自动重放。
- 需要可靠推送时，先落库，再向客户端投递，并以客户端确认驱动重试。当前 Flow 是实时通知通道。

新增第五个 App 的实际接入顺序：引入公共 `ipc-api` 与 client runtime；声明绑定权限/包可见性并使用兼容签名；在宿主白名单增加新的包名→clientId；创建 Controller 和生成 ClientAdapter，在连接后预热、登记、订阅；为新角色定义可接受消息并修改业务接收校验。只改显示名称或 JSON 不能获取新的 Binder 身份，也不会自动加入当前会议角色。
