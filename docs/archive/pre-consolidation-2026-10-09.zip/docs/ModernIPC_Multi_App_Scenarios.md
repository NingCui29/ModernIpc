# ModernIpc 多 App 场景目录

本目录在原有会议通知案例之外，增加仓储工单、配置同步和遥测告警三个可操作场景。四个 APK 复用同一 Broker、消息中枢和 Flow 订阅；业务角色、载荷和完成条件各不相同。客户端场景选择器提供“会议通知 / 仓储工单 / 配置同步 / 遥测告警”，默认会议通知；只展示当前选中的业务卡片。

这是同一台 Android 设备上的独立 App 协作：客户端 2 的工单、配置和温度卡都是本地界面，客户端 3 是独立观察页面。案例没有驱动物理仓储设备、读取真实传感器或控制其他终端。

## 1. 场景与业务终态

| 场景 | client_1 | client_2 | client_3 | 业务完成条件 |
| --- | --- | --- | --- | --- |
| [会议通知与展示](ModernIPC_Business_Interaction_Guide.md) | 调度台发布会议 | 会议屏更新卡片、广播确认 | 运维屏观察确认与通知 | 收到匹配 commandId/title/room 的展示确认；仅表示页面数据已更新。 |
| [仓储工单](#3-仓储工单分派接单与人工完成) | 分派台下达工单、跟踪状态 | 执行台接单，用户点击完成 | 看板观察接单与完成 | 同一 commandId 的 completed；accepted 仅表示接单。 |
| [配置同步](#4-配置同步广播版本与逐端确认) | 管理台广播配置、汇总确认 | 显示端 A 更新自己的配置卡 | 显示端 B 更新自己的配置卡 | client_2 和 client_3 都确认同一版本与内容；一端确认不表示全体同步。 |
| [遥测告警](#5-遥测告警样本分析与告警广播) | 值班台观察告警 | 采集模拟器手工发送温度样本、观察告警 | 分析台判断阈值并广播告警 | 对指定异常样本生成告警并在 client_1、client_2 可见；正常样本不产生告警。 |

场景切换只改变可见业务卡片；连接和消息订阅仍由共同的 Activity 管理。各场景接收逻辑按业务类型处理消息，隐藏卡片照常更新其当前内存 TextView 数据并回传确认，收到消息不会自动切换场景。暂停订阅影响此 App 的全部场景和普通消息，恢复后没有历史消息补发。

### 四 APK 共用架构

```mermaid
flowchart LR
    subgraph D["同一 Android 设备 / 四个不同 UID"]
        C1["app-client1 / client_1<br/>分派、配置、值班"]
        H["app-server<br/>Broker + MessageHubServiceImpl<br/>签名 / UID 身份校验"]
        C2["app-client2 / client_2<br/>执行、显示、样本模拟"]
        C3["app-client3 / client_3<br/>看板、显示、阈值分析"]
        C1 -- "Async sendMessage<br/>定向 / ALL / SERVER_ONLY" --> H
        C2 -- "Async sendMessage<br/>确认 / 状态 / 样本" --> H
        C3 -- "Async sendMessage<br/>配置确认 / 告警" --> H
        H -- "observeMessages Flow" --> C1
        H -- "observeMessages Flow" --> C2
        H -- "observeMessages Flow" --> C3
    end
```

四包同签名安装，服务端由 signature 级权限保护，并按包名/调用 UID 绑定 clientId。接收逻辑还校验真实 MessageEnvelope.fromId 和 target，不以 JSON 自报身份代替调用身份。新增业务角色未增加 Binder 事务、服务 ID 或 Schema 版本。

## 2. 运行与观察方式

先按[会议业务指南的构建与启动步骤](ModernIPC_Business_Interaction_Guide.md#4-构建启动与操作)构建并安装 app-server、app-client1/2/3。测试只使用小米 `925c23bb`；先启动服务端，再启动客户端 2、3，最后启动客户端 1，确认连接与订阅。

在各客户端的场景选择器选择同一场景；按下面的角色步骤操作，再切换到接收端查看业务卡。同一时刻只有一个 Activity 在前台，切换页面观察不能证明全部 App 持续在前台。登记 Oneway 返回和“已启动订阅”提示都不表示远端 collector 已就绪，必须观察具体消息与业务状态。

三个新增场景共用 JSON 载荷族，所有字段必填；原会议仍使用 `case=meeting-board`，不会改为此载荷。字段中的业务版本与 Binder 服务契约版本分别维护。

```json
{
  "case": "multi-app-scenarios",
  "v": 1,
  "scenario": "settings",
  "kind": "settings.apply",
  "commandId": "settings-20261009-001",
  "title": "显示配置",
  "detail": "dark",
  "revision": 1,
  "value": 18
}
```

| 字段 | 约定 |
| --- | --- |
| case / v | 固定 `multi-app-scenarios` / 整数 `1`。 |
| scenario | `work-order`、`settings`、`telemetry`。 |
| kind | 只能是对应场景定义的事件，见下表。 |
| commandId | 匹配 `[A-Za-z0-9_-]{1,96}`；同一操作关联 ID；确认保留原始 ID 与业务字段，只改变 kind。 |
| title / detail | 都必须非空白且不超过 120 字符；工单标题/详情，配置标题/主题枚举，或样本标题/说明。 |
| revision | 必填 Long，必须大于 0；配置使用它比较版本。 |
| value | 必填 Int：工单固定 `0`；配置字号为 `18` 或 `14`；遥测温度为 `-40..125`，告警为 `30..125`。 |

| scenario | kind | 来源与路由 | 配置或状态字段 |
| --- | --- | --- | --- |
| work-order | `order.assign` | `client_1 → client_2` | 默认 revision=1、value=0。 |
| work-order | `order.accepted` / `order.completed` | `client_2 → ALL` | 保留工单的 commandId/title/detail/revision/value。 |
| settings | `settings.apply` | `client_1 → ALL` | detail=`dark` 或 `light`，value=18 或 14。 |
| settings | `settings.applied` | `client_2` 或 `client_3 → client_1` | 保留已应用配置全部字段。 |
| telemetry | `telemetry.sample` | `client_2 → client_3` | value 为手工演示温度，默认 25 或 35。 |
| telemetry | `telemetry.alert` | `client_3 → ALL` | 保留异常样本全部字段，value 至少 30。 |

`MessageEnvelope.messageId` 是中枢逐次生成的路由消息 ID，不能用来替代 commandId。配置确认、工单状态和告警都要匹配真实来源、路由与业务载荷。隐藏卡片发出的确认只表示业务数据已经赋值，不表示首帧绘制或用户看见。

实现入口为 [MultiAppScenarioMessage](../ipc-api/src/main/kotlin/com/cn/ipc/api/hub/MultiAppScenarioMessage.kt)、[MultiAppScenarioDemo](../demo-client-common/src/main/kotlin/com/cn/ipc/client/common/MultiAppScenarioDemo.kt) 和共同的 [BaseClientActivity](../demo-client-common/src/main/kotlin/com/cn/ipc/client/common/BaseClientActivity.kt)。JSON 解析拒绝超出 4096 字符、错误业务版本、字段缺失或类型/取值不符合契约的载荷。

`sendMessage` 的 `OK:` 是路由返回，不能代替以下场景的业务终态；离线目标可能以正常 String 返回 `ERROR:`。Flow 源为内存 SharedFlow，暂停、离线或缓冲丢弃时可能没有投递。超时和断线只能表示结果未知，不能证明远端未执行。

工单分派的 5 秒预算覆盖发送与接单确认，不限制用户之后何时点击完成；配置同步的 5 秒预算覆盖发送与两端确认。遥测和完成状态发送只限制路由等待，没有保证观察端消费的业务 ACK。连接变化会取消本地未完成 waiter，并将状态标为结果未知；不能自动撤销远端已经更新的页面或完成操作。

## 3. 仓储工单：分派、接单与人工完成

### 角色与业务价值

| APK | 角色 | 实际页面行为 |
| --- | --- | --- |
| app-client1 | 分派台 | 下达定向工单，显示待接单、已接单和已完成。 |
| app-client2 | 执行台 | 接收工单，更新本地工单卡并确认接单；用户点击完成后回传完成事件。 |
| app-client3 | 进度看板 | 观察广播的接单与完成事件，不接收原始定向工单。 |
| app-server | 中枢 | 身份校验和消息路由，不保存持久工单。 |

这个场景区分“执行端已经接单”和“用户点击了完成”。不能把 sendMessage 的路由返回或 `order.accepted` 当作工单完成。`order.completed` 是业务终态，迟到的 accepted 不得把状态改回已接单；完成后的相同工单重复到达时重发 completed，同 ID 冲突载荷拒绝处理。这些记录仅存在当前 Activity 内存中。

### 业务流程图

```mermaid
flowchart TD
    A["分派台：创建工单 / commandId"] --> B["定向分派给 client_2"]
    B --> C{"执行台：来源、目标、载荷有效？"}
    C -- "否" --> R["拒绝处理"]
    C -- "是" --> D["更新工单卡，广播 accepted"]
    D --> E["分派台：已接单<br/>看板：显示接单状态"]
    E --> F["用户在执行台点击完成"]
    F --> G["广播同 commandId 的 completed"]
    G --> H["分派台与看板：工单已完成"]
    B -. "未收到关联接单 / 断线" .-> U["结果未知，人工核对"]
```

### 时序图

```mermaid
sequenceDiagram
    autonumber
    participant C1 as 分派台 / client_1
    participant H as 消息中枢
    participant C2 as 执行台 / client_2
    participant C3 as 看板 / client_3
    C1->>H: order.assign / commandId → client_2
    H-->>C1: 路由结果
    H-)C2: Flow：工单
    Note over H,C3: 不向 client_3 派发原始定向工单
    C2->>C2: 校验身份与载荷，更新工单卡
    C2->>H: order.accepted / 同 commandId → ALL
    H-)C1: 关联接单状态
    H-)C3: 接单观察事件
    Note over C1,C3: accepted 不等于 completed
    C2->>C2: 用户点击完成
    C2->>H: order.completed / 同 commandId → ALL
    H-)C1: 关联完成状态
    H-)C3: 完成观察事件
```

### 操作与验收

1. 三个客户端选择“仓储工单”。客户端 1 点击“向执行屏下发工单”。默认标题为“出库复核工单”，详情为“复核 A-01 货位并完成出库”。
2. 在客户端 2 查看工单标题、详情和 commandId；客户端 1、3 应显示同一 ID 的已接单状态。
3. 在客户端 2 点击“完成当前工单”；客户端 1、3 应显示同一 ID 的已完成状态。
4. 观察窗口中客户端 3 可以收到 accepted/completed，但不应收到原始 assign。暂停客户端 3 订阅再操作，能演示看板缺失状态与恢复后无补发。

| 检查 | 合格证据 | 证明范围 |
| --- | --- | --- |
| 定向分派 | client_2 工单卡与真实来源/目标符合角色。 | 本地页面数据更新，不表示仓储硬件执行。 |
| 接单 | client_1、client_3 观察同 commandId 的 accepted。 | 执行端接单，不是工作完成。 |
| 人工完成 | 完成按钮触发后，两端观察同 commandId 的 completed。 | 演示用户操作终态，不证明物理任务完成。 |
| 定向隔离 | 同一采集窗口 client_3 没有 assign。 | 只覆盖该窗口。 |

**产品化边界**：需要数据库保存工单与状态、明确执行人权限、持久去重和状态转换规则。多执行端抢单、转派、取消、冲突处理、审计和物理完成证据需另外实现；当前 Activity 内存不承担这些保证。

## 4. 配置同步：广播版本与逐端确认

### 角色与业务价值

| APK | 角色 | 实际页面行为 |
| --- | --- | --- |
| app-client1 | 配置管理台 | 广播带 revision 的配置，分别跟踪两个显示端的确认。 |
| app-client2 | 显示端 A | 更新本地配置卡的颜色与字号，定向确认给管理台。 |
| app-client3 | 显示端 B | 独立校验版本、更新自己的卡片，定向确认给管理台。 |
| app-server | 中枢 | 发送 ALL 广播和定向确认，不维护权威配置版本。 |

本场景演示状态同步：单调递增 revision 限制旧配置覆盖新配置。detail 的 `dark`/`light` 选择业务卡颜色，value 的 `18`/`14` 选择业务卡字号，只改变配置演示卡，不改变 App 整体主题或系统设置。ACK 表示该端的配置卡数据已赋值；两个端都确认才表示本次两个目标均完成，不是跨 App 原子事务。

发布端也做检查：新 commandId 的版本必须高于当前 Activity 此前生成的版本；同一 commandId 的冲突载荷直接拒绝，不发往中枢。已保存的完整命令可重发，接收端再独立检查是否已经过期。因此“发送端拒绝”与“消息到达接收端后拒绝”是不同验收项，日志不能混记。

### 业务流程图

```mermaid
flowchart TD
    A["管理台：创建 revision 和配置内容"] --> B["apply 广播 → client_2 / client_3"]
    B --> C{"接收端 revision 与本地版本比较"}
    C -- "旧版本" --> R["拒绝覆盖，保留现有卡片"]
    C -- "同版本、不同命令或内容" --> X["拒绝冲突，保留现有卡片"]
    C -- "同版本、完整命令一致" --> ACK["重发 applied 确认"]
    C -- "新版本" --> D["更新本地配置卡，保存当前版本"]
    D --> ACK
    ACK --> E["定向 applied → client_1"]
    E --> F{"管理台匹配 revision / 内容 / 来源？"}
    F -- "是" --> G["记录该显示端已应用"]
    G --> H{"client_2 与 client_3 都确认？"}
    H -- "是" --> I["两个显示端本次同步完成"]
    H -- "否" --> W["等待另一端 / 结果未知"]
    F -- "否" --> N["不确认为本次版本"]
```

### 时序图

```mermaid
sequenceDiagram
    autonumber
    participant C1 as 管理台 / client_1
    participant H as 消息中枢
    participant C2 as 显示端 A / client_2
    participant C3 as 显示端 B / client_3
    C1->>H: settings.apply / revision / 配置 → ALL
    H-->>C1: 广播路由结果
    H-)C2: Flow：新版本配置
    H-)C3: Flow：新版本配置
    par 两端独立应用
        C2->>C2: 校验版本、更新颜色与字号
        C2->>H: settings.applied / 同 revision 与内容 → client_1
    and
        C3->>C3: 校验版本、更新颜色与字号
        C3->>H: settings.applied / 同 revision 与内容 → client_1
    end
    H-)C1: 两个独立来源的配置确认
    C1->>C1: 汇总 client_2 与 client_3 的确认
    Note over C1,C3: 一端成功、另一端缺席时不表示全体同步
    C1->>H: 旧 revision 或同 revision 冲突 → ALL
    H-)C2: 旧版本 / 冲突载荷
    H-)C3: 旧版本 / 冲突载荷
    C2->>C2: 拒绝覆盖
    C3->>C3: 拒绝覆盖
```

### 操作与验收

1. 三个客户端选择“配置同步”。客户端 1 点击“同步主题与字号（深/浅交替）”。默认标题为“案例卡显示配置”；第一次 dark/18，随后 light/14，版本在当前 Activity 内递增。
2. 客户端 2、3 的配置卡应显示相同 revision、内容、颜色和字号；客户端 1 应分别收到两端确认。
3. 客户端 1 再次点击发布下一版本，观察两端独立更新和确认。相同 revision 的不同 commandId 也被视为冲突，即使主题和字号相同；只有完整命令相同才可重发确认。
4. **额外手工/诊断，非自动脚本覆盖**：用受控业务载荷分别验收发送端检查和接收端检查。重复发送已保存的旧命令可观察接收端忽略旧 revision；同 ID 冲突和新 ID 非递增版本会先被发布端拒绝，不能以此证明接收端冲突分支已执行。普通按钮没有旧版/冲突注入动作，自动脚本只验证两个合法配置版本。
5. 暂停任一显示端订阅再发布新版本，管理台不能显示两个目标都已同步；恢复后只有随后新发送的配置可被处理，没有自动快照补齐。

| 检查 | 合格证据 | 证明范围 |
| --- | --- | --- |
| 两端应用 | 两端对应配置卡 revision、内容、颜色与字号一致。 | 局部演示卡，不修改其他 App 的全局系统设置。 |
| 逐端确认 | 管理台匹配来自 client_2 和 client_3 的 applied。 | 两端独立完成，非原子提交。 |
| 拒绝旧版本 | 接收端记录拒绝，卡片 revision 和样式未被旧版本覆盖。 | 当前 Activity 的版本记录。 |
| 拒绝冲突 | 相同 revision、不同内容不改变已应用卡片。 | 不覆盖进程重启后的持久冲突识别。 |

**产品化边界**：需要权威配置存储、持久 revision、连接后快照拉取、目标清单和缺席端状态。若有多个发布者，要定义版本分配与冲突解决；若要求所有 App 同时生效，还需单独设计准备、提交和恢复协议。当前广播加 ACK 不具备原子切换保证。

## 5. 遥测告警：样本分析与告警广播

### 角色与业务价值

| APK | 角色 | 实际页面行为 |
| --- | --- | --- |
| app-client1 | 值班台 | 显示分析台发出的告警。 |
| app-client2 | 样本模拟器 | 手工发送 25°C 或 35°C 样本给分析台，并显示告警。 |
| app-client3 | 分析台 | 显示定向样本，按 30°C 阈值判断，异常时广播告警。 |
| app-server | 中枢 | 路由定向样本和告警，不参与阈值计算。 |

25°C/35°C 来自演示按钮，非真实传感器读数。本场景演示“数据由一个 App 产生、由另一个 App 解释、结果广播给其他角色”，阈值计算发生在客户端 3。

### 业务流程图

```mermaid
flowchart TD
    A["客户端 2：用户选择 25°C / 35°C"] --> B["sample / commandId 定向 → client_3"]
    B --> C{"分析台校验来源、目标、数值"}
    C -- "无效" --> R["拒绝分析"]
    C -- "有效" --> D["更新分析台样本卡"]
    D --> E{"温度达到 30°C 告警阈值？"}
    E -- "否" --> N["显示正常样本，不广播告警"]
    E -- "是" --> F["alert / 同样本 commandId → ALL"]
    F --> G["client_1 值班卡 / client_2 告警卡更新"]
```

### 时序图

```mermaid
sequenceDiagram
    autonumber
    participant C2 as 样本模拟器 / client_2
    participant H as 消息中枢
    participant C3 as 分析台 / client_3
    participant C1 as 值班台 / client_1
    C2->>H: telemetry.sample / commandId / 25°C → client_3
    H-->>C2: 路由结果
    H-)C3: 定向样本
    C3->>C3: 校验、更新卡片，低于阈值
    Note over C1,C3: 正常样本不产生新告警
    C2->>H: telemetry.sample / 新 commandId / 35°C → client_3
    H-)C3: 定向异常样本
    C3->>C3: 校验、更新卡片，达到阈值
    C3->>H: telemetry.alert / 异常样本 commandId → ALL
    H-)C1: 告警事件
    H-)C2: 告警事件
    Note over H,C1: client_1 不接收原始定向 sample
```

### 操作与验收

1. 三个客户端选择“遥测告警”。在客户端 2 点击“发送正常温度 25°C”。默认标题为“仓库温度”，详情为“按钮预置温度样本”。
2. 客户端 3 的“最近样本”卡显示对应 commandId 和 25°C；观察窗口内客户端 1 没有该样本的新告警。
3. 客户端 2 点击“发送高温 35°C”。客户端 3 显示异常样本，客户端 1、2 显示同一样本 commandId 的告警。
4. 客户端 1 不应收到原始 sample；客户端 3 是告警发送方，ALL 默认排除发送者，不能要求它经自己的 Flow 收到自身告警。

| 检查 | 合格证据 | 证明范围 |
| --- | --- | --- |
| 正常样本 | 分析台样本卡为 25°C，对应 ID 无新告警事件。 | 有限观察窗口，不证明告警引擎长期稳定。 |
| 异常样本 | 分析台为 35°C；client_1、client_2 告警卡对应同一 ID。 | 手工演示样本的单次链路。 |
| 来源与隔离 | sample 仅来自 client_2 并发往 client_3；alert 来自 client_3 并发往 ALL。 | 不覆盖其他任意角色或伪造载荷的全部安全场景。 |

**产品化边界**：需要真实数据源、采样时间与设备身份、数据缺失/乱序处理、持久告警、去重、抑制/滞回和解除规则，以及人员确认与升级路径。当前告警卡是最近事件记录；正常样本不等于一套持久告警的解除，不承担安全监控或硬件保护职责。

## 6. 验收记录与证据边界

新场景当前没有小米设备实测结果，不能将本文的流程图或验收条件写成已通过。源码和构建状态将单独记录在[新增场景报告](benchmarks/xiaomi14ultra_2026-10-09_more_scenarios.md)。原会议构建、旧跨包 smoke、框架 64 项回归和 echo 性能记录仍使用各自 APK 与采样条件，不证明这三个新增业务链。

计划入口为 [capture_multi_app_scenarios.py](benchmarks/harness/capture_multi_app_scenarios.py)。默认只准备，`--execute` 才操作固定小米 `925c23bb`；每次使用新 run-id，保存源码/APK 哈希、不同 UID、业务关联日志与对应 UI 卡。

```powershell
python docs/benchmarks/harness/capture_multi_app_scenarios.py --run-id scenariosprepare1
python docs/benchmarks/harness/capture_multi_app_scenarios.py --run-id scenarios1 --execute
```

设备验收至少分别覆盖工单 accepted/completed、配置双端 applied/旧版/冲突、正常样本与异常告警，不能以“连接成功”替代全部场景 PASS。暂停订阅、断线、Activity 重建与长期后台应另设条件和记录；没有覆盖的条件不能默认通过。

自动脚本覆盖合法业务链中的工单 accepted/completed、两个合法配置版本的双端 applied，以及正常样本与异常告警；旧版、冲突和故障场景属于额外手工/诊断，不计入自动脚本通过项。每个场景的自动回复最多保留一个本地 waiter，新回复取消旧回复的等待；已经启动的 Binder 仍可能在远端完成。快速连续配置、并发多样本和多条确认不能据此认为每个事件都可靠交付。

若要衡量业务性能，应测量每条链从发送到业务终态的耗时：工单接单与用户完成分别计时；配置分别记录两个端应用时间；遥测分别记录分析与告警可见时间。人工完成时间包含人的操作，不能当作 IPC RTT，也不能与既有 echo 或 AndLinker 数据直接比较。

## 7. 接入真实业务的选择

| 业务需求 | 可以复用的案例路径 | 需要应用补齐 |
| --- | --- | --- |
| 多端执行任务 | 定向 assign → accepted → completed | 持久工单、执行权限、抢单/取消/转派及副作用去重。 |
| 多端显示同一配置 | 版本 apply 广播 → 各端 applied | 权威版本、快照恢复、缺席端策略、必要时提交协议。 |
| 独立分析数据与告警 | 定向 sample → 分析 → alert 广播 | 真实数据源、持久告警、时间/乱序、抑制与解除。 |
| 会议展示或信息发布 | [meeting.show → meeting.displayed](ModernIPC_Business_Interaction_Guide.md) | 内容存储、发布权限、首帧或物理屏验收。 |

增加第五个 App 还需在服务端包名→clientId 白名单中定义身份、配置签名权限与包可见性，并实现它可接受的业务消息和角色校验。仅增加 JSON 字段、显示名称或下拉项不会自动获取新的 Binder 身份。SDK 接入方法见[SDK 指南](ModernIPC_SDK_Guide.md)，底层调用链见[架构文档](ModernIPC_Architecture.md)。
