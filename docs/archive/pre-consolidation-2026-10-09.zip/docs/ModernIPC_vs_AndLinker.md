# ModernIpc 与 AndLinker 详细对比

对比基准：ModernIpc 为本仓库 2026-10-09 工作区源码；AndLinker 固定为已核对的[上游提交 7ae01bfd](https://github.com/codezjx/AndLinker/tree/7ae01bfd87ddcf021319148a8727a95345cf350e)。当前已实现可取消冷发现、关闭时作废发现容器、Async 入口截止，并接入默认关闭的请求 trace；冻结 5C8CE... APK 完成功能门禁、跨包 smoke 与完整 trace 采集，详细分析及后续实验状态见[本轮报告](benchmarks/xiaomi14ultra_2026-10-09_cold_trace_optimization.md)。前序阶段 1、2、3 的独立 APK 门禁、阶段 4 同 APK 性能/取消竞争及 52 项功能回归保留在[顺序修复报告](benchmarks/xiaomi14ultra_2026-10-08_ordered_remediation.md)；阶段 3 初次失败与修复过程也保留。本轮没有重新运行 AndLinker 性能测试，历史两库比值不能作为当前版本的速度排名。

模块与调用链见[架构分析](ModernIPC_Architecture.md)，优化推理与历史变体见[优化分析](ModernIPC_Optimization_Analysis.md)。

## 1. 接口模型与实现对比

ModernIpc 面向 Kotlin suspend/Flow 接口、跨应用消息中枢和统一连接管理。AndLinker 面向 Java 接口代理、同步或回调式调用，并提供 RxJava 适配。两者都基于 Android Binder；以下差异来自指定版本的实际调用链。

| 维度 | ModernIpc 当前源码 | AndLinker 7ae01bfd |
| --- | --- | --- |
| 接口与生成 | IpcFacade 配合 IpcAsync、IpcDirect、IpcStream、IpcOneway，KSP 生成 ClientAdapter、ServerStub 与逐事务 Schema。Broker 使用 AIDL，业务使用生成的 Parcel/Binder 协议。 | RemoteInterface 配合 Java Proxy，运行时解析并缓存 ServiceMethod；服务端缓存 MethodExecutor，底层使用 ITransfer。 |
| 同步调用 | IpcDirect 在一次同步 Binder 事务中返回；客户端拒绝主线程调用，服务端在 Binder 分发线程执行。Broker 握手、冷发现和流订阅仍使用同步事务；冷发现由专用 worker 执行，同步解析冷缓存在 Main 上拒绝。 | RemoteCall.execute 执行同步 ITransfer 调用；调用线程等待远端返回。 |
| 异步调用 | suspend 使用单向请求加独立回调 Binder，PendingCallRegistry 恢复 continuation；服务端由 IpcRequestTracker 管理业务 Job。 | enqueue 在线程池执行原有远程调用，再交付 Callback；提供 RxJava 1/2 CallAdapter。 |
| 请求截止 | 生成 Async 默认 30 秒入口预算覆盖可取消冷发现和 pending，可由 Controller 配置；已登记请求在截止时向捕获的原 Binder 发送取消。Flow 仅限制发现等待；Direct 业务与已开始的同步 transact 不会被强制中断。 | RemoteCall 没有等价的远端 Job 截止机制；应用需设计超时与业务取消。 |
| 取消与清理 | Async 按 UID、回调 Binder、请求 ID 定位远端 Job；服务端 dispose 取消请求、订阅及宿主 scope。取消不回滚副作用，也不保证停止非协作业务。 | RemoteCall.cancel 设置本地标志，没有对应的远端取消事务。RemoteCallbackList 管理 Callback Binder，不代表远端业务任务已取消。 |
| 持续事件 | IpcStream 按连接代次创建 Flow observer；有 NEXT、COMPLETE、ERROR。默认缓冲满时显式失败，CONFLATE 允许合并状态值。断线可重订阅，旧代次事件被过滤。 | 支持跨进程 Callback；持续事件的完成、错误、背压与重订阅由应用接口定义。Rx 单次调用适配不能直接等同于 Flow 订阅。 |
| 单向调用 | IpcOneway 使用 FLAG_ONEWAY；提交成功不等于业务完成，没有回执或远端取消。 | OneWay 通过单向 ITransfer 执行，同样没有业务完成回执。 |
| 类型支持 | WireTypeModel 统一校验、生成 codec 与 Schema：非空 String、Int、Long、Boolean、ByteArray、实际实现 Parcelable 的无泛型类型；Flow 元素另支持 Float、Double。拒绝任意 DTO、可空类型、泛型及未支持返回类型。Async Unit 暂不支持，Oneway 返回 Unit。 | README 列出基本类型、String、CharSequence、Parcelable、List、Map 及 In/Out/Inout；具体嵌套组合与参数方向应编译、实测。 |
| 协议发现 | 主版本校验与实际能力交集；严格发现检查 serviceId、版本区间、descriptor、客户端要求的逐事务签名。签名包含调用方式、事务关联、codec 与回复/终态封装。 | 绑定指定 Service 获得 ITransfer；没有等价的 serviceId、逐事务 Schema 与版本区间协商。 |
| 热路径缓存 | 服务 Binder 按 generation、serviceId、minApiVersion、Schema fingerprint 隔离；命中时不重复元数据 RPC 或摘要计算。同一 Controller 同键冷发现共享结果；Schema 构造时冻结，校验与写入 Parcel 使用同一快照。 | ServiceMethod 与 MethodExecutor 均缓存；动态代理和反射不能被描述为每次重新扫描接口。 |
| 生命周期 | close 关闭当前连接并允许重连；dispose 永久释放且拒绝新连接。关闭置换/作废发现容器并唤醒 waiter，不 join 冷发现 RPC；晚结果不进入新容器。控制 scope 独立于 owner，owner Job 最终完成后自动 dispose。覆盖绑定超时、onNullBinding、onBindingDied 与 Binder 死亡。 | ServiceConnection 通知连接与断开；未见内建退避重连循环，宿主负责绑定、解除和重连策略。 |
| 重连与设备策略 | 默认最多 10 次，基值从 500 ms 增长并封顶 30 s，另加抖动。仍受小米跨包唤醒及后台策略约束。 | 宿主自行实现重连；Binder 绑定仍受系统和厂商策略约束。 |
| 并发资源 | 同一进程/classloader 的发现预算最多 4 个 worker、无排队，饱和时新冷发现拒绝。每 Stub 默认 128 个 Async 在途请求，超限返回 SERVER_BUSY。Direct/Oneway 不经过该限额，Flow 没有订阅数量上限；BoundedDispatcher 未接入默认链路。 | Dispatcher 的 ThreadPoolExecutor 最大线程数为 Integer.MAX_VALUE；突发 enqueue 的资源上限需由应用控制。 |
| 鉴权 | CallerAuthenticator 检查 UID 与服务端同签名；跨包示例另有 signature 绑定权限。Parcelable 请求先鉴权再反序列化。 | ITransfer 分发未见强制同签名校验；由宿主 exported、permission 与业务鉴权决定。 |
| 重试与可靠投递 | idempotent 未驱动业务自动重放；重连不等于 RPC 重试。流重订阅不补历史，消息示例没有持久化、确认或去重保证。 | 重试、事件恢复与持久可靠投递由宿主实现。 |
| 双栈与适配 | ModernIpcRouter 固定选择 Modern，AndLinker 回退未接入；RxIpcExtensions 未启用。 | 可独立使用；本仓库没有已验证的自动双栈切换。 |

ModernIpc 核对入口：[连接与缓存](../ipc-runtime-client/src/main/kotlin/com/cn/ipc/client/IpcConnectionController.kt)、[客户端生成器](../ipc-compiler/src/main/kotlin/com/cn/ipc/compiler/ClientAdapterGenerator.kt)、[服务端生成器](../ipc-compiler/src/main/kotlin/com/cn/ipc/compiler/ServerStubGenerator.kt)、[统一类型模型](../ipc-compiler/src/main/kotlin/com/cn/ipc/compiler/WireTypeModel.kt)、[Schema 契约](../ipc-contract/src/main/kotlin/com/cn/ipc/ServiceSchema.kt)、[Broker 校验](../ipc-runtime-server/src/main/kotlin/com/cn/ipc/server/IpcBrokerStub.kt)、[请求跟踪](../ipc-runtime-server/src/main/kotlin/com/cn/ipc/server/IpcRequestTracker.kt)。

AndLinker 核对入口：[README](https://github.com/codezjx/AndLinker/blob/7ae01bfd87ddcf021319148a8727a95345cf350e/README.md)、[AndLinker.java](https://github.com/codezjx/AndLinker/blob/7ae01bfd87ddcf021319148a8727a95345cf350e/andlinker/src/main/java/com/codezjx/andlinker/AndLinker.java)、[RemoteCall.java](https://github.com/codezjx/AndLinker/blob/7ae01bfd87ddcf021319148a8727a95345cf350e/andlinker/src/main/java/com/codezjx/andlinker/RemoteCall.java)、[ITransfer.java](https://github.com/codezjx/AndLinker/blob/7ae01bfd87ddcf021319148a8727a95345cf350e/andlinker/src/main/java/com/codezjx/andlinker/ITransfer.java)、[Dispatcher.java](https://github.com/codezjx/AndLinker/blob/7ae01bfd87ddcf021319148a8727a95345cf350e/andlinker/src/main/java/com/codezjx/andlinker/Dispatcher.java)、[LinkerBinderImpl.java](https://github.com/codezjx/AndLinker/blob/7ae01bfd87ddcf021319148a8727a95345cf350e/andlinker/src/main/java/com/codezjx/andlinker/LinkerBinderImpl.java)。

## 2. 架构与调用链

~~~mermaid
flowchart LR
    subgraph M["ModernIpc：编译期生成与服务发现"]
        M1["Kotlin 业务接口"] --> M2["KSP ClientAdapter + Schema"]
        M2 --> MC["Controller：绑定、代次、Binder 缓存"]
        MC -->|"可取消等待 / 同键共享"| MW["ServiceDiscoveryCache：进程内最多4 worker"]
        MW -->|"锁外同步冷发现"| MB["AIDL Broker：鉴权与 Schema 校验"]
        MB --> MS["生成 ServerStub"]
        MC -->|"缓存命中，业务 transact"| MS
        MS -->|"Async"| MJ["IpcRequestTracker / 业务 Job"]
        MJ --> MR["独立回调 Binder / continuation"]
        MS -->|"Direct"| MD["业务执行 / 同步 reply"]
        MS -->|"Stream"| MF["订阅 Job / observer 终态"]
    end
    subgraph A["AndLinker：运行时解析与缓存"]
        A1["Java 业务接口"] --> A2["Proxy / 缓存 ServiceMethod"]
        A2 --> A3["RemoteCall"]
        A3 -->|"execute"| A4["ITransfer"]
        A3 -->|"enqueue"| AQ["Dispatcher"]
        AQ --> A4
        A4 --> A5["LinkerBinderImpl / 缓存 MethodExecutor"]
        A5 --> A6["业务对象 / 同步 Response"]
        A6 --> A7["调用方结果或 Callback"]
    end
~~~

ModernIpc Async 的请求经过“单向业务事务 → 服务端 Job → 回调事务 → 协程恢复”。AndLinker enqueue 在线程池中执行同步远程调用，业务结果仍从原事务 reply 返回。两者的异步入口相似，取消、截止、调度和 Binder 往返结构有实际差异。

### 严格发现：冷路径与热路径

~~~mermaid
sequenceDiagram
    participant C as ClientAdapter
    participant K as Controller
    participant W as 发现 worker
    participant B as Broker
    participant S as ServerStub
    C->>K: 指定代次、serviceId、最低版本与 Schema
    alt 无可用缓存
        K->>W: 同键共享 / 等待可取消 / 有限预算
        W->>B: getServiceSchema(serviceId)
        B-->>W: 版本区间、descriptor、事务签名
        W->>W: 核对连接与需求 / 本地检查版本与事务
        W->>B: getServiceChecked(minApiVersion, 冻结 Schema)
        B->>B: 再次鉴权并检查版本、descriptor 与事务
        B-->>W: 已验证业务 Binder
        W->>W: 核对连接与需求 / 发布到原容器
        W-->>K: 发现结果
    else 相同键且 Binder 存活
        K->>K: 读取缓存，不请求元数据
    end
    K-->>C: 业务 Binder
    C->>S: 按生成协议调用
~~~

Async 在调用入口建立预算再执行上述 await，pending 使用 WithinDeadline 延续外层预算；该底层 primitive 不自行创建截止，手写调用者必须提供外层截止。Flow 只限制上述发现阶段，不给长期业务流设置整段超时。最后 waiter 退出后放弃发现，关闭作废旧容器；已开始的 Binder 不会被强制中断，取消检查到下一次 RPC 仍有竞态。同步冷解析在 Main 上 fail-fast，Oneway 的 Main 入口先挂起预热。详见[SDK 接入](ModernIPC_SDK_Guide.md)与[本轮报告](benchmarks/xiaomi14ultra_2026-10-09_cold_trace_optimization.md)。

握手能力为客户端请求位与服务端支持位的交集，定义了 SCHEMA_CHECKED_SERVICES、STREAM_TERMINALS。新生成客户端要求严格 Schema 发现，旧 Broker 不支持时拒绝，不能解释成自动降级。服务端要求客户端使用的事务子集匹配，允许在版本区间内新增其他方法。客户端版本须落在服务端最低兼容版本与 API 版本之间；旧 getService 无法证明客户端版本，服务最低兼容版本高于 1 时拒绝该入口。

Schema 检查 descriptor、事务号、参数/返回 codec、调用模式、回复封装和取消/退订关联。Parcelable 以类名和 opaque codec 标识，其字段布局未递归证明。apiHash、sessionId、nonce 未形成业务帧校验或会话绑定；maxInlinePayloadBytes 仍为声明值，未形成发送限额或大数据方案。

阶段 3 初次小米探针发现，Broker 业务拒绝抛出的 RemoteException 不能通过 Java Binder 的 Parcel.writeException 正常编码，导致客户端没有拿到预期拒绝原因。修复改用可传输的 IllegalArgumentException，鉴权仍保留 SecurityException；修复后的 compat3 已通过完整设备门禁。客户端协议不兼容使用 IpcCompatibilityException。

### 流终态与取消

| 情况 | ModernIpc 当前处理 | AndLinker 对应边界 |
| --- | --- | --- |
| 数据 | observer code 1，保持原裸 payload；连接实例与代次有效时接收。 | Callback 方法传数据，协议由应用定义。 |
| 自然完成 | code 2 COMPLETE；服务端与客户端终态各只接受一次，collector 正常结束。 | 应用定义完成回调，没有相同的通用终态帧。 |
| 业务异常 | code 3 ERROR 携带 String；客户端以异常结束流。 | 应用定义错误回调与异常传播。 |
| 慢消费者 | 默认 ERROR 显式报溢出；CONFLATE 合并中间状态。 | 应用或 Rx 层决定缓冲、丢弃和背压。 |
| collector 取消 / observer 死亡 | 安静退订并取消远端订阅 Job，不附加远端错误。 | RemoteCallbackList 管理死亡 Callback，业务任务取消需应用实现。 |
| 服务端 dispose / scope 已取消 | 拒绝新任务并终结已有协作任务；错误终态有兜底，取消异常不误报 COMPLETE。 | 宿主定义任务生命周期与终态。 |
| 断线 / 重连 | 旧 observer 失效，向捕获的旧 Binder/subId 退订，新代次重订阅；不补断线事件。 | 宿主定义绑定、注册和事件恢复。 |

Async 保持旧请求布局。原生安全参数在识别尾部回调后校验，用原有 String 错误回包；Parcelable 仍先鉴权再反序列化。坏 token、截断请求及无法安全识别回调的非法帧由客户端截止兜底，不通过猜测 Binder 帧尾绕过鉴权。当前生成 Async 的入口截止还覆盖冷发现等待，不能强行停止同步 Binder 调用。原始终态实测范围见[阶段 2 报告](benchmarks/xiaomi14ultra_2026-10-08_ordered_remediation.md#阶段-2请求与流终态)，冷发现修复另按[本轮报告](benchmarks/xiaomi14ultra_2026-10-09_cold_trace_optimization.md)验收。

## 3. 跨应用消息业务流程

下图描述 ModernIpc 消息中枢示例。AndLinker 可以承载同类接口，但注册、路由、订阅恢复和确认由宿主实现，库中没有等价消息中枢。

~~~mermaid
sequenceDiagram
    participant A as 客户端 A
    participant H as IMessageHubService
    participant R as 中枢注册与路由
    participant F as 客户端 B 的 Flow
    A->>H: registerClient / 单向登记业务身份
    H->>R: 校验并登记客户端
    F->>H: observeMessages / 生成层传入 observer
    H-->>F: 返回订阅标识 subId
    A->>H: sendMessage(fromClientId, targetScope, content)
    H->>R: 校验身份并查找接收方
    R-->>F: 发布消息 / NEXT
    R-->>H: 路由处理结果
    H-->>A: Async 请求结果
    Note over A,F: NEXT 与回执的观察次序不保证，回执不证明消费或持久化
    alt 连接变化
        F->>H: 向旧 Binder/subId 退订
        F->>H: 新代次重新订阅
        Note over R,F: 没有历史重放或消费确认
    else 永久释放
        F->>H: 取消订阅
        Note over H,F: dispose 结束本地流并回收协作任务
    end
~~~

终态处理与消息可靠投递属于不同层次。示例 SharedFlow 的 DROP_OLDEST 可能在进入 IPC 前丢值；客户端 CONFLATE 也允许合并状态。MessageEnvelope 已有服务端内存计数生成的消息 ID；可靠投递仍需持久化、接收确认、重放和去重。COMPLETE 或取消清理不能证明这些能力。

## 4. 顺序修复：源码与小米证据

测试限定 Xiaomi 14 Ultra（925c23bb、Android 16）。各阶段是独立 Debug APK，不能把样本当成同一构建。原始日志与状态见[顺序修复报告](benchmarks/xiaomi14ultra_2026-10-08_ordered_remediation.md)。

| 阶段 | 当前实现 | 已记录设备证据 | 验收边界 |
| --- | --- | --- | --- |
| 1：生命周期 | 独立控制 scope；close/dispose 分离；按代次 observer 与捕获 Binder 清理；Service.onDestroy 释放注册 Stub；Job 完成后移除计数。 | lifecycle1：22 PASS、DONE。服务由锚定连接保活，8 轮关闭/重连后请求与订阅归零；真实请求关闭、dispose、owner 完成、Service 销毁重建、空绑定与绑定超时通过。 | owner 自动释放在 Job 最终完成时触发；非协作任务与同步调用不承诺被中断。onBindingDied 仅构建覆盖，未制造系统事件；业务自建任务不全在计数内。 |
| 2：请求与流终态 | Async 默认截止；Flow COMPLETE/ERROR 与唯一终态；默认溢出错误、可选 CONFLATE；可识别前置错误回包。 | terminal1：8 PASS、DONE。有限流 1/2/3 后完成、运行时错误、溢出清理、CONFLATE 末值 999、显式取消、150 ms 截止、raw null 回包、坏 token 截止通过。 | 阶段 2 当时只限制注册等待，当前 Async 已覆盖冷发现；Direct 不受业务截止中断。源流仍可丢值，非法 Parcelable 不绕过鉴权。 |
| 3：协议兼容 | 逐事务 Schema、统一类型模型、能力交集、严格双端发现、版本区间、冻结 Schema 与缓存隔离已落地。 | compat3：16 PASS、DONE。17 个事务元数据、真实旧版事务子集调用、双端拒绝、Schema 缓存隔离、冻结 Map、旧发现限制及热缓存/重连通过。初次失败日志保留。 | 旧 Broker 是同 UID 方法可用性夹具，非历史 APK 完整升级矩阵；未测跨 UID 授权变化。Parcelable 字段兼容未被证明。 |
| 4：性能 | PendingCallRegistry 的 3 个 AtomicBoolean 合并为 1 个 AtomicInteger，保持协议、截止和取消语义；同 APK 保留完整旧版 Registry。 | pendingperf1/2 各 12 PASS、DONE，共 32 个 IPC 块；第三组 pendingperf3awake 另有 12 PASS、16 个 IPC 块，各块 1000 次。最终同 APK 功能回归 52 PASS。 | 分配约减少 48 B/次；前两组缺少起止状态记录，第三组 16 字符摘要变慢且有未定位长尾。未证明固定 RTT 增益；无新版 AndLinker 配对。 |

阶段 1 APK SHA-256：59ACE43ADCF5C9275AC62FDFC9DB366DECD530765BD371B47BC563D2DE10BAB3。
阶段 2 APK SHA-256：14124F10BA7417152BF7380E88F429638ED5BCA9C95142DE6F2846ABF6E150A1。
阶段 3 APK SHA-256：CEA7244D318B31786621AD19B93EAEA7F9C0BD5969A7D1F5C5DAF472E3E24FD2。
阶段 4 APK SHA-256：49C58DAA156DA8CEE1A79AAD11033D78DC65860680F3FEC27F70948AFC5DC4B4。
各阶段本地产物与设备 base.apk 分别匹配；阶段 4 三组及最终 52 项回归使用同一 APK。计数是并发快照，归零来自真实 Job 完成后的移除，不等于 join，也不覆盖所有业务自建资源。

阶段 3 的 100 次生成 Direct 热调用只出现 metadata=1、checked=1；同 Stub 锚定后的关闭/重连使 generation 递增、两项发现计数各到 2。构造后修改输入 Map 不改变 fingerprint，真实 Broker wire 与 Controller 使用原快照；copy 后的新 Schema 被双端拒绝。旧 Broker 夹具缺少 Schema 方法时严格客户端失败，legacyFallbacks=0。详见顺序报告的场景表，不能扩大为所有历史版本的升级验证。

### 阶段 4：同 APK 完整 Registry 对比与范围

2026-10-08，仍为 Xiaomi 14 Ultra（925c23bb、Android 16）。同一 Debug APK 内同时保留冻结的旧版完整 PendingCallRegistry 与生产优化版，通过相同适配入口、callback Binder、事务 10/11 与 String codec 调用同一 echo 服务。切换前确认两边 pending 和服务端 Job 归零。本地 TIME 在同一线程运行，ALLOC 单独采集进程级 ART 计数；IPC 按 ABBA 顺序交替，并反转 16/1024 字符顺序。这一夹具比较完整 Registry 与相同 wire 的调用，不等于所有生成 ClientAdapter 开销或两库对比。

前两组各有 12 条取消/回复/截止竞争 PASS 和 DONE；合计 32 个 IPC CSV、32000 个有效调用，返回值校验正确。前两组没有保存测试起止 power/activity 快照，不能严谨声明整个测量窗口前台，也不与后续有状态记录的数据合并为前台增益。原始分析：[pendingperf1](benchmarks/runs/2026-10-08-xiaomi14ultra/ordered-performance/analysis.json)、[pendingperf2](benchmarks/runs/2026-10-08-xiaomi14ultra/ordered-performance-repeat/analysis.json)；安装包与源码：[第一组证据](benchmarks/runs/2026-10-08-xiaomi14ultra/ordered-performance/evidence.json)、[第二组证据](benchmarks/runs/2026-10-08-xiaomi14ultra/ordered-performance-repeat/evidence.json)。

| 运行 / 本地情景 | 旧版分配 B/次 | 优化版分配 B/次 | 变化 |
| --- | ---: | ---: | ---: |
| pendingperf1 / immediate | 897.188 | 849.674 | −5.30% |
| pendingperf1 / parcel | 929.628 | 881.295 | −5.20% |
| pendingperf2 / immediate | 897.516 | 849.510 | −5.35% |
| pendingperf2 / parcel | 929.464 | 881.295 | −5.18% |

源码确定每个请求的原子状态对象从 3 个减少到 1 个。另一个测量结论是，前两组进程级近似分配都减少约 48 B/次；该数值包括客户端进程中的其他分配，不能当作两个对象的精确尺寸，也不能直接换算成 RTT 增益。每个 ALLOC 批次为 50000 次完整 Registry 调用。

线程 CPU 摘要在 immediate 情景降低约 11.5%–11.8%，parcel 降低约 1.4%–2.8%，但批次随预热与运行顺序明显漂移：旧版 immediate 从两组首批约 40.6/40.8 μs 降到末批 29.3/30.2 μs，优化版后批约 29.7/30.4 μs。当前数据无法将整个 CPU 摘要差归因于状态合并，也不能推出进程总体 CPU 的固定下降。

| 运行 / 入参 | 旧版 P50 摘要 ms | 优化版 P50 摘要 ms | 摘要变化 |
| --- | ---: | ---: | ---: |
| pendingperf1 / 16 字符 | 0.566250 | 0.493802 | −12.79% |
| pendingperf1 / 1024 字符 | 0.590000 | 0.544897 | −7.64% |
| pendingperf2 / 16 字符 | 0.761980 | 0.500521 | −34.31% |
| pendingperf2 / 1024 字符 | 0.765730 | 0.584427 | −23.68% |

摘要为每组四轮 P50 的中位数。四个摘要均较低，但两组幅度差异明显，16 个 size/round 配对有 4 次优化版 P50 更高；逐轮 P99、最大值和变化均保留在原始分析中。因此当前可确认分配减少及取消竞争通过，IPC 是指定条件下的观测结果，尚未证明状态合并带来固定 RTT 增益。没有用该 APK 重新配对测试 AndLinker，不能更新两库速度排名。

#### 第三组：有起止状态快照的观察

pendingperf3awake 仍使用同一 APK，12 PASS、DONE，16 个 IPC CSV、16000 次返回值正确的调用。[分析](benchmarks/runs/2026-10-08-xiaomi14ultra/ordered-performance-awake/analysis.json)与[源码/安装包证据](benchmarks/runs/2026-10-08-xiaomi14ultra/ordered-performance-awake/evidence.json)均保存。

目录名 awake 表示唤醒尝试，不能证明全窗口前台。[开始电源快照](benchmarks/runs/2026-10-08-xiaomi14ultra/ordered-performance-awake/power-before.txt)为 Awake，但[开始 Activity](benchmarks/runs/2026-10-08-xiaomi14ultra/ordered-performance-awake/activities-before.txt)已有 PAUSING/isSleeping；[结束电源](benchmarks/runs/2026-10-08-xiaomi14ultra/ordered-performance-awake/power.txt)为 Dozing，[结束 Activity](benchmarks/runs/2026-10-08-xiaomi14ultra/ordered-performance-awake/activities.txt)中 demo 为 STOPPED。快照采集有时间滞后，不能据此确定完整测量窗口的前后台状态，也不能直接归因异常样本。本组与前两组分别保留，不合并成前台收益。

| 本地情景 | 旧版分配 B/次 | 优化版分配 B/次 | 变化 |
| --- | ---: | ---: | ---: |
| immediate | 896.696 | 849.183 | −5.30% |
| parcel | 929.300 | 880.968 | −5.20% |

本组进程近似分配同样减少约 48 B/次。测量线程 CPU 摘要为 immediate 31.205→27.356 μs/次、parcel 34.673→32.120 μs/次；与前两组一样，应保留状态与批次范围，不能宣称进程总体 CPU 的固定改善。

| 入参 | 旧版 P50 摘要 ms | 优化版 P50 摘要 ms | 摘要变化 |
| --- | ---: | ---: | ---: |
| 16 字符 | 1.408985 | 1.450339 | +2.94% |
| 1024 字符 | 1.485912 | 1.407631 | −5.27% |

16 字符摘要变慢，1024 字符摘要较低，仍没有一致的 RTT 收益。旧版 16 字符第 2 轮存在 6411.066769 ms 最大样本，原因未定位，原样保留；P50 不能排除这类长尾，也不能将其归因于位状态或 Dozing。三组未重新配对 AndLinker，既有两库排名不更新。

![第三组同 APK 的线程 CPU、近似分配及逐轮 P50](benchmarks/runs/2026-10-08-xiaomi14ultra/ordered-performance-awake/pending-performance.png)

图中 RTT 线展示逐轮 P50，未显示上述 6.411 秒最大样本；完整 P99、均值和最大值见原始分析。

### 最终优化 APK：52 项功能回归

上述阶段 1–3 原始门禁属于各自 APK；最终优化 APK 49C58... 已重新运行并通过 22 项生命周期、8 项请求/流终态、16 项兼容、6 项故障验证，合计 52 PASS，四组各有 DONE，安装包与构建哈希匹配。这证明所列功能门禁通过，不能当作受控前台 RTT 验收。

| 最终运行 | PASS | 保存的日志 |
| --- | ---: | --- |
| lifecycleawake | 22 | [生命周期](benchmarks/runs/2026-10-08-xiaomi14ultra/ordered-final-lifecycle-awake/logcat.txt) |
| terminalawake | 8 | [请求与流终态](benchmarks/runs/2026-10-08-xiaomi14ultra/ordered-final-terminals-awake/logcat.txt) |
| compatawake | 16 | [兼容](benchmarks/runs/2026-10-08-xiaomi14ultra/ordered-final-compatibility-awake/logcat.txt) |
| faultawake | 6 | [故障](benchmarks/runs/2026-10-08-xiaomi14ultra/ordered-final-fault-awake/logcat.txt) |

初次 lifecyclefinal 在第三轮关闭中断，现场记录为 [Dozing](benchmarks/runs/2026-10-08-xiaomi14ultra/ordered-final-dozing/power.txt) 与 [Activity STOPPED](benchmarks/runs/2026-10-08-xiaomi14ultra/ordered-final-dozing/activities.txt)，该次不能判为功能通过，也不能据此判定原子状态故障。最终四组成功记录保留了原有范围：同步 Binder/非协作业务不能强制中断，Parcelable 字段兼容和完整旧版本升级矩阵仍未证明。结果统一见[顺序修复报告](benchmarks/xiaomi14ultra_2026-10-08_ordered_remediation.md)。

### 后续 Async 发送前检查优化

前序 guard APK `30ED4B9762422AFEBF5DBA9DEEBB125C81921EA60C5C766A7B53EEAE01A1782D` 将注册 pending 后的第二次完整服务缓存查询改为原连接/未释放/捕获 Binder 存活检查；首次完整 Schema 解析保留，不换 Binder、不重放。该 APK 的生命周期/终态/兼容/故障回归共 52 PASS、四组 DONE；两组前台门禁合格记录各 6 项 guard PASS，共 32,000 次成功 IPC。

发送前步骤近似少分配 48 B，局部线程 CPU 约少 0.60 μs。两组 16 字符 P50 摘要分别 -31.89% 与 +4.84%，1024 字符分别 -16.91% 与 +9.98%，方向反转，未证明稳定 RTT 收益。零分配计数增量不表示整个 Async 零分配，不与前序 Registry 差额直接相加，也不更新 AndLinker 排名。[该轮完整报告、状态与失败记录](benchmarks/xiaomi14ultra_2026-10-08_presend_guard.md)。

### 当前冷发现、清理与请求 trace

此前“调用线程同步冷发现早于 pending 截止”和“RPC 位于 ConcurrentHashMap.compute 内影响清理”两项 P1 已修复：发现放到锁外 worker，生成 Async 的截止从入口开始，close/dispose 置换并作废旧容器、唤醒等待者，不等待已开始的发现 RPC。修复不承诺中断同步 Binder，也不将取消检查与下一次远端调用变成原子操作。

第一阶段冷发现 APK `6F4162248E507B6762CE3C7984EC454480849D69EB2BC70B4DE6A007037E6067` 完成 12 项冷发现及 52 项功能回归，共 64 PASS、5 DONE。之后五应用统一构建成功，冻结 demo APK `5C8CECFDC5650E8186EC326DEAC916A9584755508BF555A5F48CE917AFBE20FC` 重新完成冷发现12、生命周期22、终态8、兼容16、故障6，共 64 PASS、5 DONE，逐组安装哈希一致，另通过 3 独立客户端跨包 smoke。其[冷发现证据](benchmarks/runs/2026-10-09-xiaomi14ultra/ordered-final-cold-trace/evidence.json)与其余门禁见[本轮报告](benchmarks/xiaomi14ultra_2026-10-09_cold_trace_optimization.md)，不沿用前序 APK 数字作新 APK 证明。

请求 trace 默认关闭，显式启用后每进程最多保留 16,384 个事件，停止后写 Logcat 或文件；窗口内无逐事件 Logcat。诊断限隔离的单客户端/单 Controller 按 requestId 关联，callback identity 仅在本进程有效，服务端 generation=0。5C8CE... 的 traceon4 完成 1000 请求完整链、11000 事件且 dropped=0，traceoff1 双端为 0 事件，两组状态门禁有效。分段包含埋点与阶段间工作；新增 demo 调度配置实验后的 4494F529... APK 再次通过 64 PASS/5 DONE 和完整 traceon5，两轮 56,192 次测量均成功。小包串行有反向配对，专用线程只保留为短任务可选配置；SDK scope 仍由宿主提供，demo 默认 Default。本轮没有新增两库配对或通用稳定 RTT 收益结论，详细分析见[冷发现与请求 trace 报告](benchmarks/xiaomi14ultra_2026-10-09_cold_trace_optimization.md)。

## 5. 历史实际性能与 APK 范围

以下历史结果保留其原始日期和构建范围，均早于上述阶段 1–4 APK。历史同负载两库比较、本库快路径比较与鉴权局部优化分别回答不同问题，不能合并数值排名。

| 历史数据组 | 日期 | APK SHA-256 与范围 |
| --- | --- | --- |
| 两库 echo 主序列 | 2026-09-29 | ModernIpc：47BB67B492393E116B7239EFF712E0010C265D29B1CE0194896374D39C156E30；AndLinker：CFD5EE622B80470771C20391065F29611F17C5C1ED5A9AE038E174D5E8101B25。 |
| 本库 suspend / Direct | 2026-09-29 | 208343DE0AA7968919EE1F054B35372738BACD6FBA927A7D0653B9E6B34BBA1B，同 APK 内对比。 |
| 鉴权旧 / 新配对 | 2026-10-08 | FCD36F32540CFB9256A19013439A4911C16144873F1AA8D122778EB65CEDAA0D，同 APK 内对比，无 AndLinker 重跑。 |

原版示例短测使用另外的 APK：ModernIpc 服务端 170131EEB04AAC939614CFF37A96310FF8CD797C55CBC3911D316860111BE8B8、客户端 1 617E97B375D65EC999BC4215F0E2D158DEB08AEF51167449675A03E0992EA80B、AndLinker sample 2C3B68ABD40E20815C7668DA7CD8FCCC9DE9B2E276A3AF68685ED415E5FE939E。其余客户端哈希未记录，第一次逐次 RTT 原始日志未保存，不能补写成完整可重算证据。

### 2026-09-29 原版示例短测

| 项目 | ModernIpc | AndLinker |
| --- | --- | --- |
| 安装拓扑 | 服务端与三个客户端为四个独立包、独立 UID。 | 原版 sample 同包，主进程与 :remote 进程。 |
| 功能 | 跨包绑定、挂起 RPC、定向消息和 Flow 接收；冷启动跨包唤醒受到小米 WakePathChecker 拦截，打开服务端后恢复。 | 跨进程绑定、初始化、Callback 和 Oneway 均有日志。 |
| 原版示例短测 | 同一版本两次 1000 次 sendMessage 串行请求，P50 为 2.067/2.256 ms；含业务处理。后台场景两次回执达 37.411/77.895 s。 | 原版示例没有等价 RTT 测试；Oneway 处理含主动 sleep 3 秒，不代表 IPC 时延。 |

上述原版示例短测的业务和拓扑不同，不能彼此相除。完整环境、APK 哈希和日志见[实机短测](benchmarks/xiaomi14ultra_2026-09-29_smoke.md)。

### 2026-09-29 同负载 echo 性能对比

随后在同一小米 14 Ultra 上给两个库都加了原样返回 String 的 echo 方法，统一为同包主进程到服务进程、前台客户端、每档 50 次预热和每轮 1000 次串行请求。交替运行四轮；所有返回值校验正确，零失败。下表为四轮各自 P50 的中位数，单位 ms：

| 入参 | ModernIpc suspend | AndLinker 同步 | AndLinker Call.enqueue |
| ---: | ---: | ---: | ---: |
| 16 字符 | 0.536 | 0.258 | 0.327 |
| 1024 字符 | 0.682 | 0.232 | 0.353 |

这次前台 echo 中，AndLinker 同步和 enqueue 的端到端 P50 均低于 ModernIpc。相对于 enqueue 路径，ModernIpc 的两档 P50 分别为 1.64 倍与 1.93 倍。同步路径与 suspend 方法的 API 语义不同；enqueue 也通过线程池执行同步 Binder 调用，而 ModernIpc 使用单向请求加回调 Binder。两边 targetSdk 分别为 26 与 34，且使用 Debug 构建；这些数据不代表库在所有业务、后台或跨包场景中的固定速度差。逐轮 P99、测试代码、APK SHA-256 和原始 CSV 见[完整同负载报告](benchmarks/xiaomi14ultra_2026-09-29_echo_ab.md)。

#### 为什么这组历史数据中 AndLinker 更快

源码能确认热路径结构不同。ModernIpc 的生成代理把请求 ID 和响应 Binder 写入 Parcel，发送一次单向业务事务；生成 Stub 交给 IpcRequestTracker，后者为每次请求申请在途许可、建立 Job、登记回调 Binder 的死亡通知，并在完成后清理。服务端再发送一次独立回调事务，客户端从 PendingCallRegistry 取回 continuation，恢复协程。AndLinker 的同步方法经 ITransfer.execute 发起一次带 reply 的同步 transact，服务端调用缓存的 MethodExecutor 后在该事务的 reply 中返回。Call.enqueue 只是把这条同步调用交给线程池，再把结果投递到默认主线程回调。两边方法都需编解码；AndLinker 的动态代理和反射并非每次重新扫描接口，因为 ServiceMethod 与 MethodExecutor 已缓存。

这些额外的事务、Job/死亡通知登记及协程恢复是 ModernIpc 在极轻 echo 工作量下较慢的合理解释，但主对比没有逐段设备计时，不能指定哪一项贡献了多少。现代代理还缓存了服务 Binder，热路径未每次走 Broker；本次同包分进程的调用 UID 相同，CallerAuthenticator 走快速返回分支，所以也不能把差距归因于跨包签名校验。随后针对服务端调度、**测试调用方**的恢复调度及每请求死亡监听分别做了临时变体复测：两处调度成本可测，死亡监听在串行 echo 中未见稳定收益。结果与风险见[优化分析](ModernIPC_Optimization_Analysis.md)；还需给请求发送、服务端接收/执行、回调发送和客户端恢复分别打点。调用方调度不是 ModernIpc 内部额外强制的一次切换，不能把它算成可由库单独消除的成本。

#### 2026-09-29 本库 Direct 快路径

ModernIpc 现提供显式 `@IpcDirect`，允许非挂起短方法像 AndLinker 的同步接口一样，在一次带 reply 的 Binder 事务中返回。它沿用 Broker 服务发现和服务端鉴权，客户端拒绝主线程调用；接口不具备原 `suspend` 方法的跨进程取消与 128 在途许可。给旧 echo 契约新增 `echoDirect` 后，**同一新版 APK** 内的四轮 P50 中位数为 suspend 0.543/0.602 ms、direct 0.129/0.328 ms（16/1024 字符）。这说明针对无计算短调用，协议路径可以明显降低本库耗时；新版 APK 与前述 AndLinker 测试处于不同构建和时段，不能把两组数值混作新版两库排名。完整 P99、16/64 并发结果与原始数据见[快速路径设备报告](benchmarks/xiaomi14ultra_2026-09-29_direct_fast_path.md)。

源码核对：[ModernIpc 请求跟踪](../ipc-runtime-server/src/main/kotlin/com/cn/ipc/server/IpcRequestTracker.kt)、[客户端挂起点](../ipc-runtime-client/src/main/kotlin/com/cn/ipc/client/PendingCallRegistry.kt)、[调用方鉴权](../ipc-runtime-server/src/main/kotlin/com/cn/ipc/server/CallerAuthenticator.kt)、[AndLinker ITransfer](https://github.com/codezjx/AndLinker/blob/7ae01bfd87ddcf021319148a8727a95345cf350e/andlinker/src/main/java/com/codezjx/andlinker/ITransfer.java)、[RemoteCall](https://github.com/codezjx/AndLinker/blob/7ae01bfd87ddcf021319148a8727a95345cf350e/andlinker/src/main/java/com/codezjx/andlinker/RemoteCall.java)。

### 2026-10-08 鉴权局部优化

同 APK 旧/新鉴权配对中，局部 CPU 与分配减少；同 UID 局部 CPU 从 479.8 降至 187.5 ns，约 60.9%。四轮 IPC 延迟变化方向不一致，未证明稳定的端到端加速，并保留了 11.341 s 的最大停顿样本。本轮没有重跑 AndLinker，也早于顺序修复 APK。结果、产物及跨 UID 功能回归见[鉴权分配优化实测](benchmarks/xiaomi14ultra_2026-10-08_auth_optimization.md)。

## 6. 迁移映射与未实现边界

| 现有 AndLinker 用法 | ModernIpc 对应方式 | 迁移时需要处理 |
| --- | --- | --- |
| 直接返回 / execute | 明确的极短方法用 IpcDirect；挂起业务用 IpcAsync。 | Direct 在后台线程调用；生成 Async 默认 30 秒入口预算覆盖发现与 pending，业务可选更短超时。同步 transact 不可强制中断。 |
| enqueue / Rx 单次结果 | suspend 配合调用方协程上下文，或自行 Rx 适配。 | RxIpcExtensions 未启用；保留调度与错误处理语义。 |
| Callback 注册 | IpcStream Flow。 | 完成/错误、取消与溢出策略明确；重订阅不补历史值。 |
| OneWay | IpcOneway。 | 两库 wire 不兼容，需要重定事务号与 codec；无业务回执。Main 冷缓存须先挂起严格预热或改在后台同步解析。 |
| 动态代理服务 | 共享注解契约并生成双端 Schema。 | 检查版本区间、descriptor、事务签名；Parcelable 字段变化另做兼容验证。 |
| In/Out/Inout 或复杂集合 | 用支持类型重新设计请求与返回 DTO。 | 没有等价的参数方向协议，不支持类型不能依赖任意 Parcelable fallback。 |
| 自定义服务权限 | 同签名校验与 Manifest 权限。 | 独立签名第三方需要先实现新的授权模型。 |

当前仍未实现：Parcelable 字段级 Schema、会话与业务帧绑定、按方法 permission/requiredCapability 执行、内联大小限额和分块/FD 传输、Flow 数量上限、Direct/Oneway 总量限制、持久可靠消息、RPC 幂等重放、Rx 兼容层与自动双栈回退。独立 SubscriptionRegistry、FlowAdapterHelper、BoundedDispatcher 等辅助代码不能算作默认生成链路已经使用的能力。

迁移应逐方法验证参数方向、空值、Parcelable、异常、超时、断线、版本拒绝与进程死亡。两个库的 Binder 协议不同，AndLinker 代理不能直接指向 ModernIpc Broker。

## 7. 如何选择与继续测量

- 既有 Java/Rx 接口可继续评估 AndLinker，核对宿主权限、线程与异步资源上限；固定版本的缓存和同步链路已有源码依据。
- Kotlin suspend/Flow、共享签名应用群、需要统一连接与逐事务兼容检查时，可评估 ModernIpc，并为 SERVER_BUSY、截止、断线、溢出和不兼容拒绝建立业务处理。
- 可靠投递需要应用层持久化与确认；性能结论需要针对真实方法进行配对测量。

历史 echo 已统一设备、同包分进程、负载与采样次数，尚未统一 targetSdk、构建工具和异步调度模型。阶段 4 已完成同 APK Registry 变量配对，分配减少与 RTT 摘要分别记录；后续可测真实业务、生成代理整体和 suspend/Direct，继续绑定源码及设备安装包哈希。新的两库速度结论需要新的配对数据。测试继续限定小米设备，统一签名/包拓扑、前后台状态、输入与返回，报告成功吞吐、失败数、P50/P90/P99、CPU、温度、电量及重连结果。Oneway 应测服务端完成时间，不能用客户端提交时间替代。

### 2026-10-09 握手隔离补充

当前ModernIPC源码在4494调度实测后新增有界HandshakeExecutor，防止同步握手占满控制IO容量；关闭只取消本地等待，晚回包按连接和Job身份拒绝。该新增变更已通过源码复核与runtime-client编译，最新402684版本五应用构建安装成功，9项小米阻塞握手及完整回归等待设备解锁，不能沿用前一APK结果或更新两库性能排名。范围与状态见[本轮报告](benchmarks/xiaomi14ultra_2026-10-09_cold_trace_optimization.md)。
