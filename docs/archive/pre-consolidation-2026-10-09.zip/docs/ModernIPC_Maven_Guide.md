# ModernIpc Maven 构建与发布

此文档描述当前[发布脚本](../build-logic/src/main/kotlin/convention.publish.gradle.kts)配置，不代表远端仓库已经有可下载产物。按实际版本、权限和坐标查询结果决定外部工程如何消费。

## 发布坐标和模块

发布脚本默认 group 为 com.modernipc，版本为 2.0.1；可通过 Gradle 属性 VERSION_NAME 覆盖。artifactId 使用模块名。Android library 发布 release AAR，JVM library 发布 java JAR。可发布模块包括 ipc-api、ipc-contract、ipc-runtime-client、ipc-runtime-server、ipc-annotations、ipc-compiler。应用模块不是 SDK 依赖坐标。

ipc-api 是仓库内示例契约，依赖其他运行时模块并在自身构建时运行 KSP。第三方工程若定义自己的业务契约，必须使服务端和客户端共享该契约并为定义接口的模块配置 KSP；只依赖已构建的 ipc-api 不会自动为新接口生成代理。模块图见[架构文档](ModernIPC_Architecture.md)。

## 在本仓库构建和本地发布

Windows PowerShell：

~~~powershell
.\gradlew.bat :ipc-api:assembleRelease :ipc-runtime-client:assembleRelease :ipc-runtime-server:assembleRelease
.\gradlew.bat :ipc-api:publishReleasePublicationToProjectLocalRepository
.\gradlew.bat :ipc-contract:publishReleasePublicationToProjectLocalRepository
.\gradlew.bat :ipc-runtime-client:publishReleasePublicationToProjectLocalRepository
.\gradlew.bat :ipc-runtime-server:publishReleasePublicationToProjectLocalRepository
.\gradlew.bat :ipc-annotations:publishJavaPublicationToProjectLocalRepository
.\gradlew.bat :ipc-compiler:publishJavaPublicationToProjectLocalRepository
~~~

项目内仓库位于根目录 local-maven。先检查具体模块支持的任务；例如只需要一个坐标时，执行对应模块的 ProjectLocal 任务即可。直接运行根级 publish 会尝试所有已配置仓库，包括 GitHubPackages，并需要远端凭据。

在同一机器的另一个 Gradle 工程消费本地构建，可在 settings.gradle.kts 的 dependencyResolutionManagement.repositories 中添加：

~~~kotlin
maven { url = uri("D:/Developer/WorkSpace/ModernIpc/local-maven") }
~~~

然后按实际发布版本声明所需模块。例如示例业务接口所在包：

~~~kotlin
implementation("com.modernipc:ipc-api:2.0.1")
~~~

使用新契约的工程还需配置与编译器兼容的 KSP 插件，并将 com.modernipc:ipc-compiler:2.0.1 加入 ksp 配置。必须核对发布 POM 中的传递依赖、Kotlin/AGP/KSP 版本及宿主 minSdk；本仓库示例的项目依赖不等于外部集成已经通过测试。

## GitHub Packages 配置

发布脚本的远端地址按以下优先级确定：GITHUB_REPOSITORY 环境变量、gpr.repo 属性、gpr.modern.ipc.repo 属性、最后回退到 Cuinings/ModernIpc。仓库已发生重定向，发布时应显式指定实际 owner/repo，不依赖回退值。凭据依次读取 GITHUB_ACTOR/GITHUB_TOKEN 或 gpr.user/gpr.key。凭据应放在本机 Gradle 用户属性或 CI 密钥中，勿提交到仓库。

~~~properties
gpr.repo=实际用户名/ModernIpc
gpr.user=实际用户名
gpr.key=具有对应权限的令牌
~~~

本地向远端发布单个 Android 模块的任务形式：

~~~powershell
.\gradlew.bat :ipc-api:publishReleasePublicationToGitHubPackagesRepository
~~~

使用者在自己的 settings.gradle.kts 添加对应 Maven URL 与只读凭据后，才可解析 GAV。远端包是否存在、是否公开、当前版本及访问令牌权限，均需在 GitHub Packages 页面或实际 Gradle resolve 中核实。本次文档改写未执行远端发布。

## CI 与版本一致性

[release.yml](../.github/workflows/release.yml) 在推送 v* 标签时以 JDK 17 执行根级 publish，随后收集 AAR/JAR 并创建 GitHub Release。工作流没有从标签自动推导 VERSION_NAME；例如 v2.0.2 标签若未同步设置版本属性，仍可能发布默认 2.0.1。发布前应核对标签、VERSION_NAME、生成的 POM、Packages 条目和 Release 附件。工作流存在并不证明某次运行成功。
