# ModernIpc 延迟优化分析与验证顺序

核对日期：2026-10-09。当前源码已将冷服务发现移出调用线程与缓存锁，生成 Async 的入口截止覆盖发现和 pending 等待，并接入默认关闭的请求 trace。冻结 5C8CE... APK 已通过功能门禁、跨包 smoke 和完整请求 trace 采集；详细耗时分析与后续调度实验另按其 APK 记录，不声称 RTT 提升。状态与证据见[冷发现与请求 trace 报告](benchmarks/xiaomi14ultra_2026-10-09_cold_trace_optimization.md)。本文保留前序 presend guard、pending 状态优化及调度/鉴权的历史结果。测试限定 Xiaomi 14 Ultra（925c23bb、Android 16）；各轮 APK 与场景按原报告核对，不把历史 echo 数据推广为当前版本或跨应用消息中枢的性能。

## 1. 当前验证顺序与优先级

前序先修复生命周期、请求与流终态、协议兼容，再完成 pending 状态与 Async presend guard 优化；本轮修复冷发现与清理边界，随后通过 trace 定位真实耗时。前序完整门禁、失败排查、安装 APK 与源码哈希见[顺序修复报告](benchmarks/xiaomi14ultra_2026-10-08_ordered_remediation.md)；当前状态见[本轮报告](benchmarks/xiaomi14ultra_2026-10-09_cold_trace_optimization.md)，架构与接入 API 见[架构](ModernIPC_Architecture.md)、[SDK 指南](ModernIPC_SDK_Guide.md)。

| 阶段 | 当前源码与小米结果 | 性能证明边界 |
| --- | --- | --- |
| 1 生命周期 | 独立控制 scope、close/dispose、原 Binder 取消/退订、生成 Stub 释放；22 PASS + DONE | 验证释放、代次与真实请求/订阅回收，不证明延迟改善 |
| 2 请求与流终态 | 阶段 2 为注册 RPC 默认 30 秒、NEXT/COMPLETE/ERROR、默认溢出 ERROR、显式 CONFLATE；8 PASS + DONE | 验证终结与容量策略；当前 Async 已扩展为入口截止，见下方冷发现阶段 |
| 3 严格 Schema | KSP 共享 codec/事务签名、两端严格校验、floor、旧 Broker 不降级；16 PASS + DONE | 验证兼容边界与缓存；没有新增性能收益结论 |
| 4 pending 状态 | 三个 AtomicBoolean 合并为一个 AtomicInteger；已完成三组同 APK A/B，每组 12 项竞态 PASS | 最新唤醒尝试记录完整 Registry 每调用进程分配约少 48 字节；未证明全程前台，16/1024 字符 RTT 方向不同，无稳定收益保证 |
| 前序 presend guard | 首次严格发现保留；该轮同 APK 两组各 6 项 guard PASS，30ED4... APK 功能回归 52 PASS/4 DONE | 发送前步骤约少 48 B，局部线程 CPU 较低；两组 IPC 摘要方向反转，未证明稳定 RTT 收益 |
| 本轮冷发现与清理 | 可取消共享发现、进程内 4 worker 无队列预算、close 作废容器、Async 入口截止已实现；冻结 5C8CE... APK 完成 64 PASS/5 DONE、3 独立客户端跨包 smoke | 五应用统一构建完成；1000 请求完整 trace、11000 事件且无丢弃，关闭 trace 时 0 事件；不声称 RTT 提升 |

前序 pending 状态优化 APK（SHA-256：49C58DAA156DA8CEE1A79AAD11033D78DC65860680F3FEC27F70948AFC5DC4B4）的日志完成生命周期 22、终态 8、兼容 16、故障 6 项，共 52 PASS 并分别 DONE；该 APK 三组性能探针各 12 项，共 36 PASS。这些结果属于发送前 guard 改动之前的 APK，不作为本轮新 APK 的功能或性能验收。最终功能证据：[生命周期](benchmarks/runs/2026-10-08-xiaomi14ultra/ordered-final-lifecycle-awake/evidence.json)、[终态](benchmarks/runs/2026-10-08-xiaomi14ultra/ordered-final-terminals-awake/evidence.json)、[兼容](benchmarks/runs/2026-10-08-xiaomi14ultra/ordered-final-compatibility-awake/evidence.json)、[故障](benchmarks/runs/2026-10-08-xiaomi14ultra/ordered-final-fault-awake/evidence.json)。这些capture也含Dozing/STOPPED；日志功能通过不表示受控前台RTT验收。不能通过删除死亡监听、取消、鉴权、终态或 Schema 校验获得一个语义不同的“优化版”。

## 2. 当前 Async 热路径与冷发现

```mermaid
sequenceDiagram
    participant C as 客户端协程
    participant A as ClientAdapter / Controller
    participant W as 发现 worker / 同键共享结果
    participant P as PendingCallRegistry
    participant B as 服务端 Binder 线程
    participant T as IpcRequestTracker
    participant D as 服务端协程调度器
    C->>A: suspend调用
    A->>A: 建立默认30秒入口截止 / 获取连接快照
    alt 冷发现
        A->>W: 可取消等待 / 同键共享发现
        W->>W: 同步 Schema + checked RPC / 连接与需求检查
        W-->>A: 已验证 Binder
    else 温缓存
        A->>A: 命中严格缓存 / 捕获Binder
    end
    A->>P: WithinDeadline注册 continuation、取消状态、requestId
    A->>A: presend guard：快照、disposed、捕获 Binder 存活
    A-)B: FLAG_ONEWAY 请求事务
    B->>B: 鉴权、解码
    B->>T: 获取 permit、登记 Job、linkToDeath
    T->>D: 启动 Job
    D->>D: 执行 echo / 业务方法
    D-)P: FLAG_ONEWAY 回调 / requestId / status / payload
    P-->>C: 原子摘除 pending / 解码 / 恢复 continuation
    D->>T: 完成 Job、unlinkToDeath、释放 permit
```

[客户端代理生成器](../ipc-compiler/src/main/kotlin/com/cn/ipc/compiler/ClientAdapterGenerator.kt)以单向 `transact(10)` 发送 echo 请求；[服务端 Stub 生成器](../ipc-compiler/src/main/kotlin/com/cn/ipc/compiler/ServerStubGenerator.kt)经请求跟踪器启动协程，再以单向 `transact(1)` 回调。[PendingCallRegistry](../ipc-runtime-client/src/main/kotlin/com/cn/ipc/client/PendingCallRegistry.kt)为每次调用登记 continuation 与取消状态；[IpcRequestTracker](../ipc-runtime-server/src/main/kotlin/com/cn/ipc/server/IpcRequestTracker.kt)为每次调用登记 Job、permit 和 Binder 死亡监听。当前 echo 的同 UID 鉴权走 [CallerAuthenticator](../ipc-runtime-server/src/main/kotlin/com/cn/ipc/server/CallerAuthenticator.kt) 快速路径，异 UID 仍实时检查包与签名。

当前所有生成模式向 [Controller](../ipc-runtime-client/src/main/kotlin/com/cn/ipc/client/IpcConnectionController.kt)传 `CLIENT_SCHEMA`。每个 `(generation, serviceId, minApiVersion, schemaFingerprint)` 的首次正常发现需要同步 `getServiceSchema` 与 `getServiceChecked` 两次 Broker RPC；当前由发现 worker 执行，客户端与 Broker 分别检查版本、descriptor 和期待事务。缓存命中不重复这些 RPC，fingerprint 在 Schema 构造时计算。因此测量必须分别报告握手/冷发现与已预热业务 RTT；不能把“每次重新找 Broker”或“每次验跨包签名”作为同 UID 热 echo 的默认解释。

生成 Async 在入口建立默认 30 秒预算，覆盖可取消冷发现和注册后的 pending 等待；callSuspendWithinDeadline 不重置预算。该 primitive 本身不创建截止，手写调用者必须提供外层截止。Flow 只限制发现等待，订阅后的长期业务流没有整段默认截止。同步冷解析在 Main 上立即拒绝，Oneway 的 Main 入口需先挂起预热；Direct 仍必须在后台线程调用。取消或超时结束等待与作废晚结果，不能强制中断已经开始的同步 Binder 或回滚远端副作用。

### 2.1 前序已实施：发送前 guard

前序 guard 轮次仅实施发送前检查精简：首次严格发现捕获已经验证的连接与业务 Binder，在 PendingCallRegistry 注册后、transact 前，将此前第二次完整发现/缓存查询改为 checkServiceBinderForConnection。第二次查询的返回值原来没有被使用，请求与取消仍使用首次捕获的 Binder。当前首次解析已改用 awaitServiceBinderForConnection；guard 语义保持。源码：[ClientAdapterGenerator](../ipc-compiler/src/main/kotlin/com/cn/ipc/compiler/ClientAdapterGenerator.kt)、[Controller guard](../ipc-runtime-client/src/main/kotlin/com/cn/ipc/client/IpcConnectionController.kt)。

| 环节 | 保持或改变 | 预期证明方式 |
| --- | --- | --- |
| 首次服务发现 | 保留能力、版本区间、descriptor、逐事务 Schema 校验与按代次缓存。 | 冷发现 metadata/checked 数量及兼容拒绝门禁。 |
| 注册后的发送前检查 | 保留两次连接实例与 disposed 检查，中间检查捕获 Binder 的 isBinderAlive。 | 已关闭/已重连快照、检查期间关闭、死亡 Binder 拒绝；不更新至新代次 Binder。 |
| 温缓存的重复操作 | 去掉第二个 ServiceBinderKey 构造、第二次 serviceVersions 查询与第二次 cache get。 | 字节码/源码核对，发送前步骤分配与局部 CPU；整体 Async RTT 另测。 |
| wire、鉴权与资源 | 请求/回复、回调 Binder、取消、截止、Job、permit 和死亡监听保持；未改 Direct/Stream/Oneway。 | 同 APK 单因素配对及完整功能门禁，不能把其他候选收益并入此轮。 |

guard 成功之后仍可能与断连或 Binder 死亡竞争，后续 transact 必须继续检查返回值和处理异常；检查不是发送与关闭的原子承诺。取消 hook 保留原 Binder，不向重连后 Binder 发送旧请求取消。温缓存原本就不重复 metadata RPC，本轮减少的是本地重复操作。

该轮实测报告：[2026-10-08 小米 presend guard](benchmarks/xiaomi14ultra_2026-10-08_presend_guard.md)。以下第 2.3 节记录 30ED4... APK 的有效测量及功能回归；前序 49C58... APK 的 52/36 PASS 仍保留其原始范围，均不替代本轮冷发现/trace APK 验收。

### 2.2 运行时对象判断：以生成结果和字节码为准

已检查的 Debug 编译产物中，String echo 的 deserializer 在 offset 84 使用 getstatic 读取 IBenchmarkEchoServiceClientAdapter$echo$2.INSTANCE，是单例；offset 90/103 的 new 对应捕获 Binder/adapter/连接等值的 cancel/send 闭包。因此不能把这个 String decoder 当作每请求新建对象，也不能将“提升 decoder 为字段”计入本轮收益。观察限定为已检查的 String echo 编译结果；Parcelable 的 classLoader reader 等捕获型 codec 需独立检查，不能推广所有返回类型。

~~~text
getstatic IBenchmarkEchoServiceClientAdapter$echo$2.INSTANCE
new IBenchmarkEchoServiceClientAdapter$echo$3
new IBenchmarkEchoServiceClientAdapter$echo$4
~~~

复核命令为 javap -c -p -classpath ipc-api/build/intermediates/compile_library_classes_jar/debug/classes.jar com.cn.ipc.api.test.IBenchmarkEchoServiceClientAdapter。该检查支持对象结构判断；编译产物与设备验收仍须按本轮 APK/源码哈希记录。

ClientAdapterGenerator 的 listOf、ServerStubGenerator 的 setOf/joinToString 等用于 KSP 执行和代码生成。编译器源码中的这些集合不能计作每次 RPC 的运行时对象；应检查实际生成代码及字节码。生成 Schema 初始化的集合和真实方法体中的集合也要按其实际生命周期分别计量，不能从 KSP 模板推算 per-call allocation。

### 2.3 前序 guard 小米结果：局部步骤改善，RTT 摘要方向反转

该轮最终 Debug APK SHA-256：30ED4B9762422AFEBF5DBA9DEEBB125C81921EA60C5C766A7B53EEAE01A1782D。guardperf3 与 guardperf5 均使用该同一 APK，比对重复 lookup 与轻量 guard，两组各 6 项 guard PASS、DONE，各 16 个 IPC CSV、每个 1000 次调用，合计 32000 次有效 IPC。安装包哈希与本地产物匹配。该轮生产改动只有 presend guard，其他第 7 节候选未实施。

两组 BEGIN→END 的生命周期/焦点事件及约 500 ms 应用内采样均记录 RESUMED、focused、interactive、keyguard/device unlocked；有效观察分别为 39/41 次，最大间隔 504/505 ms。power-begin 与结束快照为 Awake，demo 为 topResumed。该范围比前序只保存滞后快照更完整；状态结论按事件与采样覆盖范围解释。

| 本地发送前步骤 | guardperf3：lookup→guard | guardperf5：lookup→guard | 适用范围 |
| --- | --- | --- | --- |
| 线程 CPU，ns/步骤 | 1309.55→710.81（−45.72%） | 1509.78→902.83（−40.20%） | 只测重复查找或 guard，非完整 Registry/RPC 或进程 CPU。 |
| 进程近似分配，B/步骤 | 48.087040→0 | 48.087040→0.016384 | 发送前步骤约少 48 B；0 表示计数器未报告增量，完整调用仍分配 continuation、请求记录、闭包等。 |

本地 TIME、ALLOC 分开采集，每个批次 500000 次步骤。局部 CPU 摘要约少 0.60 μs/步骤，不应换算为 RPC 的固定延迟增益；进程分配计数也不能当作缓存键对象的精确尺寸。

| 四轮 P50 中位数 | guardperf3：lookup→guard，ms | guardperf5：lookup→guard，ms |
| --- | --- | --- |
| 16 字符 | 0.9517445→0.6482295（−31.89%） | 0.812526→0.851849（+4.84%） |
| 1024 字符 | 0.8865365→0.7366665（−16.91%） | 0.741198→0.8151565（+9.98%） |

首组两档摘要较低，第二组两档均变慢；有效前台条件下仍没有一致的 RTT 收益。约 0.60 μs 的局部步骤差与首组约 0.30 ms 的 RPC 摘要差来自不同测量，不能将后者归因于 guard，也不能仅取首组宣称稳定加速。P99、最大值、各配对与状态轨迹全部保留：[guardperf3 分析](benchmarks/runs/2026-10-08-xiaomi14ultra/ordered-guardperf-3/analysis.json)、[guardperf5 分析](benchmarks/runs/2026-10-08-xiaomi14ultra/ordered-guardperf-5/analysis.json)；源码与 APK：[第 3 组证据](benchmarks/runs/2026-10-08-xiaomi14ultra/ordered-guardperf-3/evidence.json)、[第 5 组证据](benchmarks/runs/2026-10-08-xiaomi14ultra/ordered-guardperf-5/evidence.json)。本轮没有新的 AndLinker 配对，不更新两库排名。

该轮最终 APK 又通过生命周期 22、终态 8、兼容 16、故障 6 项，合计 52 PASS、4 DONE，各组前台 END valid=true，源码已冻结，安装包同哈希。证据：[生命周期](benchmarks/runs/2026-10-08-xiaomi14ultra/ordered-guard-lifecycle/evidence.json)、[终态](benchmarks/runs/2026-10-08-xiaomi14ultra/ordered-guard-terminals/evidence.json)、[兼容](benchmarks/runs/2026-10-08-xiaomi14ultra/ordered-guard-compatibility/evidence.json)、[故障](benchmarks/runs/2026-10-08-xiaomi14ultra/ordered-guard-fault/evidence.json)。这是 30ED4... APK 的功能验收，与前序 49C58... APK 的同数门禁分别记录；功能通过不等于稳定 RTT 改善。

### 2.4 无效或失败记录保留

| 运行 | 原因与记录范围 | 处理 |
| --- | --- | --- |
| guardperf1 | 锁屏条件未通过前台门禁。 | 保存失败记录，不纳入有效前台 A/B。 |
| guardperf2 | 基准把 Direct 专用 __error__ 夹具套用到 Async，断言不适用。 | 修正 benchmark；该次失败不作为生产 guard 故障或性能收益。 |
| guardperf4 | 测量期间出现 pause/focus loss；虽有 6 PASS、DONE 及完整 CSV，前台资格不通过。 | 全部样本保留，不纳入 qualified 对比，不通过追加好样本替换该记录。 |

失败、资格判断、原始样本及图表统一见[本轮报告](benchmarks/xiaomi14ultra_2026-10-08_presend_guard.md)。本轮有效数据包括第 3、5 组，不能与不合格第 4 组或前序电源状态未明的 pendingperf 数据混算收益。

### 2.5 冷发现问题：修复与当前验证状态

[2026-10-08 问题分析](benchmarks/xiaomi14ultra_2026-10-08_problem_analysis.md)曾确认两个 P1 源码风险；以下为已落地的修复，不再列为当前未修问题：

| 原风险 | 当前实现与保留边界 |
| --- | --- |
| 冷发现同步 Binder 早于 Async pending 截止计时 | 生成 Async 入口先建立预算，再可取消等待 worker 的严格发现结果，最后在同一预算内登记 pending。Main 不再直接执行冷发现 RPC；超时不强制中断 worker 内已开始的 Binder。 |
| 冷发现 RPC 位于 ConcurrentHashMap.compute 内 | ServiceDiscoveryCache 在 map/生命周期锁外执行 RPC；close/dispose 先改变状态，再置换并作废旧容器、唤醒 waiter，不等待发现 RPC 返回。旧 worker 无法向新容器发布结果；取消检查与下一次 RPC 之间仍存在竞态。 |

同一 Controller、同一键的等待者共享发现，一个退出不影响其他等待者；最后一个退出后放弃 flight。所有 Controller 在同一进程/classloader 内共用最多 4 个 worker，SynchronousQueue 不保留排队任务，预算占满时新冷发现以 RejectedExecutionException 失败，温缓存可继续读取。同步冷解析在 Main 上 fail-fast；发现本身仍使用同步 Binder，4 个卡住的 RPC 可占满预算。源码：[ServiceDiscoveryCache](../ipc-runtime-client/src/main/kotlin/com/cn/ipc/client/ServiceDiscoveryCache.kt)、[Controller](../ipc-runtime-client/src/main/kotlin/com/cn/ipc/client/IpcConnectionController.kt)。

冷发现第一阶段 APK `6F4162248E507B6762CE3C7984EC454480849D69EB2BC70B4DE6A007037E6067` 已完成 12 项冷发现加 52 项功能回归，共 64 PASS、5 DONE。之后五应用统一构建成功，冻结 demo APK 为 `5C8CECFDC5650E8186EC326DEAC916A9584755508BF555A5F48CE917AFBE20FC`；其[冷发现最终门禁](benchmarks/runs/2026-10-09-xiaomi14ultra/ordered-final-cold-trace/evidence.json)完成 12 PASS/DONE，涵盖 Main 响应、150 ms 截止、取消、同键共享、关闭/释放、代次、失败重试、严格拒绝和 worker 饱和。该 APK 又完成[生命周期22](benchmarks/runs/2026-10-09-xiaomi14ultra/ordered-final-lifecycle-trace/evidence.json)、[终态8](benchmarks/runs/2026-10-09-xiaomi14ultra/ordered-final-terminals-trace/evidence.json)、[兼容16](benchmarks/runs/2026-10-09-xiaomi14ultra/ordered-final-compatibility-trace/evidence.json)、[故障6](benchmarks/runs/2026-10-09-xiaomi14ultra/ordered-final-fault-trace/evidence.json)，共 64 PASS、5 DONE，设备安装哈希逐组一致；3 独立客户端跨包 smoke 通过。两轮同数门禁按各自 APK 区分，不互相替代。

[IpcRequestTrace](../ipc-contract/src/main/kotlin/com/cn/ipc/IpcRequestTrace.kt)已接入 Async 双端阶段，默认关闭，每进程有界缓冲 16,384 个事件；停止后可输出 Logcat 或文件，窗口内不逐事件打印。隔离的单客户端/单 Controller 按 requestId 关联，服务端 generation=0，callback identity 仅在本进程有效。阶段区间包含埋点及阶段间工作，不等于纯编码或纯排队时间。5C8CE... APK 的 traceon4 完成 1000 个请求完整链，客户端 6000、服务端 5000 个事件，双方 dropped=0；[启用状态](benchmarks/runs/2026-10-09-xiaomi14ultra/ordered-trace-on4/qualification.json)与[关闭状态](benchmarks/runs/2026-10-09-xiaomi14ultra/ordered-trace-off1/qualification.json)门禁有效，traceoff1 双方均为 0 事件。详细耗时以[本轮报告](benchmarks/xiaomi14ultra_2026-10-09_cold_trace_optimization.md)为准；这不是冷发现修复的配对性能收益证明。

demo 现有 coroutineScope 的 dispatcher 配置 A/B 已完成，调度实验 APK 为 `4494F5299DF407EA3DB2DFE915B14057A39A6DCE5F4171217237FF8F88E1F0A4`，再次通过 64 PASS/5 DONE 与完整 traceon5。两轮各 28,096 次测量全部成功：1024 字符串行的轮内配对 P50 变化中位数为 -30.52%/-17.30%；16 字符第二轮有 2/4 配对反向，不能承诺通用小包加速。专用线程保留为短任务可选配置；SDK scope 仍由宿主提供，demo 默认 Default。最终身份、原始样本、全部配对与限制见[本轮报告](benchmarks/xiaomi14ultra_2026-10-09_cold_trace_optimization.md)，不能沿用或混合 5C8CE... RTT，也不据此解释前序波动。

## 3. 前序阶段 4：合并 pending 原子状态，同 APK 实测

原实现为 `dispatched`、`aborted`、`cancelSent` 分别分配一个 AtomicBoolean；当前实现用一个 AtomicInteger 的三个位记录单调状态。这只精简每次请求的取消状态，不改变请求/回复 wire、服务端调度、死亡监听、鉴权或调用方恢复上下文。

| 状态位 | 当前含义与必须保持的行为 |
| --- | --- |
| dispatched=1 | 请求发送 block 正常返回后登记；取消若早于发送完成，发送后补查 aborted |
| aborted=2 | 本地取消或连接关闭；注册项摘除并触发原 Binder 取消 hook |
| cancelSent=4 | 仅 dispatched 与 aborted 同时存在时 CAS 取得发送权；重复关闭/取消不再发送 |

正常成功没有 aborted，不应补发 cancel；进入发送 block 前已观察到取消时跳过发送；发送期间取消在确认已派发后尝试一次远端取消。连接关闭与超时仍走相同生命周期。取消与开始发送之间仍有竞态，同步 transact 已发生后不能回滚远端副作用；取消发送也不是远端完成 ACK。

静态上每请求少两个原子状态对象，其余 continuation、PendingCall、闭包、超时任务、Parcel、服务端 Job 仍存在。对象大小、ART 优化、GC 与调度会影响实际成本，本轮按下表分别测量。

| 测量层 | A/B 条件 | 可支持的结论 |
| --- | --- | --- |
| 完整 Registry 本地路径 | 同 APK 内基线/优化都运行真实注册、回调完成、摘除与截止路径；不是只循环 CAS | allocation/调用、线程 CPU/调用、GC；不代表跨进程 RTT |
| 等价 wire Async IPC | 同 APK、同 Stub、相同参数/返回、相同鉴权/Job/死亡监听/取消及回调语义，仅替换客户端 pending 状态实现 | 完整成功 RTT 的 P50/P90/P99/最大值、失败、请求/取消数；不推广到 Direct 或真实 Hub |
| 生命周期与竞态门禁 | 两实现覆盖成功不发 cancel、发送前/期间/后取消、超时、断连、重复/迟到回调与代次切换 | 无重复恢复、无漏取消、pending/远端请求计数可回收；不能以更少 cancel 掩盖漏清理 |

### 3.1 最新唤醒尝试记录：pendingperf3awake

三组均将 A（三个 AtomicBoolean 基线）与 B（单 AtomicInteger）放在同一 APK 内，使用 ABBA 配对。每组 12 项竞态 PASS、16 个 IPC block（每个 1000 调用）、本地 8 个 TIME + 8 个 ALLOC block（每个 50,000 调用）。已安装 APK 与本地产物 SHA-256 同为 `49C58DAA156DA8CEE1A79AAD11033D78DC65860680F3FEC27F70948AFC5DC4B4`。

第三组尝试唤醒并临时设置保持充电唤醒，保存开始与结束的 power/Activity 状态。power-before为Awake，但activity-before含isSleeping/PAUSING；结束采集晚于DONE，记录Dozing/demo STOPPED。awake路径只表示唤醒尝试，不能证明整个窗口受控前台运行；以该组作为最新观察，不作为前台RTT验收。源码哈希、采样状态与原始数据按顺序报告保存，临时设置已恢复原值0。

| 测量 | 基线→优化 | 证明范围 |
| --- | --- | --- |
| immediate 进程分配，bytes/调用 | 896.70→849.18（-5.30%） | 完整 Registry 本地路径约少 47.51 bytes/调用 |
| parcel 进程分配，bytes/调用 | 929.30→880.97（-5.20%） | 包含 Parcel 解码约少 48.33 bytes/调用 |
| 16字符 IPC 四轮 P50 的中位数，ms | 1.4089845→1.450339（+2.94%） | 本组短字符串摘要变慢；4个配对中2个P50变慢 |
| 1024字符 IPC 四轮 P50 的中位数，ms | 1.4859115→1.4076305（-5.27%） | 本组较大字符串摘要较低，不能推广为固定加速 |

局部线程 CPU 汇总 immediate/parcel 分别较低12.33%/7.36%，属于这组 TIME block 的观察，不是整进程 CPU 或稳定业务收益。完整 IPC 仍明显波动：基线16字符第2轮最大值为6411.067ms，原因未知，原始样本与长尾保留；不能因异常大而删去，也不能归因于pending位状态。1024字符第2轮优化P99为10.414ms，高于基线6.632ms，P50较低不等于所有尾部改善。

最新逐 block 数据见[awake analysis.json](benchmarks/runs/2026-10-08-xiaomi14ultra/ordered-performance-awake/analysis.json)，APK/源码证明见[awake evidence.json](benchmarks/runs/2026-10-08-xiaomi14ultra/ordered-performance-awake/evidence.json)。分配仍来自测试进程分配计数，包含其他对象，不是纯状态对象大小或常驻内存；局部 CPU/分配不等于 RTT。IPC 保留相同请求/回复 wire、Stub、鉴权、调度与死亡监听，本轮未重测 AndLinker，也未替换成 Direct。

### 3.2 前两组保留数据：电源/Activity 状态未保存

pendingperf1/pendingperf2 已完成，但没有保存开始/结束 power 与 Activity 状态，不能严谨声称全窗口前台运行，也不与第三组合并计算前台固定收益。

| 测量 | pendingperf1：基线→优化 | pendingperf2：基线→优化 | 该两组范围 |
| --- | --- | --- | --- |
| immediate 进程分配，bytes/调用 | 897.2→849.7（-5.30%） | 897.5→849.5（-5.35%） | 两组约减少 48 bytes/调用 |
| parcel 进程分配，bytes/调用 | 929.6→881.3（-5.20%） | 929.5→881.3（-5.18%） | 包含 Parcel 解码的本地路径也约减少 48 bytes/调用 |
| immediate 线程 CPU 汇总 | -11.8% | -11.5% | 首个 A 冷、末个 A 热存在明显漂移，不能解释为稳态固定降幅 |
| 等价 wire Async IPC | 摘要中位数较低，配对存在反向 | 摘要降幅与首组差异明显，也有反向配对 | 合计 16 个 size/round 配对中 4 个 P50 变慢，无稳定 RTT 收益保证 |

immediate 的基线 TIME 首/末 block，首组约 40.6→29.3 μs/调用，次组约 40.8→30.2 μs/调用；同实现随时间已明显变化。分配结果来自完整 Registry 路径的进程分配计数，包含测试进程的其他分配，不是纯对象大小或全应用常驻内存。线程 CPU 不是整进程 CPU，局部分配减少也不等于 IPC 往返时间一定下降。IPC 保留相同请求/回复 wire、Stub、鉴权、调度与死亡监听；本轮没有重新测试 AndLinker，也没有更改为 Direct。

逐 block 的 P50/P90/P99/最大值、CPU 与分配见[首组 analysis.json](benchmarks/runs/2026-10-08-xiaomi14ultra/ordered-performance/analysis.json)、[复测 analysis.json](benchmarks/runs/2026-10-08-xiaomi14ultra/ordered-performance-repeat/analysis.json)。三组原始数据、图表、竞态门禁及最终同 APK 52项功能回归统一见[顺序报告](benchmarks/xiaomi14ultra_2026-10-08_ordered_remediation.md)。此前最终回归曾在第三轮关闭时中断，现场含Dozing/Activity STOPPED，保存在ordered-final-dozing；它不是完整PASS记录，也不能仅据此认定源码回归或确定中断原因。再次尝试后的最终功能日志已完整通过，状态capture仍不证明全窗口前台。

## 4. 历史协议比较：2026-09-29

与 AndLinker 的同步 echo 相比，协议本身多一次返回回调事务及挂起/恢复过程。AndLinker `enqueue` 还经线程池和主线程回调，其语义更接近异步调用，但仍不是同一调度实现。此前四轮同负载结果：ModernIpc P50 16/1024 字符分别为 0.536/0.682 ms；AndLinker `enqueue` 为 0.327/0.353 ms；详见[完整测试](benchmarks/xiaomi14ultra_2026-09-29_echo_ab.md)。这约 0.209/0.329 ms 的差额包含多项成本，不能直接全部归因于 Binder 跳数或调度器。尤其是客户端 continuation 会回到**调用方所选**的协程上下文；当前库在回调收到后直接 `resumeWith`，没有再强制切换一次线程。

## 5. 历史单因素诊断：服务端调度（2026-09-29）

仅把[示例 echo Stub](../demo-app/src/main/kotlin/com/cn/ipc/demo/MyBrokerService.kt)的 `CoroutineScope(Dispatchers.Default + SupervisorJob())` 临时改为 `Dispatchers.Unconfined`。echo 只返回入参且不会实际挂起，因此该变体让 Job 从当前 Binder 线程开始执行。设备仍是 USB 连接的小米 14 Ultra；复测结束电量 21%、电池温度 30.4 °C、Thermal Status 0。每档仍是 50 次预热、1000 次串行采样，原始纳秒 CSV 在 [dispatch-ab](benchmarks/runs/2026-09-29-xiaomi14ultra/dispatch-ab)。测试结束已恢复 Default 并重新安装原实现。

第一次原版→变体→原版的 d1–d6 出现大幅时间漂移：前四轮 P50 在约 1.0–1.3 ms，末两轮约 0.5–0.6 ms，不能据其计算优化收益。重新稳定后进行了 d7–d12 原版→变体→原版：

| 路径 | 轮次 | 16 字符 P50 ms | 1024 字符 P50 ms |
| --- | --- | ---: | ---: |
| Default | d7 / d8 | 0.513 / 0.515 | 0.547 / 0.623 |
| Unconfined 临时变体 | d9 / d10 | 0.426 / 0.377 | 0.460 / 0.436 |
| Default 恢复 | d11 / d12 | 0.545 / 0.543 | 0.542 / 0.634 |

四轮 Default P50 的中位数为 0.529/0.585 ms；两轮变体为 0.402/0.448 ms，分别低约 0.127/0.137 ms（约 24%/23%）。这是对**无挂起、极短 echo** 的诊断证据；每段都重新构建和安装，APK 哈希不同，而且第一次序列有显著漂移，不能作为生产改动的固定收益或高并发安全性证明。两轮变体的 16 字符 P99 为 1.505/0.979 ms，原版四轮为 1.161/1.100/1.891/1.234 ms；尾部没有稳定优势。第二序列 APK SHA-256：d7–d8 原版 `96FFBED0AA12992CDCC5E9D1748B2924733F8688743E51B8B837D705B8DEA2A2`，d9–d10 变体 `8C749A10DFB79D71B0F6F00B49EDF3D176D2492C5F72FDC4B8AB68AC863181EB`，d11–d12 恢复版 `06A601C1C5BEF21663A523F2511DD7DA262D77DF20B53CEEBE64D9A9A25B9DFB`，且已与设备已安装 base.apk 的 SHA-256 核对一致。源代码改动仅为这一处调度器切换，但构建产物哈希不相同。

## 6. 历史拆分：死亡监听与客户端调度（2026-09-29）

仍使用同一小米设备、同一 echo、每档 50 次预热加 1000 次串行采样。每种临时变体都恢复原源码并重装原实现。下表中 A 为原实现，B 为只改变该行的诊断变体；数值是各轮 P50，单位 ms。所有 CSV 都是 1000 条正数，结果校验通过。

| 只改动的环节 | 16 字符 A→B→A | 1024 字符 A→B→A | 原始数据 |
| --- | --- | --- | --- |
| `IpcRequestTracker` 暂时不执行 `linkToDeath` / `unlinkToDeath` | 0.547/0.508 → 0.533/0.466 → 0.548/0.528 | 0.640/0.758 → 0.689/0.609 → 0.562/0.661 | [death-ab](benchmarks/runs/2026-09-29-xiaomi14ultra/death-ab) |
| 仅[测试调用方](../demo-app/src/main/kotlin/com/cn/ipc/demo/IpcEchoBenchmark.kt)的 `withContext(Default)` 改为 `Unconfined` | 0.507/0.509 → 0.430/0.395 → 0.566/0.539 | 0.551/0.635 → 0.476/0.414 → 0.623/0.564 | [client-dispatch-ab](benchmarks/runs/2026-09-29-xiaomi14ultra/client-dispatch-ab) |

死亡监听 A 的四轮 P50 中位数为 0.538/0.651 ms，B 的两轮为 0.500/0.649 ms。16 字符约差 0.038 ms，1024 字符几乎持平，且波动与差值相当。**不能据此认定共享监听值得优先开发，更不能在正式代码里删除死亡监听。**

客户端调度 A 的四轮 P50 中位数为 0.524/0.594 ms，B 的两轮为 0.413/0.445 ms。这个结果确认调用方调度选择影响串行 echo 延迟，但这次改的是**示例基准的 `withContext`**，不是 ModernIpc 内部代码。`Unconfined` 恢复后可能在回调 Binder 线程继续执行下一次调用；[Kotlin 官方文档](https://kotlinlang.org/api/kotlinx.coroutines/kotlinx-coroutines-core/kotlinx.coroutines/-dispatchers/-unconfined.html)明确说明它不固定恢复线程。不能将上述数值描述为库本身可直接实现的优化收益。

最后同时把客户端测试协程和服务端 echo 作用域设为 `Unconfined`，得到两轮 P50 0.282/0.313 ms（16 字符）与 0.315/0.283 ms（1024 字符）；恢复两处 Default 后两轮为 0.511/0.488 ms 与 0.449/0.518 ms。原始数据在 [both-dispatch-ab](benchmarks/runs/2026-09-29-xiaomi14ultra/both-dispatch-ab)。这是一组 B→A、每侧仅两轮的诊断，不是完整 ABBA；它表明两个调度环节在极短 echo 中合起来足以解释**相当一部分**端到端差距，但不能量化协议事务本身的净成本，也不能跨序列直接宣称已达到 AndLinker 性能。测试结束源码、APK 均已恢复；已安装 base.apk 与本地恢复版 SHA-256 同为 `D12A8F26C4D0153138A96FE1A9D89FD43E93087F7133B59788301D146EC5913C`。本轮结束电量 22%、电池温度 30.9 °C、Thermal Status 0。

从仓库根目录用[复算脚本](benchmarks/harness/analyze_ablation.py)重算三组逐轮均值与 P50/P90/P99：

```powershell
python docs/benchmarks/harness/analyze_ablation.py docs/benchmarks/runs/2026-09-29-xiaomi14ultra/death-ab docs/benchmarks/runs/2026-09-29-xiaomi14ultra/client-dispatch-ab docs/benchmarks/runs/2026-09-29-xiaomi14ultra/both-dispatch-ab
```

## 7. 前序 guard 范围与较低优先的候选

前序 30ED4... APK 的生产改动只有第 2.1 节的 Async presend guard；本轮另外实施第 2.5 节的冷发现与清理修复并接入 trace。以下四项仍是后续候选，没有混入上述实现或历史测量。

| 较低优先候选 | 源码依据与适用范围 | 可能减少的操作 | 并发风险与必要门禁 |
| --- | --- | --- | --- |
| IpcRequestTracker 的 started 合入 Key body | 每次 submit 构造 Key 和独立 AtomicBoolean；started 只从 false 写为 true，完成回调读取。 | 用 Key body 的 volatile Boolean 保存启动状态，成功准入请求少一个对象；实际 bytes/请求须测。字段不能加入 data class 构造参数或 equals/hash。 | 保持不可变 uid/callback/requestId 身份、never-start 错误兜底和完成后释放 permit。覆盖取消前/期间、scope 已取消、dispose、重复 ID 与回调死亡，验证唯一回复及最终计数归零。 |
| DeathRecipient 直接捕获 admitted Job | 当前死亡监听通过 jobs[key]?.cancel 查找已经知道的 Job。 | 少捕获一份 tracker/key 引用路径，省死亡时的 map 查找；成功 RTT 收益没有证据。 | 保留每请求 link/unlink 与 UID/requestId 取消定位。死亡监听应取消该次 Job；覆盖旧请求完成后 ID 重用、客户端死亡、链接失败、dispose 与完成竞争，permit 只释放一次。 |
| CallerAuthenticator 保存 ownUid | authorizeCurrentCaller 重复读取宿主 Process.myUid；生成 Stub 已复用 authenticator。 | 按实例保存宿主 UID，减少重复读取；如保存 PackageManager 引用，仍通过它实时查询。 | 每事务继续读取 Binder 调用方 UID，不缓存授权结果；不同 UID 的 getPackagesForUid/checkSignatures 仍执行。覆盖同 UID、同签名异 UID、不同签名拒绝；不能把历史同 UID 鉴权微测收益再次计入。 |
| 冷发现直接发送冻结 expectedSchema | Controller 对已冻结的 ClientServiceSchema 又复制 Map、计算 fingerprint；其 writeToParcel 已使用 stableMethodSignatures。 | 冷缓存未命中时少一次 Schema/Map/摘要构造；温缓存无收益。 | 保持 cache key 与发送快照一致，保留双端校验。覆盖构造后修改原 Map、copy 新 Schema、不同最低版本/Schema 缓存隔离、额外服务端事务、旧 Broker 不降级与代次变化。 |

这些候选的来源分别为[请求跟踪](../ipc-runtime-server/src/main/kotlin/com/cn/ipc/server/IpcRequestTracker.kt)、[鉴权](../ipc-runtime-server/src/main/kotlin/com/cn/ipc/server/CallerAuthenticator.kt)、[发现与缓存](../ipc-runtime-client/src/main/kotlin/com/cn/ipc/client/IpcConnectionController.kt)和[冻结 Schema](../ipc-contract/src/main/kotlin/com/cn/ipc/ServiceSchema.kt)。started 的 volatile 字段方案具有跨线程可见性要求，不能改成普通局部 Boolean。捕获 Job 也不等于共享或删除死亡监听。

PendingCallRegistry 已合并为单原子状态。其 withTimeout、PendingCall、Long 键装箱与取消闭包涉及截止起点、原子摘除及关闭竞争；进一步改动应先定位实际分配占比，再单因素实现。分段计时可测发送前、收到、Job 开始、回调发出和客户端恢复，插桩成本须复核；历史调度变体不能代替本轮定位。

@IpcDirect 是独立接口，适合后台调用的短、无阻塞 I/O、可并发方法。[2026-09-29 同 APK echo 报告](benchmarks/xiaomi14ultra_2026-09-29_direct_fast_path.md)描述当时 Direct/Async 的协议比较，不是本轮 guard 收益。真实业务需验证 Binder 线程占用、重入和负载长尾；Hub 仍使用 Async 的取消/截止。服务端与调用方 Unconfined 变体也属于历史诊断，没有纳入本轮生产路径。

## 8. 回归与后续验证门槛

2026-10-08 前序协议回归补齐客户端 suspend、oneway 和 Flow 编码/发送的 finally 回收，并检查发送事务返回值；本地或自定义 Binder 拒绝请求时，经 PendingCallRegistry 异常路径退出。Direct/Flow 订阅回复使用标准异常头，客户端先 readException。历史 protocol v3 测试契约当时为 apiVersion=3、bench_echo_v3；当前测试接口另含生命周期/终态探针并已演进，不应混用其 APK 或接口摘录。此类故障修复不证明正常调用延迟下降。

前序 49C58... APK 的顺序门禁覆盖独立控制 scope、永久 Disposed、实际远端 Job/订阅回收、Flow code 2/3、溢出/显式 CONFLATE、严格 Schema 与旧 Broker 明确失败。这些已实现，不再列为待开发。仍有以下真实边界：

- 自动 dispose 等待 owner Job 最终完成；非协作子任务或同步 Binder 可能延迟最终完成，显式 dispose 也不保证远端即时中断。
- 生成 Async 的入口截止已覆盖冷发现与 pending；Flow 仅限制发现等待。Direct 没有同样的业务请求截止/远端取消，已开始的同步 Binder 无法被强制中断。
- Stream 无订阅数量上限、credit、消费 ACK 或重放；Hub 源 SharedFlow 的 DROP_OLDEST 仍可能丢值，CONFLATE 仅适用于状态快照。
- RpcError 还未替代实际 String 错误；请求 trace 仅为默认关闭的单客户端诊断，未新增 wire 会话身份或统一错误/重试语义。idempotent 不启用自动重放。
- Parcelable 字段布局为 opaque；严格签名验证类名/codec，不验证 CREATOR/字段兼容。旧 Broker 夹具证明方法不可用时不降级，不是所有历史 APK 的升级矩阵。

1. 前序 49C58... APK 的阶段 4 与 30ED4... APK 的 guard 分别完成独立测量及功能门禁；guard 局部步骤改善，RTT 摘要方向反转，按独立报告记录。当前冷发现/trace 版本先完成其独立功能门禁与请求关联诊断。后续仅在真实负载或剩余风险需要时扩展 `sendMessage`，仍按原版→候选→候选→原版交替并记录 P50/P90/P99、失败和最大值，CPU/分配单列；不靠重复微基准筛选理想单轮。
2. 并发 1/16/64/128 与超过上限的场景，分别记录成功吞吐、`SERVER_BUSY`、P99、Binder 线程数、进程 CPU、GC/alloc；128 permit 是保护上限，不能通过盲目放大上限掩盖排队。
3. 对任何直执行或共享死亡监听候选，覆盖取消前/中/后、客户端和服务端进程死亡、重连、重复 requestId、异常返回、跨包 UID/签名鉴权、Flow 和 Oneway，验证无悬挂 Job、无双重恢复和 permit 泄漏。
4. 单独比较后台跨包唤醒与前台 echo。小米 WakePathChecker 拒绝是绑定/启动问题，不能靠微基准热路径优化解决；历史跨包时延也不能与本次 echo 混算。

历史证据说明服务端调度和测试调用方恢复调度对极短 echo 有可测成本；死亡监听复用的串行试验没有稳定收益。前序 pending 唤醒尝试记录支持完整 Registry 局部分配约少 48 bytes/调用，16字符与1024字符RTT摘要方向不同且前台状态未证实；保留未知原因的6.411秒长尾，不宣称稳定延迟收益，也不把历史调度变体或Direct协议差值写成其收益。当前冷发现修复与 trace 接入不改变这些历史测量的 APK 和结论范围。

前序验证见[2026-10-08 小米协议 v3 回归](benchmarks/xiaomi14ultra_2026-10-08_protocol_v3.md)：仅小米设备，12096 次计时调用无失败；鉴权 token、缺失参数与业务异常均完成回归。异常回收与拒绝事务分支的证据范围及该轮 APK 哈希见报告，不替代阶段 1–4 的记录。

前序排查修复了成功后额外 cancel、完成/断连重复恢复、跨代次发送、Flow 订阅异常误读及订阅 Parcel 长期持有，见[小米故障路径报告](benchmarks/xiaomi14ultra_2026-10-08_fault_paths.md)。该历史报告当时列出的 Flow 终止、scope 关闭和 null binding 已由顺序阶段 1/2 的小米门禁覆盖；类型形状由阶段 3 的共享模型与 KSP 校验拒绝，不能用兼容探针代替所有类型的编译/运行矩阵。剩余非法帧、非协作执行与 opaque DTO 等边界以最新顺序报告为准。

## 9. 历史已落地鉴权分配优化（2026-10-08）

2026-10-08 生成 Stub 复用无状态 CallerAuthenticator，并通过 authorizeCurrentCaller 实时鉴权。同 UID 避免身份/包名集合构造及无用 PID 查询；异 UID 仍每次检查包与签名。[同 APK 小米验证](benchmarks/xiaomi14ultra_2026-10-08_auth_optimization.md)显示预热后局部线程 CPU 约降 60.9%，进程分配计数显著减少；四轮 IPC 变化方向不一致，未证明端到端稳定加速。不能把局部微测倍数套到整条 RPC。

## 9. 同步握手容量补充修复

在上述4494已验收版本之后，复核发现同步handshake仍占用控制Dispatchers.IO，连续超时重试可能累积阻塞worker。当前源码新增独立HandshakeExecutor（最多4 worker、无队列），解绑与绑定截止取消等待Job，晚回包校验连接/Binding/Job身份；不能中断已启动的Binder事务。该改动与业务发现4worker分池，最新402684版本五应用构建安装成功，9项真实阻塞探针及完整回归等待小米解锁。详见[本轮报告](benchmarks/xiaomi14ultra_2026-10-09_cold_trace_optimization.md#33-补充绑定握手也需要独立的阻塞容量)，旧4494性能/功能结果不能替代此变更验收。
