# ModernIpc

ModernIpc 是 Android Binder IPC 示例工程与 SDK：以 Kotlin 接口描述业务，用 KSP 生成调用代理和服务端 Stub。当前实现提供挂起 RPC、可选短调用同步 RPC、Flow 订阅、Oneway、Broker 服务发现、连接状态与断线重连。框架层仍有一份 Broker AIDL；业务接口无需逐个编写 AIDL。

本仓库展示两种部署：demo-app 的同包跨进程示例，以及 app-server + app-client1/2/3 的跨包消息中枢。跨包示例要求服务端和客户端同签名，且服务端绑定权限设为 signature 级；客户端身份按包名与 UID 校验。

## 从哪里开始

| 需求 | 文档 |
| --- | --- |
| 理解模块与调用链 | [架构与协议](docs/ModernIPC_Architecture.md) |
| 在工程中调用 SDK | [SDK 接入](docs/ModernIPC_SDK_Guide.md) |
| 运行四 APK 会议通知与展示案例 | [多 App 业务案例](docs/ModernIPC_Business_Interaction_Guide.md) |
| 运行仓储工单、配置同步、遥测告警 | [多 App 场景目录](docs/ModernIPC_Multi_App_Scenarios.md) |
| 构建、发布或消费 Maven 产物 | [Maven 指南](docs/ModernIPC_Maven_Guide.md) |
| 与 AndLinker 选型 | [详细对比](docs/ModernIPC_vs_AndLinker.md) |
| 设备测试数据和局限 | [测试索引](docs/benchmarks/README.md) |
| 调用延迟优化与诊断 | [优化分析](docs/ModernIPC_Optimization_Analysis.md) |

## 模块

| 模块 | 职责 |
| --- | --- |
| ipc-annotations | IpcFacade、IpcAsync、IpcDirect、IpcStream、IpcOneway 注解。 |
| ipc-compiler | KSP 生成 ClientAdapter 和 ServerStub。 |
| ipc-contract | Broker AIDL、公共 Binder 协议与默认关闭的请求 trace。 |
| ipc-runtime-client | 绑定、握手、可取消共享服务发现、请求关联、取消和重连。 |
| ipc-runtime-server | Broker、调用方鉴权、请求跟踪和服务端辅助组件。 |
| ipc-api | 示例业务契约，如 IMessageHubService；配置 KSP。 |
| demo-app | 同包分进程示例。 |
| demo-client-common | 跨包客户端共用界面和测试代码。 |
| app-server、app-client1/2/3 | 一个服务端和三个独立客户端 APK。 |

```mermaid
flowchart LR
    API["业务接口 / ipc-api"] --> KSP["ipc-compiler / KSP"]
    KSP --> CLIENT["客户端生成代理"]
    KSP --> SERVER["服务端生成 Stub"]
    CLIENT --> RUNTIME["ipc-runtime-client"]
    RUNTIME -- "IIpcBroker AIDL 握手 / Binder 请求" --> BROKER["ipc-runtime-server / Broker"]
    BROKER --> SERVER
    SERVER -- "回调 Binder / Flow 事件" --> CLIENT
```

入口见 [settings.gradle.kts](settings.gradle.kts)、[IMessageHubService](ipc-api/src/main/kotlin/com/cn/ipc/api/hub/IMessageHubService.kt) 和 [Broker AIDL](ipc-contract/src/main/aidl/com/cn/ipc/IIpcBroker.aidl)。

## 构建和运行跨包示例

前提：可用的 Android SDK、JDK 和 ADB；用仓库 Gradle Wrapper 构建。PowerShell 示例：

~~~powershell
.\gradlew.bat :app-server:assembleDebug :app-client1:assembleDebug :app-client2:assembleDebug :app-client3:assembleDebug
adb -s 925c23bb install -r app-server\build\outputs\apk\debug\app-server-debug.apk
adb -s 925c23bb install -r app-client1\build\outputs\apk\debug\app-client1-debug.apk
adb -s 925c23bb install -r app-client2\build\outputs\apk\debug\app-client2-debug.apk
adb -s 925c23bb install -r app-client3\build\outputs\apk\debug\app-client3-debug.apk
adb -s 925c23bb shell am start -W -n com.cn.ipc.server.app/.ServerMainActivity
adb -s 925c23bb shell am start -W -n com.cn.ipc.client2/.Client2Activity
adb -s 925c23bb shell am start -W -n com.cn.ipc.client3/.Client3Activity
adb -s 925c23bb shell am start -W -n com.cn.ipc.client1/.Client1Activity
~~~

以上示例固定测试设备小米 `925c23bb`。先启动中枢，再打开会议屏、运维屏，最后打开调度台；确认连接及订阅后操作。客户端仍可发 ALL 广播、指定 client_2/client_3 的定向消息，或向 SERVER_ONLY 上报。启动顺序在小米设备上尤其重要：2026-09-29 实测中，服务端未运行时的跨包自动唤醒被系统拦截；详见[实机记录](docs/benchmarks/xiaomi14ultra_2026-09-29_smoke.md)。跨包可见性、权限和签名配置见[业务案例](docs/ModernIPC_Business_Interaction_Guide.md)。

## 多 App 实际案例：会议通知与展示

| 应用 | 业务角色 | 操作与效果 |
| --- | --- | --- |
| app-server | 消息中枢 | Broker、身份校验和路由，记录仅服务端上报。 |
| app-client1 | 调度台 | 发布定向会议、广播会务通知、向中枢上报。 |
| app-client2 | 会议屏 | 更新 App 内 TextView 会议卡，回传同一 commandId 的展示确认。 |
| app-client3 | 运维屏 | 观察展示确认和公共通知，不接收会议屏的原始定向指令。 |

三个客户端的“多 App 案例：会议通知”卡使用独立 JSON 业务载荷，复用现有 IMessageHubService。调度台按钮“发布会议到会议屏”发送 `meeting.show`；会议屏更新卡片后广播 `meeting.displayed`，调度台匹配 commandId/title/room。案例提供覆盖路由 RPC 与业务 ACK 的 5 秒总预算，超时显示结果未知、不自动重发。另有“广播会务通知”和“仅向中枢上报”。案例与原消息接收共用一条订阅流，可暂停或恢复。

这是同一 Android 设备上四个独立 UID/APK 的协作。会议卡、在线表和最近 64 条去重记录均在内存中；路由 OK 不代表最终消费，展示确认只表示本地 TextView 赋值，离线与暂停订阅不补发。案例架构图、业务流程图、完整时序、权限和验收步骤见[业务文档](docs/ModernIPC_Business_Interaction_Guide.md)。

[案例采集脚本](docs/benchmarks/harness/capture_multi_app_case.py)默认只准备，`--execute` 才在小米 `925c23bb` 上运行。新场景构建和设备状态见[案例报告](docs/benchmarks/xiaomi14ultra_2026-10-09_multi_app_case.md)，设备验收为 NOT_RUN；既有 crosspkg1 smoke、64 项框架回归和 echo 性能数据均不能替代本案例投递与确认验证。

## 更多多 App 场景

客户端场景选择器保留默认“会议通知”，并新增三个场景：

| 场景 | 实际协作链 | 完成条件 |
| --- | --- | --- |
| 仓储工单 | client1 定向分派 → client2 接单 → 用户点击完成 → client1/3 观察状态。 | `order.completed`；接单确认不等于完成。 |
| 配置同步 | client1 广播 revision → client2/3 更新本地卡片颜色与字号 → 各自确认给 client1。 | 两个端确认同一版本与内容；旧版本及冲突拒绝覆盖。 |
| 遥测告警 | client2 手工发送 25/35°C 样本 → client3 按 30°C 阈值分析 → 异常告警广播给 client1/2。 | 指定异常样本的告警可见；正常样本不产生新告警。 |

新增场景复用当前 String 业务协议，未改变 Binder 事务、服务 ID 或 Schema。所有业务状态仍在 Activity 内存中；配置只改变演示卡，温度来自预置按钮，工单没有硬件或库存副作用。架构图、逐场景流程图、时序图、操作与验收见[场景目录](docs/ModernIPC_Multi_App_Scenarios.md)。构建与小米设备验收状态单独见[新增场景报告](docs/benchmarks/xiaomi14ultra_2026-10-09_more_scenarios.md)，不能沿用原会议或历史 echo 测试结果。

## API 行为与边界

- IpcAsync 挂起请求经 Oneway Binder 发送，并由回调 Binder 返回结果；生成入口默认 30 秒预算覆盖可取消冷发现和 pending 等待，可配置。已登记请求的取消与截止向原 Binder 传递取消请求；已开始的同步 Binder 不能被强制中断，已经产生的副作用无法自动回滚。
- IpcDirect 为明确的短方法生成一次同步 Binder 请求/响应；客户端必须在后台线程调用，服务端直接使用 Binder 线程。它没有异步请求的取消与 128 在途限制，不能用于阻塞 I/O 或长计算。详见[接入说明](docs/ModernIPC_SDK_Guide.md#短调用快速路径)。
- IpcStream 使用订阅与取消订阅事务，具有 NEXT、COMPLETE、ERROR 终态；发现等待有截止，订阅后的长期业务流没有整段默认超时。默认客户端缓冲溢出显式报错，状态流可标注 CONFLATE 合并值。示例 SharedFlow 仍采用丢弃旧值策略，不保证离线消息或持久投递。
- IpcOneway 只保证客户端无需等待业务回执；它不表示服务端已经完成处理。同步冷解析在 Main 上立即拒绝，界面入口需先用 awaitServiceBinderForConnection 挂起预热严格 Schema；跨包示例的注册与 Ping 已接入预热。
- 服务端默认最多跟踪 128 个在途请求；超限可能收到 SERVER_BUSY。连接退避重试不会自动重放失败的业务 RPC。IpcAsync 的 idempotent 属性目前未接入自动重试。
- Controller 的 close 可重新连接，dispose 永久释放；owner Job 最终结束后自动 dispose。关闭时置换并作废发现容器、唤醒 waiter，不等待发现 RPC 返回；晚结果不进入新容器。Service 销毁时释放注册 Stub 的请求与订阅；已开始的同步或非协作业务不能保证被中断。
- 生成客户端首次取得服务时校验版本、descriptor 和逐事务签名，按连接代次、最低版本及预期签名缓存。服务端再次检查；严格客户端在旧 Broker 上明确失败。用户与消息中枢服务要求客户端契约版本至少 2。
- 同一 Controller 同键发现共享结果，可取消等待；最后 waiter 退出后放弃该发现。同一进程/classloader 的所有 Controller 共用最多 4 个发现 worker，不保留排队任务；饱和时拒绝新的冷发现，温缓存仍可读取。手写 callSuspendWithinDeadline 必须自行提供外层截止。
- IpcRequestTrace 默认关闭，启用后每进程最多缓冲 16,384 个事件，窗口结束再导出 Logcat 或文件；仅支持隔离单客户端/单 Controller 的请求关联诊断，不新增 wire 身份或自动重试。
- KSP 拒绝未实现的 nullable、泛型、集合及 Async Unit 等类型。基本 IPC 类型为 String/Int/Long/Boolean/ByteArray，Flow item 另支持 Float/Double，非 Direct 支持非泛型 Parcelable。Parcelable 内部字段布局仍由应用维护兼容性。
- ModernIpcRouter 中的 AndLinker 回退尚未接入，RxIpcExtensions 中的适配实现也尚未启用。

## 测试证据

测试限定 Xiaomi 14 Ultra `925c23bb`。[冷发现与请求 trace 轮次](docs/benchmarks/xiaomi14ultra_2026-10-09_cold_trace_optimization.md)已完成五应用统一构建、3 独立客户端跨包 smoke。初始 trace APK `5C8CE...` 完成 64 PASS/5 DONE，traceon4 完成 1000 请求完整链、11000 文件事件且无丢弃，traceoff1 双端 0 事件。新增 demo 调度配置实验后，调度实测 APK `4494F5299DF407EA3DB2DFE915B14057A39A6DCE5F4171217237FF8F88E1F0A4` 再次通过 64 PASS/5 DONE 与完整 traceon5；[该阶段验收](docs/benchmarks/runs/2026-10-09-xiaomi14ultra/cold-trace-analysis/final-verification.json)可核验。本轮已修入口截止和缓存清理两项 P1；两轮同 APK 调度实验全部 56,192 次测量成功，但小包串行收益有反向配对，保留为短任务可选配置。SDK scope 仍由宿主提供，demo 默认 Default；不声称通用稳定 RTT 加速，未更新两库性能排名。后续复核另修复同步握手占用控制 IO 的风险，新增有界握手 worker 与 9 项探针；此前握手构建402684版本五应用构建及安装哈希校验通过，新增9项与完整设备回归尚未完成，不能沿用 4494 验收。案例源码新增后的构建身份与设备状态单独见[会议案例报告](docs/benchmarks/xiaomi14ultra_2026-10-09_multi_app_case.md)。

第一阶段冷发现 APK `6F4162248E507B6762CE3C7984EC454480849D69EB2BC70B4DE6A007037E6067` 的 64 PASS/5 DONE 属于此前构建，与当前 5C8CE... 的独立回归区分。

前序[Async 发送前检查优化](docs/benchmarks/xiaomi14ultra_2026-10-08_presend_guard.md)保留首次严格发现，将注册后的第二次完整缓存查询改为捕获 Binder 的连接/释放/存活检查。30ED4... APK 完成 52 项功能 PASS；两组合格前台记录共 32,000 次成功 IPC。发送前步骤近似少分配 48 B、线程 CPU 约少 0.60 μs，RTT 两组方向反转，未证明稳定端到端加速。

前序按生命周期 → 请求与流终态 → 协议兼容 → pending 状态优化推进，阶段源码/APK 哈希与小米日志统一见[顺序修复报告](docs/benchmarks/xiaomi14ultra_2026-10-08_ordered_remediation.md)。该前序 APK 的功能回归共 52 项 PASS，三组性能竞态检查共 36 项 PASS；本地完整 Registry 近似每调用少分配 48 字节（约 5%），当时未证明全程前台。未知原因的 6.411 秒长尾保留，不能认定已被本轮 guard 修复，两轮局部分配差额也不直接相加为完整调用收益。

2026-09-29 小米 14 Ultra 短测，在当时修复后的 Debug APK 上验证了跨包连接、两次各 1000 次的挂起 RPC、定向消息与 Flow。两次 RTT P50 为 2.067 ms 和 2.256 ms，均包含服务端业务处理。后台跨包冷启动被 Xiaomi WakePathChecker 拦截。该数据不能用来断言库与 AndLinker 的速度优劣；两个原版示例的包拓扑和业务方法不同。原始日志、APK 哈希与条件见[测试报告](docs/benchmarks/xiaomi14ultra_2026-09-29_smoke.md)。早期无原始日志的压测数字单独归档为[历史记录](docs/benchmarks/benchmark_Xiaomi_14_Ultra.md)。

另有[同负载 echo 对比](docs/benchmarks/xiaomi14ultra_2026-09-29_echo_ab.md)：两库统一为同包分进程，服务端原样返回 16/1024 字符，四轮各 1000 次串行调用，均零失败。四轮 P50 中位数分别为 ModernIpc suspend 0.536/0.682 ms、AndLinker 同步 0.258/0.232 ms、AndLinker enqueue 0.327/0.353 ms。本次前台 Debug 示例中 AndLinker 较低；两边协议、调度和 targetSdk 不同，不能据此推断跨包后台或其他业务的固定速度差。原始 CSV 与完整限制见报告。

针对该差距增加[可选快速路径实测](docs/benchmarks/xiaomi14ultra_2026-09-29_direct_fast_path.md)：在同一新版 Debug APK、同包双进程且原样 echo 的前台场景，16/1024 字符四轮 P50 中位数由 suspend 的 0.543/0.602 ms 降到 direct 的 0.129/0.328 ms。并发短测、APK 哈希、P99、原始 CSV 与调用语义限制均在报告中；这些数据不与较早的 AndLinker APK 直接混算。

## 发布状态

构建脚本配置了项目内 local-maven 与 GitHub Packages 发布目标；远端包是否已存在须在使用前核实。版本和仓库地址以[发布脚本](build-logic/src/main/kotlin/convention.publish.gradle.kts)为准。可复现的本地发布和消费步骤见[Maven 指南](docs/ModernIPC_Maven_Guide.md)。
