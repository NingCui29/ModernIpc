/*
 * This file is auto-generated.  DO NOT MODIFY.
 */
package com.cn.ipc;
/**
 * IPC 核心 Broker 接口（AIDL）。
 * 
 * 作为跨进程通信的中枢，所有客户端在使用具体业务服务前，
 * 必须先通过 handshake 完成协议协商，再通过 getService 获取目标服务的 Binder。
 */
public interface IIpcBroker extends android.os.IInterface
{
  /** Default implementation for IIpcBroker. */
  public static class Default implements com.cn.ipc.IIpcBroker
  {
    /**
     * 执行握手协议协商。
     * 
     * 客户端在绑定服务后应首先调用此方法，发送 ClientHello 完成版本与能力的双向协商。
     * 协商失败时返回可通过 Parcel 编码的 IllegalArgumentException。
     * 
     * @param client 客户端握手请求，包含版本信息、包名及请求能力集合。
     * @return 服务端握手响应，包含协商后的协议版本、能力集合及本次会话 ID。
     */
    @Override public com.cn.ipc.ProtocolInfo handshake(com.cn.ipc.ClientHello client) throws android.os.RemoteException
    {
      return null;
    }
    /**
     * 获取指定业务服务的 Binder 对象。
     * 
     * 握手成功后，客户端通过此方法按 serviceId 向 Broker 请求具体业务服务的 Binder。
     * 若服务不存在或版本不满足要求，服务端将抛出 IllegalArgumentException。
     * 
     * @param serviceId     目标服务的全局唯一 ID（对应 @IpcFacade.serviceId）。
     * @param minApiVersion 客户端要求的最低服务 API 版本，低于此版本时请求被拒绝。
     * @return 目标服务的 IBinder，客户端可将其转换为对应的 AIDL Stub。
     */
    @Override public android.os.IBinder getService(int serviceId, int minApiVersion) throws android.os.RemoteException
    {
      return null;
    }
    /** Metadata only; no business Binder is granted by this transaction. */
    @Override public com.cn.ipc.ServiceSchema getServiceSchema(int serviceId) throws android.os.RemoteException
    {
      return null;
    }
    /** Acquire only after checking the client's concrete wire contract. */
    @Override public android.os.IBinder getServiceChecked(int serviceId, int minApiVersion, com.cn.ipc.ClientServiceSchema clientSchema) throws android.os.RemoteException
    {
      return null;
    }
    @Override
    public android.os.IBinder asBinder() {
      return null;
    }
  }
  /** Local-side IPC implementation stub class. */
  public static abstract class Stub extends android.os.Binder implements com.cn.ipc.IIpcBroker
  {
    /** Construct the stub at attach it to the interface. */
    public Stub()
    {
      this.attachInterface(this, DESCRIPTOR);
    }
    /**
     * Cast an IBinder object into an com.cn.ipc.IIpcBroker interface,
     * generating a proxy if needed.
     */
    public static com.cn.ipc.IIpcBroker asInterface(android.os.IBinder obj)
    {
      if ((obj==null)) {
        return null;
      }
      android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
      if (((iin!=null)&&(iin instanceof com.cn.ipc.IIpcBroker))) {
        return ((com.cn.ipc.IIpcBroker)iin);
      }
      return new com.cn.ipc.IIpcBroker.Stub.Proxy(obj);
    }
    @Override public android.os.IBinder asBinder()
    {
      return this;
    }
    @Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
    {
      java.lang.String descriptor = DESCRIPTOR;
      if (code >= android.os.IBinder.FIRST_CALL_TRANSACTION && code <= android.os.IBinder.LAST_CALL_TRANSACTION) {
        data.enforceInterface(descriptor);
      }
      switch (code)
      {
        case INTERFACE_TRANSACTION:
        {
          reply.writeString(descriptor);
          return true;
        }
      }
      switch (code)
      {
        case TRANSACTION_handshake:
        {
          com.cn.ipc.ClientHello _arg0;
          _arg0 = _Parcel.readTypedObject(data, com.cn.ipc.ClientHello.CREATOR);
          com.cn.ipc.ProtocolInfo _result = this.handshake(_arg0);
          reply.writeNoException();
          _Parcel.writeTypedObject(reply, _result, android.os.Parcelable.PARCELABLE_WRITE_RETURN_VALUE);
          break;
        }
        case TRANSACTION_getService:
        {
          int _arg0;
          _arg0 = data.readInt();
          int _arg1;
          _arg1 = data.readInt();
          android.os.IBinder _result = this.getService(_arg0, _arg1);
          reply.writeNoException();
          reply.writeStrongBinder(_result);
          break;
        }
        case TRANSACTION_getServiceSchema:
        {
          int _arg0;
          _arg0 = data.readInt();
          com.cn.ipc.ServiceSchema _result = this.getServiceSchema(_arg0);
          reply.writeNoException();
          _Parcel.writeTypedObject(reply, _result, android.os.Parcelable.PARCELABLE_WRITE_RETURN_VALUE);
          break;
        }
        case TRANSACTION_getServiceChecked:
        {
          int _arg0;
          _arg0 = data.readInt();
          int _arg1;
          _arg1 = data.readInt();
          com.cn.ipc.ClientServiceSchema _arg2;
          _arg2 = _Parcel.readTypedObject(data, com.cn.ipc.ClientServiceSchema.CREATOR);
          android.os.IBinder _result = this.getServiceChecked(_arg0, _arg1, _arg2);
          reply.writeNoException();
          reply.writeStrongBinder(_result);
          break;
        }
        default:
        {
          return super.onTransact(code, data, reply, flags);
        }
      }
      return true;
    }
    private static class Proxy implements com.cn.ipc.IIpcBroker
    {
      private android.os.IBinder mRemote;
      Proxy(android.os.IBinder remote)
      {
        mRemote = remote;
      }
      @Override public android.os.IBinder asBinder()
      {
        return mRemote;
      }
      public java.lang.String getInterfaceDescriptor()
      {
        return DESCRIPTOR;
      }
      /**
       * 执行握手协议协商。
       * 
       * 客户端在绑定服务后应首先调用此方法，发送 ClientHello 完成版本与能力的双向协商。
       * 协商失败时返回可通过 Parcel 编码的 IllegalArgumentException。
       * 
       * @param client 客户端握手请求，包含版本信息、包名及请求能力集合。
       * @return 服务端握手响应，包含协商后的协议版本、能力集合及本次会话 ID。
       */
      @Override public com.cn.ipc.ProtocolInfo handshake(com.cn.ipc.ClientHello client) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        com.cn.ipc.ProtocolInfo _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, client, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_handshake, _data, _reply, 0);
          _reply.readException();
          _result = _Parcel.readTypedObject(_reply, com.cn.ipc.ProtocolInfo.CREATOR);
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * 获取指定业务服务的 Binder 对象。
       * 
       * 握手成功后，客户端通过此方法按 serviceId 向 Broker 请求具体业务服务的 Binder。
       * 若服务不存在或版本不满足要求，服务端将抛出 IllegalArgumentException。
       * 
       * @param serviceId     目标服务的全局唯一 ID（对应 @IpcFacade.serviceId）。
       * @param minApiVersion 客户端要求的最低服务 API 版本，低于此版本时请求被拒绝。
       * @return 目标服务的 IBinder，客户端可将其转换为对应的 AIDL Stub。
       */
      @Override public android.os.IBinder getService(int serviceId, int minApiVersion) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        android.os.IBinder _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeInt(serviceId);
          _data.writeInt(minApiVersion);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getService, _data, _reply, 0);
          _reply.readException();
          _result = _reply.readStrongBinder();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /** Metadata only; no business Binder is granted by this transaction. */
      @Override public com.cn.ipc.ServiceSchema getServiceSchema(int serviceId) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        com.cn.ipc.ServiceSchema _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeInt(serviceId);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getServiceSchema, _data, _reply, 0);
          _reply.readException();
          _result = _Parcel.readTypedObject(_reply, com.cn.ipc.ServiceSchema.CREATOR);
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /** Acquire only after checking the client's concrete wire contract. */
      @Override public android.os.IBinder getServiceChecked(int serviceId, int minApiVersion, com.cn.ipc.ClientServiceSchema clientSchema) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        android.os.IBinder _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeInt(serviceId);
          _data.writeInt(minApiVersion);
          _Parcel.writeTypedObject(_data, clientSchema, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getServiceChecked, _data, _reply, 0);
          _reply.readException();
          _result = _reply.readStrongBinder();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
    }
    static final int TRANSACTION_handshake = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
    static final int TRANSACTION_getService = (android.os.IBinder.FIRST_CALL_TRANSACTION + 2);
    static final int TRANSACTION_getServiceSchema = (android.os.IBinder.FIRST_CALL_TRANSACTION + 3);
    static final int TRANSACTION_getServiceChecked = (android.os.IBinder.FIRST_CALL_TRANSACTION + 4);
  }
  public static final java.lang.String DESCRIPTOR = "com.cn.ipc.IIpcBroker";
  /**
   * 执行握手协议协商。
   * 
   * 客户端在绑定服务后应首先调用此方法，发送 ClientHello 完成版本与能力的双向协商。
   * 协商失败时返回可通过 Parcel 编码的 IllegalArgumentException。
   * 
   * @param client 客户端握手请求，包含版本信息、包名及请求能力集合。
   * @return 服务端握手响应，包含协商后的协议版本、能力集合及本次会话 ID。
   */
  public com.cn.ipc.ProtocolInfo handshake(com.cn.ipc.ClientHello client) throws android.os.RemoteException;
  /**
   * 获取指定业务服务的 Binder 对象。
   * 
   * 握手成功后，客户端通过此方法按 serviceId 向 Broker 请求具体业务服务的 Binder。
   * 若服务不存在或版本不满足要求，服务端将抛出 IllegalArgumentException。
   * 
   * @param serviceId     目标服务的全局唯一 ID（对应 @IpcFacade.serviceId）。
   * @param minApiVersion 客户端要求的最低服务 API 版本，低于此版本时请求被拒绝。
   * @return 目标服务的 IBinder，客户端可将其转换为对应的 AIDL Stub。
   */
  public android.os.IBinder getService(int serviceId, int minApiVersion) throws android.os.RemoteException;
  /** Metadata only; no business Binder is granted by this transaction. */
  public com.cn.ipc.ServiceSchema getServiceSchema(int serviceId) throws android.os.RemoteException;
  /** Acquire only after checking the client's concrete wire contract. */
  public android.os.IBinder getServiceChecked(int serviceId, int minApiVersion, com.cn.ipc.ClientServiceSchema clientSchema) throws android.os.RemoteException;
  /** @hide */
  static class _Parcel {
    static private <T> T readTypedObject(
        android.os.Parcel parcel,
        android.os.Parcelable.Creator<T> c) {
      if (parcel.readInt() != 0) {
          return c.createFromParcel(parcel);
      } else {
          return null;
      }
    }
    static private <T extends android.os.Parcelable> void writeTypedObject(
        android.os.Parcel parcel, T value, int parcelableFlags) {
      if (value != null) {
        parcel.writeInt(1);
        value.writeToParcel(parcel, parcelableFlags);
      } else {
        parcel.writeInt(0);
      }
    }
  }
}
